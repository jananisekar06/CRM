# CRM Project - Run panna evlo steps (Tanglish)

## Main Bug fix panniten
`crm-backend/db/store.js` file la `ALLOWED_TABLES` list la 10 table names mattum than irundhuchu,
aana app moththama 39 tables use pannudhu (leads, payments, reports, inventory, notifications, sales,
contacts, vendors, campaigns, emails, whatsapp, logs, subscriptions, companies, analytics, etc).
Adhunala andha modules ellam "Invalid table name" error kudutha 500 error throw pannuchu.
Ippo andha list la ella table names um add pannitten - test pannen, ellam 200 OK vandhuchu.

## Ippo un system la evlo run panna:

### 1) PostgreSQL install pannu (illana already iruntha skip)
- Windows/Mac: https://www.postgresql.org/download/ la irundhu install pannu
- Install panra pothu oru password kekum "postgres" user ku - adha nyabagam vச்சுko

### 2) Database create pannu
psql la login aayitu:
```
CREATE DATABASE crm_db;
```

### 3) Backend .env file edit pannu
`crm-backend/.env` file open pannu, `DB_PASSWORD=postgres` nu iruku - adha step 1 la
neenga set panna password ku maathu.

### 4) Backend setup
```
cd crm-backend
npm install
npm run db:setup     (tables create aagum)
npm run db:seed      (sample data + admin login create aagum)
npm run dev
```
Backend http://localhost:5000 la run aagum. Terminal la "Server Running on Port 5000" nu varum.

Login credentials (seed panna apram):
- Email: admin@gmail.com
- Password: 123456

### 5) Frontend setup (vera terminal la)
```
cd crm-frontend
npm install
npm run dev
```
Frontend http://localhost:5173 la open aagum (terminal la exact URL varum).

## Common errors & fix
- **"password authentication failed for user postgres"** -> .env la DB_PASSWORD wrong,
  step 3 correct pannunga.
- **"database crm_db does not exist"** -> step 2 pannunga.
- **Backend start aana udane close aaidhu** -> terminal la irukura error message full ah
  paaru, adhula than root cause irukum (ipo uncaughtException/unhandledRejection ellam
  log aagum nu server.js la already add pannirukanga).
- **Frontend la data varala aana backend terminal la error illa** -> backend already
  run aagitu irukka nu check pannu (separate terminal, npm run dev backend side).
