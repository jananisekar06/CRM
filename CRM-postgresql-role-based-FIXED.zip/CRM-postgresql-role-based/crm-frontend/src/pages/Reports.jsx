import { useEffect, useState } from "react";
import axios from "axios";import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaChartBar,
  FaUsers,
  FaMoneyBillWave,
  FaShoppingCart,
} from "react-icons/fa";

function Reports() {
  const [reports, setReports] = useState([
  {
    id: 1,
    month: "April",
    sales: 350,
    revenue: "₹5.2L",
    customers: 1300,
  },
]);
const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState({
  month: "",
  sales: "",
  revenue: "",
  customers: "",
});
const handleChange = (e) => {
  setForm({
    ...form,
    [e.target.name]: e.target.value,
  });
};

const handleSubmit = async (e) => {
  e.preventDefault();

  if (
    !form.month.trim() ||
    !form.sales ||
    !form.revenue.trim() ||
    !form.customers
  ) {
    alert("Please fill all fields");
    return;
  }

  try {
    // UPDATE
    if (editingId !== null) {
      const response = await axios.put(
        `http://localhost:5000/api/reports/${editingId}`,
        form
      );

      setReports(
        reports.map((report) =>
          report.id === editingId
            ? response.data.report
            : report
        )
      );

      alert("Report Updated Successfully");

      setEditingId(null);
    }

    // ADD
    else {
      const response = await axios.post(
        "http://localhost:5000/api/reports",
        form
      );

      setReports([...reports, response.data.report]);

      alert("Report Added Successfully");
    }

    setForm({
      month: "",
      sales: "",
      revenue: "",
      customers: "",
    });
  } catch (error) {
    console.error("Error saving report:", error);
    alert("Failed to save report");
  }
};
const handleEdit = (report) => {
  setEditingId(report.id);

  setForm({
    month: report.month,
    sales: report.sales,
    revenue: report.revenue,
    customers: report.customers,
  });
};
const handleDelete = async (id) => {
  try {
    await axios.delete(
      `http://localhost:5000/api/reports/${id}`
    );

    setReports(
      reports.filter((report) => report.id !== id)
    );

    alert("Report Deleted Successfully");
  } catch (error) {
    console.error("Error deleting report:", error);
    alert("Failed to delete report");
  }
};
useEffect(() => {
  fetchReports();
}, []);

const fetchReports = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/reports"
    );

    console.log("Reports from backend:", response.data);

    setReports(response.data);
  } catch (error) {
    console.error("Error fetching reports:", error);
  }
};

   return (
    <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <main style={{ padding: "30px" }}>
       
          <h1 style={{ color: "#1E293B", marginBottom: "5px" }}>
            Reports
          </h1>

          <p style={{ color: "#64748B", marginBottom: "25px" }}>
            Business performance and analytics reports
          </p>

          {/* Report Cards */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: "20px",
            }}
          >
            <div style={reportCard}>
              <FaUsers size={32} color="#4F46E5" />
              <p>Total Customers</p>
              <h2>
  {reports.length > 0
    ? reports[reports.length - 1].customers
    : 0}
</h2>
              <span style={{ color: "#22C55E" }}>
                +12% this month
              </span>
            </div>

            <div style={reportCard}>
              <FaMoneyBillWave size={32} color="#22C55E" />
              <p>Total Revenue</p>
              <h2>
  ₹
  {reports
    .reduce((total, report) => {
      const value = parseFloat(
        String(report.revenue || "").replace(/[^\d.]/g, "")
      );
      return total + (isNaN(value) ? 0 : value);
    }, 0)
    .toFixed(2)}
</h2>
              <span style={{ color: "#22C55E" }}>
                +18% this month
              </span>
            </div>

            <div style={reportCard}>
              <FaShoppingCart size={32} color="#F59E0B" />
              <p>Total Sales</p>
              <h2>
  {reports.reduce(
    (total, report) => total + Number(report.sales || 0),
    0
  )}
</h2>
              <span style={{ color: "#22C55E" }}>
                +8% this month
              </span>
            </div>

            <div style={reportCard}>
              <FaChartBar size={32} color="#0EA5E9" />
              <p>Conversion Rate</p>
              <h2>68%</h2>
              <span style={{ color: "#22C55E" }}>
                +5% this month
              </span>
            </div>
          </div>

          {/* Sales Report */}
          <div style={sectionStyle}>
            <h2>Monthly Sales Report</h2>

            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
                marginTop: "20px",
              }}
            >
              <thead>
                <tr
                  style={{
                    background: "#4F46E5",
                    color: "#FFFFFF",
                  }}
                >
                  <th style={{ padding: "15px" }}>Month</th>
                  <th>Sales</th>
                  <th>Revenue</th>
                  <th>Customers</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
  {reports.length > 0 ? (
    reports.map((report) => (
      <tr key={report.id} style={rowStyle}>
  <td style={cellStyle}>{report.month}</td>
  <td>{report.sales}</td>
  <td>{report.revenue}</td>
  <td>{report.customers}</td>

  <td>
    <button
  onClick={() => handleEdit(report)}
  style={{
    background: "#F59E0B",
    color: "#FFFFFF",
    border: "none",
    padding: "8px 14px",
    borderRadius: "6px",
    cursor: "pointer",
    marginRight: "8px",
  }}
>
  Edit
</button>
    <button
      onClick={() => handleDelete(report.id)}
      style={{
        background: "#EF4444",
        color: "#FFFFFF",
        border: "none",
        padding: "8px 14px",
        borderRadius: "6px",
        cursor: "pointer",
      }}
    >
      Delete
    </button>
  </td>
</tr>
    ))
  ) : (
    <tr>
      <td
        colSpan="4"
        style={{
          padding: "20px",
          textAlign: "center",
          color: "#64748B",
        }}
      >
        No reports available
      </td>
    </tr>
  )}
</tbody>
            </table>
          </div>
          {/* Add Report */}

<div style={sectionStyle}>
  <h2>Add Monthly Report</h2>

  <form onSubmit={handleSubmit}>
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(2, 1fr)",
        gap: "20px",
        marginTop: "20px",
      }}
    >
      <div>
        <label>Month</label>
        <input
          type="text"
          name="month"
          placeholder="April"
          value={form.month}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>

      <div>
        <label>Sales</label>
        <input
          type="number"
          name="sales"
          placeholder="350"
          value={form.sales}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>

      <div>
        <label>Revenue</label>
        <input
          type="text"
          name="revenue"
          placeholder="₹5.2L"
          value={form.revenue}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>

      <div>
        <label>Customers</label>
        <input
          type="number"
          name="customers"
          placeholder="1300"
          value={form.customers}
          onChange={handleChange}
          style={inputStyle}
        />
      </div>
    </div>

    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        marginTop: "20px",
      }}
    >
      <button
        type="submit"
        style={{
          background: "#4F46E5",
          color: "#fff",
          border: "none",
          padding: "12px 25px",
          borderRadius: "8px",
          cursor: "pointer",
        }}
      >
        Save Report
      </button>
    </div>
  </form>
</div>

          {/* Department Report */}
          <div style={sectionStyle}>
            <h2>Department Performance</h2>

            <div style={{ marginTop: "20px" }}>
              <p>Sales Department</p>
              <Progress value="85%" />

              <p>Marketing Department</p>
              <Progress value="72%" />

              <p>Support Department</p>
              <Progress value="65%" />

              <p>HR Department</p>
              <Progress value="90%" />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function Progress({ value }) {
  return (
    <div
      style={{
        background: "#E2E8F0",
        height: "10px",
        borderRadius: "10px",
        marginBottom: "20px",
      }}
    >
      <div
        style={{
          width: value,
          height: "100%",
          background: "#4F46E5",
          borderRadius: "10px",
        }}
      />
    </div>
  );
}

const reportCard = {
  background: "#FFFFFF",
  padding: "22px",
  borderRadius: "14px",
  boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
};

const sectionStyle = {
  background: "#FFFFFF",
  padding: "25px",
  borderRadius: "14px",
  marginTop: "25px",
  boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
};

const rowStyle = {
  textAlign: "center",
  borderBottom: "1px solid #E2E8F0",
};

const cellStyle = {
  padding: "15px",
};
const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};
export default Reports;        