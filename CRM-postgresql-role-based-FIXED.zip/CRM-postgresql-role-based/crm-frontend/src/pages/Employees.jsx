
import { useEffect, useState } from "react";import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaUserTie,
  FaUsers,
  FaBuilding,
  FaMoneyBillWave,
} from "react-icons/fa";

function Employees() {
  const [search, setSearch] = useState("");
const [showModal, setShowModal] = useState(false);

const [employee, setEmployee] = useState({
  name: "",
  department: "",
  designation: "",
  salary: "",
  email: "",
  phone: "",
  status: "Active",
});
const [employees, setEmployees] = useState([
    {
      id: 101,
      name: "John Smith",
      department: "Sales",
      designation: "Sales Executive",
      salary: "₹35,000",
      email: "john@gmail.com",
      phone: "9876543210",
      status: "Active",
    },
    {
      id: 102,
      name: "Priya",
      department: "HR",
      designation: "HR Manager",
      salary: "₹45,000",
      email: "priya@gmail.com",
      phone: "9876500000",
      status: "Active",
    },
    {
      id: 103,
      name: "Rahul",
      department: "IT",
      designation: "React Developer",
      salary: "₹55,000",
      email: "rahul@gmail.com",
      phone: "9876511111",
      status: "Inactive",
    },
    {
      id: 104,
      name: "David",
      department: "Finance",
      designation: "Accountant",
      salary: "₹40,000",
      email: "david@gmail.com",
      phone: "9876522222",
      status: "Active",
    },
    {
      id: 105,
      name: "Sneha",
      department: "Support",
      designation: "Support Executive",
      salary: "₹30,000",
      email: "sneha@gmail.com",
      phone: "9876533333",
      status: "Active",
    },
  ]);
useEffect(() => {
  const fetchEmployees = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/employees"
      );

      setEmployees(response.data);
    } catch (error) {
      console.error("Failed to fetch employees:", error);
    }
  };

  fetchEmployees();
}, []);

  const filteredEmployees = employees.filter((emp) =>
    emp.name.toLowerCase().includes(search.toLowerCase())
  );
const addEmployee = async () => {
  try {
    const response = await axios.post(
      "http://localhost:5000/api/employees",
      employee
    );

    alert(response.data.message);
setEmployees((oldEmployees) => [
  ...oldEmployees,
  response.data.employee,
]);
    setShowModal(false);

    setEmployee({
      name: "",
      department: "",
      designation: "",
      salary: "",
      email: "",
      phone: "",
      status: "Active",
    });

  } catch (error) {
    alert("Failed to add employee");
  }
};

return (
   <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
    
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1 style={{ margin: 0, color: "#334155" }}>
                Employee Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage all employees
              </p>
            </div>
<button
  onClick={() => setShowModal(true)}
  style={{
    background: "#4F46E5",
    color: "#fff",
    border: "none",
    padding: "12px 22px",
    borderRadius: "8px",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: "10px",
  }}
>
            
              <FaPlus />
              Add Employee
            </button>
          </div>

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Employee..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                }}
              />
            </div>
          </div>

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Designation</th>
                  <th>Salary</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
  {filteredEmployees.map((emp) => (
    <tr
      key={emp.id}
      style={{
        textAlign: "center",
        borderBottom: "1px solid #E2E8F0",
      }}
    >
      <td style={{ padding: "15px" }}>{emp.id}</td>
      <td>{emp.name}</td>
      <td>{emp.department}</td>
      <td>{emp.designation}</td>
      <td>{emp.salary}</td>
      <td>{emp.email}</td>
      <td>{emp.phone}</td>

      <td>
        <span
          style={{
            background:
              emp.status === "Active"
                ? "#22C55E"
                : "#EF4444",
            color: "#fff",
            padding: "5px 12px",
            borderRadius: "20px",
            fontSize: "12px",
            fontWeight: "600",
          }}
        >
          {emp.status}
        </span>
      </td>

      <td>
        <button
          style={{
            background: "#F59E0B",
            color: "#fff",
            border: "none",
            padding: "8px 10px",
            borderRadius: "6px",
            marginRight: "8px",
            cursor: "pointer",
          }}
        >
          <FaEdit />
        </button>

        <button
          style={{
            background: "#EF4444",
            color: "#fff",
            border: "none",
            padding: "8px 10px",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          <FaTrash />
        </button>
      </td>
    </tr>
  ))}
</tbody>

            </table>
          </div>

          {/* Statistics */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background: "#fff",
                borderRadius: "12px",
                padding: "20px",
                textAlign: "center",
                boxShadow: "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <FaUsers
                size={35}
                color="#4F46E5"
              />
              <h3>Total Employees</h3>
              <h2>105</h2>
            </div>

            <div
              style={{
                background: "#fff",
                borderRadius: "12px",
                padding: "20px",
                textAlign: "center",
                boxShadow: "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <FaUserTie
                size={35}
                color="#22C55E"
              />
              <h3>Active Employees</h3>
              <h2>98</h2>
            </div>

            <div
              style={{
                background: "#fff",
                borderRadius: "12px",
                padding: "20px",
                textAlign: "center",
                boxShadow: "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <FaBuilding
                size={35}
                color="#F59E0B"
              />
              <h3>Departments</h3>
              <h2>8</h2>
            </div>

            <div
              style={{
                background: "#fff",
                borderRadius: "12px",
                padding: "20px",
                textAlign: "center",
                boxShadow: "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <FaMoneyBillWave
                size={35}
                color="#EF4444"
              />
              <h3>Monthly Salary</h3>
              <h2>₹18.5 L</h2>
            </div>
          </div>

        </div>
      </div>
   {showModal && (
  <div
    style={{
      position: "fixed",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <div
      style={{
        background: "#fff",
        padding: "30px",
        width: "450px",
        borderRadius: "10px",
      }}
    >
      <h2>Add Employee</h2>

      <input
        placeholder="Employee Name"
        value={employee.name}
        onChange={(e) =>
          setEmployee({
            ...employee,
            name: e.target.value,
          })
        }
        style={inputStyle}
      />

      <input
        placeholder="Department"
        value={employee.department}
        onChange={(e) =>
          setEmployee({
            ...employee,
            department: e.target.value,
          })
        }
        style={inputStyle}
      />

      <input
        placeholder="Designation"
        value={employee.designation}
        onChange={(e) =>
          setEmployee({
            ...employee,
            designation: e.target.value,
          })
        }
        style={inputStyle}
      />
      <input
  placeholder="Salary"
  value={employee.salary}
  onChange={(e) =>
    setEmployee({
      ...employee,
      salary: e.target.value,
    })
  }
  style={inputStyle}
/>

<input
  placeholder="Email"
  value={employee.email}
  onChange={(e) =>
    setEmployee({
      ...employee,
      email: e.target.value,
    })
  }
  style={inputStyle}
/>

<input
  placeholder="Phone"
  value={employee.phone}
  onChange={(e) =>
    setEmployee({
      ...employee,
      phone: e.target.value,
    })
  }
  style={inputStyle}
/>

<select
  value={employee.status}
  onChange={(e) =>
    setEmployee({
      ...employee,
      status: e.target.value,
    })
  }
  style={inputStyle}
>
  <option value="Active">Active</option>
  <option value="Inactive">Inactive</option>
</select>
<div
  style={{
    display: "flex",
    justifyContent: "space-between",
    marginTop: "20px",
  }}
>
  <button
    onClick={addEmployee}
    style={{
      background: "#4F46E5",
      color: "#fff",
      border: "none",
      padding: "10px 20px",
      borderRadius: "8px",
      cursor: "pointer",
    }}
  >
    Save
  </button>

  <button
    onClick={() => setShowModal(false)}
    style={{
      background: "#EF4444",
      color: "#fff",
      border: "none",
      padding: "10px 20px",
      borderRadius: "8px",
      cursor: "pointer",
    }}
  >
    Close
  </button>
</div>
      
    </div>
  </div>
)}
    </div>
);
}
const inputStyle = {
  width: "100%",
  padding: "10px",
  marginBottom: "15px",
  border: "1px solid #CBD5E1",
  borderRadius: "6px",
};
export default Employees;