
import { useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaCloudUploadAlt,
  FaFileAlt,
  FaCheckCircle,
  FaTrash,
  FaSearch,
  FaDownload,
} from "react-icons/fa";

function Upload() {
  const [file, setFile] = useState(null);
  const [uploaded, setUploaded] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");

  const [uploadedFiles, setUploadedFiles] = useState([]);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];

    if (!selectedFile) return;

    setFile(selectedFile);
    setUploaded(false);
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a file first.");
      return;
    }

    try {
      setUploading(true);

      const formData = new FormData();
      formData.append("file", file);

      // Backend API
      const response = await axios.post(
        "http://localhost:5000/api/upload",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      const newFile = {
        id: response.data.file?.id || Date.now(),
        name: response.data.file?.name || file.name,
        size: response.data.file?.size || formatFileSize(file.size),
        type: response.data.file?.type || file.type,
        date:
          response.data.file?.date ||
          new Date().toLocaleDateString("en-IN"),
      };

      setUploadedFiles((prev) => [newFile, ...prev]);

      setUploaded(true);
      setFile(null);

      // Reset file input
      document.getElementById("fileInput").value = "";

      alert("File uploaded successfully!");
    } catch (error) {
      console.error("Upload Error:", error);

      // If backend is not connected, show error
      alert(
        error.response?.data?.message ||
          "File upload failed. Please check backend server."
      );
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this file?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(`http://localhost:5000/api/upload/${id}`);

      setUploadedFiles((prev) =>
        prev.filter((file) => file.id !== id)
      );

      alert("File deleted successfully!");
    } catch (error) {
      console.error("Delete Error:", error);

      // Remove from frontend even if backend delete is not available
      setUploadedFiles((prev) =>
        prev.filter((file) => file.id !== id)
      );

      alert("File removed from the list.");
    }
  };

  const handleDownload = (file) => {
    if (file.url) {
      window.open(file.url, "_blank");
      return;
    }

    alert("Download link is not available for this file.");
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return "0 KB";

    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));

    return (
      Math.round(bytes / Math.pow(1024, i), 2) +
      " " +
      sizes[i]
    );
  };

  const filteredFiles = uploadedFiles.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <main style={{ padding: "30px" }}>
          {/* Header */}

          <div style={{ marginBottom: "25px" }}>
            <h1
              style={{
                color: "#1E293B",
                marginBottom: "5px",
              }}
            >
              Upload Files
            </h1>

            <p
              style={{
                color: "#64748B",
                marginTop: 0,
              }}
            >
              Upload customer, employee or business documents
            </p>
          </div>

          {/* Upload Card */}

          <div
            style={{
              background: "#FFFFFF",
              padding: "40px",
              borderRadius: "15px",
              maxWidth: "700px",
              boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
              textAlign: "center",
              marginBottom: "30px",
            }}
          >
            <FaCloudUploadAlt
              size={70}
              color="#4F46E5"
            />

            <h2
              style={{
                color: "#334155",
                marginBottom: "8px",
              }}
            >
              Select a File
            </h2>

            <p
              style={{
                color: "#64748B",
                marginBottom: "20px",
              }}
            >
              PDF, Excel, Word, CSV or image files
            </p>

            {/* File Input */}

            <input
              id="fileInput"
              type="file"
              onChange={handleFileChange}
              accept=".pdf,.xls,.xlsx,.doc,.docx,.csv,.png,.jpg,.jpeg"
              style={{
                marginTop: "10px",
                marginBottom: "20px",
              }}
            />

            {/* Selected File */}

            {file && (
              <div
                style={{
                  background: "#F1F5F9",
                  padding: "15px",
                  borderRadius: "8px",
                  marginBottom: "20px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "10px",
                }}
              >
                <FaFileAlt color="#4F46E5" />

                <span
                  style={{
                    color: "#334155",
                    fontWeight: "600",
                  }}
                >
                  {file.name}
                </span>

                <span
                  style={{
                    color: "#64748B",
                    fontSize: "13px",
                  }}
                >
                  ({formatFileSize(file.size)})
                </span>
              </div>
            )}

            {/* Upload Button */}

            <button
              onClick={handleUpload}
              disabled={uploading}
              style={{
                background: uploading
                  ? "#94A3B8"
                  : "#4F46E5",
                color: "#FFFFFF",
                border: "none",
                padding: "12px 25px",
                borderRadius: "8px",
                cursor: uploading
                  ? "not-allowed"
                  : "pointer",
                fontWeight: "600",
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <FaCloudUploadAlt />

              {uploading
                ? "Uploading..."
                : "Upload File"}
            </button>

            {/* Success Message */}

            {uploaded && (
              <div
                style={{
                  marginTop: "20px",
                  color: "#166534",
                  background: "#DCFCE7",
                  padding: "12px",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "8px",
                }}
              >
                <FaCheckCircle />
                File uploaded successfully!
              </div>
            )}
          </div>

          {/* Uploaded Files */}

          <div
            style={{
              background: "#FFFFFF",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
            }}
          >
            {/* Section Header */}

            <div
              style={{
                padding: "20px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                borderBottom: "1px solid #E2E8F0",
              }}
            >
              <div>
                <h2
                  style={{
                    margin: 0,
                    color: "#334155",
                  }}
                >
                  Uploaded Files
                </h2>

                <p
                  style={{
                    margin: "5px 0 0",
                    color: "#64748B",
                  }}
                >
                  Manage uploaded documents
                </p>
              </div>

              {/* Search */}

              <div
                style={{
                  position: "relative",
                  width: "300px",
                }}
              >
                <FaSearch
                  style={{
                    position: "absolute",
                    left: "14px",
                    top: "13px",
                    color: "#64748B",
                  }}
                />

                <input
                  type="text"
                  placeholder="Search files..."
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                  style={{
                    width: "100%",
                    padding: "11px 15px 11px 40px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                    outline: "none",
                    boxSizing: "border-box",
                  }}
                />
              </div>
            </div>

            {/* Table */}

            {filteredFiles.length > 0 ? (
              <div style={{ overflowX: "auto" }}>
                <table
                  style={{
                    width: "100%",
                    borderCollapse: "collapse",
                  }}
                >
                  <thead
                    style={{
                      background: "#4F46E5",
                      color: "#FFFFFF",
                    }}
                  >
                    <tr>
                      <th style={{ padding: "15px" }}>
                        File Name
                      </th>

                      <th>Type</th>

                      <th>Size</th>

                      <th>Uploaded Date</th>

                      <th>Status</th>

                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {filteredFiles.map((item) => (
                      <tr
                        key={item.id}
                        style={{
                          textAlign: "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td
                          style={{
                            padding: "15px",
                            fontWeight: "600",
                            color: "#334155",
                          }}
                        >
                          <FaFileAlt
                            color="#4F46E5"
                            style={{
                              marginRight: "8px",
                            }}
                          />

                          {item.name}
                        </td>

                        <td style={{ color: "#64748B" }}>
                          {item.type || "File"}
                        </td>

                        <td style={{ color: "#64748B" }}>
                          {item.size}
                        </td>

                        <td style={{ color: "#64748B" }}>
                          {item.date}
                        </td>

                        <td>
                          <span
                            style={{
                              background: "#DCFCE7",
                              color: "#166534",
                              padding: "5px 12px",
                              borderRadius: "20px",
                              fontSize: "12px",
                              fontWeight: "600",
                            }}
                          >
                            Uploaded
                          </span>
                        </td>

                        <td>
                          <button
                            onClick={() =>
                              handleDownload(item)
                            }
                            style={{
                              background: "#3B82F6",
                              color: "#FFFFFF",
                              border: "none",
                              padding: "8px 10px",
                              borderRadius: "6px",
                              marginRight: "8px",
                              cursor: "pointer",
                            }}
                            title="Download"
                          >
                            <FaDownload />
                          </button>

                          <button
                            onClick={() =>
                              handleDelete(item.id)
                            }
                            style={{
                              background: "#EF4444",
                              color: "#FFFFFF",
                              border: "none",
                              padding: "8px 10px",
                              borderRadius: "6px",
                              cursor: "pointer",
                            }}
                            title="Delete"
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div
                style={{
                  padding: "50px",
                  textAlign: "center",
                  color: "#64748B",
                }}
              >
                <FaFileAlt
                  size={40}
                  color="#CBD5E1"
                />

                <p>
                  {search
                    ? "No files found."
                    : "No files uploaded yet."}
                </p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Upload;