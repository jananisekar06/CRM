
import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaSave,
  FaBuilding,
  FaPalette,
  FaEnvelope,
  FaLock,
  FaUserCircle,
} from "react-icons/fa";

function Settings() {
  const [companyName, setCompanyName] = useState("ABC CRM Solutions");
  const [theme, setTheme] = useState("Light");
  const [smtpHost, setSmtpHost] = useState("smtp.gmail.com");
  const [smtpPort, setSmtpPort] = useState("587");
  const [email, setEmail] = useState("admin@company.com");

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* Header */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "30px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Settings
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage company configuration
              </p>
            </div>

            <button
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <FaSave />
              Save Settings
            </button>
          </div>

          {/* Summary Cards */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(5,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaBuilding size={28} color="#4F46E5" />
              <h3>Company</h3>
              <h2>Configured</h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaPalette size={28} color="#16A34A" />
              <h3>Theme</h3>
              <h2>Light</h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaEnvelope size={28} color="#2563EB" />
              <h3>SMTP</h3>
              <h2>Connected</h2>
            </div>

            <div
              style={{
                background: "#FEF3C7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaLock size={28} color="#D97706" />
              <h3>Password</h3>
              <h2>Secure</h2>
            </div>

            <div
              style={{
                background: "#FCE7F3",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaUserCircle size={28} color="#DB2777" />
              <h3>Profile</h3>
              <h2>100%</h2>
            </div>
          </div>

          {/* Company Settings */}

          <div
            style={{
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Company Information
            </h2>

            <div style={{ marginTop: "20px" }}>
              <label>Company Name</label>

              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  borderRadius: "8px",
                  border: "1px solid #CBD5E1",
                }}
              />

              <label>Company Logo</label>

              <input
                type="file"
                style={{
                  width: "100%",
                  marginTop: "10px",
                }}
              />
            </div>
          </div>
                    {/* Theme Settings */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>Theme Settings</h2>

            <div style={{ marginTop: "20px" }}>
              <label>Select Theme</label>

              <select
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  borderRadius: "8px",
                  border: "1px solid #CBD5E1",
                }}
              >
                <option>Light</option>
                <option>Dark</option>
                <option>Blue</option>
                <option>Green</option>
              </select>
            </div>
          </div>

          {/* SMTP Configuration */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              SMTP Configuration
            </h2>

            <div style={{ marginTop: "20px" }}>

              <label>SMTP Host</label>

              <input
                type="text"
                value={smtpHost}
                onChange={(e) => setSmtpHost(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>SMTP Port</label>

              <input
                type="text"
                value={smtpPort}
                onChange={(e) => setSmtpPort(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>Email Address</label>

              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>SMTP Username</label>

              <input
                type="text"
                placeholder="Enter SMTP Username"
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>SMTP Password</label>

              <input
                type="password"
                placeholder="Enter SMTP Password"
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />
            </div>
          </div>
                    {/* Password Settings */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Change Password
            </h2>

            <div style={{ marginTop: "20px" }}>

              <label>Current Password</label>

              <input
                type="password"
                placeholder="Enter Current Password"
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>New Password</label>

              <input
                type="password"
                placeholder="Enter New Password"
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  marginBottom: "20px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />

              <label>Confirm Password</label>

              <input
                type="password"
                placeholder="Confirm Password"
                style={{
                  width: "100%",
                  padding: "12px",
                  marginTop: "8px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                }}
              />
            </div>
          </div>

          {/* Profile Settings */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Profile Information
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2,1fr)",
                gap: "20px",
                marginTop: "20px",
              }}
            >

              <div>
                <label>Full Name</label>
                <input
                  type="text"
                  defaultValue="Admin User"
                  style={{
                    width: "100%",
                    padding: "12px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

              <div>
                <label>Email Address</label>
                <input
                  type="email"
                  defaultValue="admin@company.com"
                  style={{
                    width: "100%",
                    padding: "12px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

              <div>
                <label>Mobile Number</label>
                <input
                  type="text"
                  defaultValue="+91 9876543210"
                  style={{
                    width: "100%",
                    padding: "12px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

              <div>
                <label>Department</label>
                <input
                  type="text"
                  defaultValue="Administration"
                  style={{
                    width: "100%",
                    padding: "12px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

              <div>
                <label>Designation</label>
                <input
                  type="text"
                  defaultValue="System Administrator"
                  style={{
                    width: "100%",
                    padding: "12px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

              <div>
                <label>Profile Photo</label>
                <input
                  type="file"
                  style={{
                    width: "100%",
                    padding: "10px",
                    marginTop: "8px",
                    border: "1px solid #CBD5E1",
                    borderRadius: "8px",
                  }}
                />
              </div>

            </div>
          </div>
                    {/* Action Buttons */}

          <div
            style={{
              marginTop: "35px",
              display: "flex",
              justifyContent: "center",
              gap: "20px",
            }}
          >
            <button
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 30px",
                borderRadius: "8px",
                cursor: "pointer",
                fontSize: "16px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaSave />
              Save Settings
            </button>


            <button
              style={{
                background: "#EF4444",
                color: "#fff",
                border: "none",
                padding: "12px 30px",
                borderRadius: "8px",
                cursor: "pointer",
                fontSize: "16px",
              }}
            >
              Reset
            </button>
          </div>


          {/* Settings Activity */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >

            <h2 style={{ color:"#334155" }}>
              Recent Settings Activity
            </h2>


            <table
              style={{
                width:"100%",
                borderCollapse:"collapse",
                marginTop:"20px"
              }}
            >

              <thead
                style={{
                  background:"#4F46E5",
                  color:"#fff"
                }}
              >

                <tr>
                  <th style={{padding:"15px"}}>
                    Activity
                  </th>

                  <th>
                    User
                  </th>

                  <th>
                    Date
                  </th>

                  <th>
                    Status
                  </th>

                </tr>

              </thead>


              <tbody>


                <tr style={{textAlign:"center"}}>

                  <td style={{padding:"15px"}}>
                    Company Logo Updated
                  </td>

                  <td>
                    Admin
                  </td>

                  <td>
                    03-08-2026
                  </td>

                  <td>

                    <span
                      style={{
                        background:"#22C55E",
                        color:"#fff",
                        padding:"5px 12px",
                        borderRadius:"20px"
                      }}
                    >
                      Completed
                    </span>

                  </td>

                </tr>



                <tr style={{textAlign:"center"}}>

                  <td style={{padding:"15px"}}>
                    SMTP Configuration Changed
                  </td>

                  <td>
                    Admin
                  </td>

                  <td>
                    02-08-2026
                  </td>

                  <td>

                    <span
                      style={{
                        background:"#3B82F6",
                        color:"#fff",
                        padding:"5px 12px",
                        borderRadius:"20px"
                      }}
                    >
                      Updated
                    </span>

                  </td>

                </tr>



                <tr style={{textAlign:"center"}}>

                  <td style={{padding:"15px"}}>
                    Password Changed
                  </td>

                  <td>
                    Admin
                  </td>

                  <td>
                    01-08-2026
                  </td>

                  <td>

                    <span
                      style={{
                        background:"#F59E0B",
                        color:"#fff",
                        padding:"5px 12px",
                        borderRadius:"20px"
                      }}
                    >
                      Security
                    </span>

                  </td>

                </tr>


              </tbody>

            </table>

          </div>


        </div>
      </div>
    </div>
  );
}

export default Settings;