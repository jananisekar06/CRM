import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaBullhorn,
} from "react-icons/fa";

function CampaignManagement() {
  const [search, setSearch] = useState("");
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [campaignData, setCampaignData] = useState({
    name: "",
    channel: "Email",
    sent: 0,
    opened: 0,
    clicked: 0,
    status: "Scheduled",
  });

  const API_URL = "http://localhost:5000/api/campaigns";

  // =========================
  // FETCH CAMPAIGNS
  // =========================

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    try {
      const response = await axios.get(API_URL);

      setCampaigns(
        Array.isArray(response.data) ? response.data : []
      );
    } catch (error) {
      console.error("Campaign Fetch Error:", error);
      setCampaigns([]);
    }
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setCampaignData((prev) => ({
      ...prev,
      [name]:
        name === "sent" ||
        name === "opened" ||
        name === "clicked"
          ? Number(value)
          : value,
    }));
  };

  // =========================
  // RESET
  // =========================

  const handleReset = () => {
    setCampaignData({
      name: "",
      channel: "Email",
      sent: 0,
      opened: 0,
      clicked: 0,
      status: "Scheduled",
    });

    setEditingId(null);
  };

  // =========================
  // CREATE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!campaignData.name.trim()) {
      alert("Please enter campaign name");
      return;
    }

    try {
      setLoading(true);

      if (editingId) {
        const response = await axios.put(
          `${API_URL}/${editingId}`,
          campaignData
        );

        setCampaigns((prev) =>
          prev.map((campaign) =>
            campaign.id === editingId
              ? response.data.campaign
              : campaign
          )
        );

        alert(
          response.data.message ||
            "Campaign updated successfully"
        );
      } else {
        const response = await axios.post(
          API_URL,
          campaignData
        );

        if (response.data.campaign) {
          setCampaigns((prev) => [
            ...prev,
            response.data.campaign,
          ]);
        }

        alert(
          response.data.message ||
            "Campaign created successfully"
        );
      }

      handleReset();
    } catch (error) {
      console.error("Campaign Save Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to save campaign"
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // EDIT
  // =========================

  const handleEdit = (campaign) => {
    setEditingId(campaign.id);

    setCampaignData({
      name: campaign.name || "",
      channel: campaign.channel || "Email",
      sent: Number(campaign.sent) || 0,
      opened: Number(campaign.opened) || 0,
      clicked: Number(campaign.clicked) || 0,
      status: campaign.status || "Scheduled",
    });

    document
      .getElementById("campaign-form")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this campaign?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await axios.delete(
        `${API_URL}/${id}`
      );

      setCampaigns((prev) =>
        prev.filter((campaign) => campaign.id !== id)
      );

      alert(
        response.data.message ||
          "Campaign deleted successfully"
      );

      if (editingId === id) {
        handleReset();
      }
    } catch (error) {
      console.error("Campaign Delete Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete campaign"
      );
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredCampaigns = campaigns.filter((campaign) => {
    const name = String(
      campaign?.name || ""
    ).toLowerCase();

    const channel = String(
      campaign?.channel || ""
    ).toLowerCase();

    const searchText = search.toLowerCase();

    return (
      name.includes(searchText) ||
      channel.includes(searchText)
    );
  });

  // =========================
  // UI
  // =========================

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Campaign Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage marketing campaigns
              </p>
            </div>

            <button
              onClick={() => {
                handleReset();

                document
                  .getElementById("campaign-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  });
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Create Campaign
            </button>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Campaign..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Campaign ID
                  </th>
                  <th>Name</th>
                  <th>Channel</th>
                  <th>Sent</th>
                  <th>Opened</th>
                  <th>Clicked</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredCampaigns.map(
                  (campaign, index) => (
                    <tr
                      key={
                        campaign?.id || index
                      }
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {campaign?.id ||
                          `CMP${String(
                            index + 1
                          ).padStart(3, "0")}`}
                      </td>

                      <td>
                        {campaign?.name || "-"}
                      </td>

                      <td>
                        {campaign?.channel || "-"}
                      </td>

                      <td>
                        {campaign?.sent || 0}
                      </td>

                      <td>
                        {campaign?.opened || 0}
                      </td>

                      <td>
                        {campaign?.clicked || 0}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              campaign?.status ===
                              "Completed"
                                ? "#22C55E"
                                : campaign?.status ===
                                  "Running"
                                ? "#3B82F6"
                                : "#F59E0B",
                            color: "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize: "12px",
                          }}
                        >
                          {campaign?.status ||
                            "-"}
                        </span>
                      </td>

                      <td>
                        <button
                          onClick={() =>
                            handleEdit(
                              campaign
                            )
                          }
                          style={{
                            background:
                              "#F59E0B",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            marginRight:
                              "8px",
                            cursor:
                              "pointer",
                          }}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(
                              campaign.id
                            )
                          }
                          style={{
                            background:
                              "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            cursor:
                              "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  )
                )}

                {filteredCampaigns.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="8"
                      style={{
                        padding: "25px",
                        textAlign:
                          "center",
                        color: "#64748B",
                      }}
                    >
                      No campaigns found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= ADD / EDIT FORM ================= */}

          <div
            id="campaign-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Update Campaign"
                : "Create New Campaign"}
            </h2>

            <form onSubmit={handleSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2,1fr)",
                  gap: "20px",
                }}
              >
                {/* Campaign Name */}

                <div>
                  <label>
                    Campaign Name
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={
                      campaignData.name
                    }
                    onChange={handleChange}
                    placeholder="Summer Offer"
                    style={inputStyle}
                  />
                </div>

                {/* Channel */}

                <div>
                  <label>Channel</label>

                  <select
                    name="channel"
                    value={
                      campaignData.channel
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Email">
                      Email
                    </option>

                    <option value="SMS">
                      SMS
                    </option>

                    <option value="WhatsApp">
                      WhatsApp
                    </option>
                  </select>
                </div>

                {/* Sent */}

                <div>
                  <label>
                    Sent
                  </label>

                  <input
                    type="number"
                    name="sent"
                    min="0"
                    value={
                      campaignData.sent
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  />
                </div>

                {/* Opened */}

                <div>
                  <label>
                    Opened
                  </label>

                  <input
                    type="number"
                    name="opened"
                    min="0"
                    value={
                      campaignData.opened
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  />
                </div>

                {/* Clicked */}

                <div>
                  <label>
                    Clicked
                  </label>

                  <input
                    type="number"
                    name="clicked"
                    min="0"
                    value={
                      campaignData.clicked
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  />
                </div>

                {/* Status */}

                <div>
                  <label>Status</label>

                  <select
                    name="status"
                    value={
                      campaignData.status
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Scheduled">
                      Scheduled
                    </option>

                    <option value="Running">
                      Running
                    </option>

                    <option value="Completed">
                      Completed
                    </option>

                    <option value="Cancelled">
                      Cancelled
                    </option>
                  </select>
                </div>
              </div>

              {/* Buttons */}

              <div
                style={{
                  display: "flex",
                  justifyContent:
                    "flex-end",
                  gap: "15px",
                  marginTop: "25px",
                }}
              >
                <button
                  type="button"
                  onClick={handleReset}
                  style={{
                    background:
                      "#E5E7EB",
                    color: "#334155",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background:
                      loading
                        ? "#9CA3AF"
                        : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius: "8px",
                    cursor:
                      loading
                        ? "not-allowed"
                        : "pointer",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingId
                    ? "Update Campaign"
                    : "Save Campaign"}
                </button>
              </div>
            </form>
          </div>

          {/* ================= SUMMARY CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaBullhorn
                size={30}
                color="#4F46E5"
              />

              <h3>Total Campaigns</h3>

              <h2>
                {campaigns.length}
              </h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Total Sent</h3>

              <h2>
                {campaigns.reduce(
                  (sum, c) =>
                    sum +
                    (Number(c.sent) ||
                      0),
                  0
                )}
              </h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Total Opened</h3>

              <h2>
                {campaigns.reduce(
                  (sum, c) =>
                    sum +
                    (Number(
                      c.opened
                    ) || 0),
                  0
                )}
              </h2>
            </div>

            <div
              style={{
                background: "#FEF3C7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Total Clicked</h3>

              <h2>
                {campaigns.reduce(
                  (sum, c) =>
                    sum +
                    (Number(
                      c.clicked
                    ) || 0),
                  0
                )}
              </h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default CampaignManagement;