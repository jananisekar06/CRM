
import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPhone,
  FaCalendarAlt,
  FaClock,
  FaPlus,
  FaSearch,
  FaClipboardCheck,
  FaUserTie,
  FaEdit,
  FaTrash,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/followups";

function FollowUp() {
  const [search, setSearch] = useState("");
  const [followUps, setFollowUps] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const emptyForm = {
    customer: "",
    contact: "",
    phone: "",
    employee: "",
    date: "",
    time: "",
    priority: "High",
    status: "Scheduled",
    notes: "",
  };

  const [followUpData, setFollowUpData] = useState(emptyForm);

  // =========================
  // FETCH FOLLOW-UPS
  // =========================

  useEffect(() => {
    fetchFollowUps();
  }, []);

  const fetchFollowUps = async () => {
    try {
      const response = await axios.get(API_URL);

      console.log("Follow-up Data:", response.data);

      setFollowUps(
        Array.isArray(response.data) ? response.data : []
      );
    } catch (error) {
      console.error("Follow-up Fetch Error:", error);
      setFollowUps([]);
    }
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFollowUpData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // CREATE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !followUpData.customer ||
      !followUpData.contact ||
      !followUpData.phone ||
      !followUpData.employee ||
      !followUpData.date ||
      !followUpData.time
    ) {
      alert("Please fill all required fields");
      return;
    }

    try {
      setLoading(true);

      // UPDATE
      if (editingId) {
        const response = await axios.put(
          `${API_URL}/${editingId}`,
          followUpData
        );

        setFollowUps((prev) =>
          prev.map((item) =>
            item.id === editingId
              ? response.data.followUp
              : item
          )
        );

        alert(
          response.data.message ||
            "Follow-up updated successfully"
        );

        setEditingId(null);
        handleReset();
        return;
      }

      // CREATE
      const response = await axios.post(
        API_URL,
        followUpData
      );

      console.log("Follow-up Created:", response.data);

      if (response.data.followUp) {
        setFollowUps((prev) => [
          ...prev,
          response.data.followUp,
        ]);
      } else {
        await fetchFollowUps();
      }

      alert(
        response.data.message ||
          "Follow-up created successfully"
      );

      handleReset();
    } catch (error) {
      console.error("Follow-up Save Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to save follow-up"
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // EDIT
  // =========================

  const handleEdit = (item) => {
    setEditingId(item.id);

    setFollowUpData({
      customer: item.customer || "",
      contact: item.contact || "",
      phone: item.phone || "",
      employee: item.employee || "",
      date: item.date || "",
      time: item.time || "",
      priority: item.priority || "High",
      status: item.status || "Scheduled",
      notes: item.notes || "",
    });

    document
      .getElementById("followup-form")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this follow-up?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await axios.delete(
        `${API_URL}/${id}`
      );

      setFollowUps((prev) =>
        prev.filter((item) => item.id !== id)
      );

      alert(
        response.data.message ||
          "Follow-up deleted successfully"
      );

      if (editingId === id) {
        setEditingId(null);
        handleReset();
      }
    } catch (error) {
      console.error("Follow-up Delete Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete follow-up"
      );
    }
  };

  // =========================
  // RESET
  // =========================

  const handleReset = () => {
    setFollowUpData(emptyForm);
    setEditingId(null);
  };

  // =========================
  // SEARCH
  // =========================

  const filteredFollowUps = followUps.filter((item) => {
    const customer = String(
      item?.customer || ""
    ).toLowerCase();

    const contact = String(
      item?.contact || ""
    ).toLowerCase();

    const employee = String(
      item?.employee || ""
    ).toLowerCase();

    const phone = String(
      item?.phone || ""
    ).toLowerCase();

    const searchText = search.toLowerCase();

    return (
      customer.includes(searchText) ||
      contact.includes(searchText) ||
      employee.includes(searchText) ||
      phone.includes(searchText)
    );
  });

  // =========================
  // DASHBOARD COUNTS
  // =========================

  const today = new Date()
    .toISOString()
    .split("T")[0];

  const todayFollowUps = followUps.filter(
    (item) => item?.date === today
  ).length;

  const completedCount = followUps.filter(
    (item) => item?.status === "Completed"
  ).length;

  const pendingCount = followUps.filter(
    (item) => item?.status === "Pending"
  ).length;

  const upcomingCount = followUps.filter(
    (item) => item?.status === "Scheduled"
  ).length;

  const assignedStaffCount = new Set(
    followUps
      .map((item) => item?.employee)
      .filter(Boolean)
  ).size;

  // =========================
  // UI
  // =========================

  return (
    <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Follow-up Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Schedule and manage customer follow-ups
              </p>
            </div>

            <button
              onClick={() => {
                handleReset();

                document
                  .getElementById("followup-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  });
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              New Follow-up
            </button>
          </div>

          {/* ================= DASHBOARD CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(5, 1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={cardStyle("#EEF2FF")}>
              <FaCalendarAlt
                size={30}
                color="#4F46E5"
              />
              <h3>Today's Follow-ups</h3>
              <h2>{todayFollowUps}</h2>
            </div>

            <div style={cardStyle("#DCFCE7")}>
              <FaPhone
                size={30}
                color="#16A34A"
              />
              <h3>Completed</h3>
              <h2>{completedCount}</h2>
            </div>

            <div style={cardStyle("#FEF3C7")}>
              <FaClock
                size={30}
                color="#D97706"
              />
              <h3>Pending</h3>
              <h2>{pendingCount}</h2>
            </div>

            <div style={cardStyle("#DBEAFE")}>
              <FaClipboardCheck
                size={30}
                color="#2563EB"
              />
              <h3>Upcoming</h3>
              <h2>{upcomingCount}</h2>
            </div>

            <div style={cardStyle("#FCE7F3")}>
              <FaUserTie
                size={30}
                color="#DB2777"
              />
              <h3>Assigned Staff</h3>
              <h2>{assignedStaffCount}</h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search customer, contact, employee..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding:
                    "12px 15px 12px 45px",
                  borderRadius: "8px",
                  border:
                    "1px solid #CBD5E1",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
                minWidth: "1100px",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    ID
                  </th>
                  <th>Customer</th>
                  <th>Contact Person</th>
                  <th>Phone</th>
                  <th>Assigned To</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredFollowUps.map(
                  (item, index) => (
                    <tr
                      key={
                        item?.id || index
                      }
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {item?.id ||
                          `FU${String(
                            index + 1
                          ).padStart(
                            3,
                            "0"
                          )}`}
                      </td>

                      <td>
                        {item?.customer ||
                          "-"}
                      </td>

                      <td>
                        {item?.contact ||
                          "-"}
                      </td>

                      <td>
                        {item?.phone ||
                          "-"}
                      </td>

                      <td>
                        {item?.employee ||
                          "-"}
                      </td>

                      <td>
                        {item?.date ||
                          "-"}
                      </td>

                      <td>
                        {item?.time ||
                          "-"}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item?.priority ===
                              "High"
                                ? "#EF4444"
                                : item?.priority ===
                                  "Medium"
                                ? "#F59E0B"
                                : "#22C55E",
                            color: "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize:
                              "12px",
                          }}
                        >
                          {item?.priority ||
                            "-"}
                        </span>
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item?.status ===
                              "Completed"
                                ? "#22C55E"
                                : item?.status ===
                                  "Scheduled"
                                ? "#3B82F6"
                                : item?.status ===
                                  "Cancelled"
                                ? "#EF4444"
                                : "#F59E0B",
                            color: "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize:
                              "12px",
                          }}
                        >
                          {item?.status ||
                            "-"}
                        </span>
                      </td>

                      {/* ACTION */}

                      <td>
                        <button
                          onClick={() =>
                            handleEdit(item)
                          }
                          style={{
                            background:
                              "#F59E0B",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            cursor:
                              "pointer",
                            marginRight:
                              "8px",
                          }}
                          title="Edit"
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(
                              item.id
                            )
                          }
                          style={{
                            background:
                              "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            cursor:
                              "pointer",
                          }}
                          title="Delete"
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  )
                )}

                {filteredFollowUps.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="10"
                      style={{
                        padding: "25px",
                        textAlign:
                          "center",
                        color:
                          "#64748B",
                      }}
                    >
                      No follow-up records
                      found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= FORM ================= */}

          <div
            id="followup-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Edit Follow-up"
                : "Schedule New Follow-up"}
            </h2>

            <form
              onSubmit={handleSubmit}
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2, 1fr)",
                  gap: "20px",
                }}
              >
                <div>
                  <label>
                    Customer Name
                  </label>

                  <input
                    type="text"
                    name="customer"
                    value={
                      followUpData.customer
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter Customer Name"
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Contact Person
                  </label>

                  <input
                    type="text"
                    name="contact"
                    value={
                      followUpData.contact
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Enter Contact Person"
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Phone Number
                  </label>

                  <input
                    type="text"
                    name="phone"
                    value={
                      followUpData.phone
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="+91 9876543210"
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Assigned Employee
                  </label>

                  <input
                    type="text"
                    name="employee"
                    value={
                      followUpData.employee
                    }
                    onChange={
                      handleChange
                    }
                    placeholder="Employee Name"
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Follow-up Date
                  </label>

                  <input
                    type="date"
                    name="date"
                    value={
                      followUpData.date
                    }
                    onChange={
                      handleChange
                    }
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Follow-up Time
                  </label>

                  <input
                    type="time"
                    name="time"
                    value={
                      followUpData.time
                    }
                    onChange={
                      handleChange
                    }
                    style={
                      inputStyle
                    }
                  />
                </div>

                <div>
                  <label>
                    Priority
                  </label>

                  <select
                    name="priority"
                    value={
                      followUpData.priority
                    }
                    onChange={
                      handleChange
                    }
                    style={
                      inputStyle
                    }
                  >
                    <option value="High">
                      High
                    </option>

                    <option value="Medium">
                      Medium
                    </option>

                    <option value="Low">
                      Low
                    </option>
                  </select>
                </div>

                <div>
                  <label>
                    Status
                  </label>

                  <select
                    name="status"
                    value={
                      followUpData.status
                    }
                    onChange={
                      handleChange
                    }
                    style={
                      inputStyle
                    }
                  >
                    <option value="Scheduled">
                      Scheduled
                    </option>

                    <option value="Pending">
                      Pending
                    </option>

                    <option value="Completed">
                      Completed
                    </option>

                    <option value="Cancelled">
                      Cancelled
                    </option>
                  </select>
                </div>

                <div
                  style={{
                    gridColumn:
                      "1 / span 2",
                  }}
                >
                  <label>
                    Call Notes
                  </label>

                  <textarea
                    name="notes"
                    value={
                      followUpData.notes
                    }
                    onChange={
                      handleChange
                    }
                    rows="5"
                    placeholder="Enter discussion notes..."
                    style={{
                      ...inputStyle,
                      resize:
                        "vertical",
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  marginTop: "25px",
                  display: "flex",
                  justifyContent:
                    "flex-end",
                  gap: "15px",
                }}
              >
                <button
                  type="button"
                  onClick={
                    handleReset
                  }
                  style={{
                    background:
                      "#E5E7EB",
                    color:
                      "#334155",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius:
                      "8px",
                    cursor:
                      "pointer",
                  }}
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background:
                      loading
                        ? "#9CA3AF"
                        : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius:
                      "8px",
                    cursor:
                      loading
                        ? "not-allowed"
                        : "pointer",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingId
                    ? "Update Follow-up"
                    : "Save Follow-up"}
                </button>
              </div>
            </form>
          </div>

          {/* ================= RECENT ACTIVITY ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
              }}
            >
              Recent Follow-up Activity
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse:
                  "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th
                    style={{
                      padding: "15px",
                    }}
                  >
                    Date
                  </th>

                  <th>
                    Activity
                  </th>

                  <th>
                    Employee
                  </th>

                  <th>
                    Status
                  </th>
                </tr>
              </thead>

              <tbody>
                {followUps
                  .slice(-3)
                  .reverse()
                  .map(
                    (
                      item,
                      index
                    ) => (
                      <tr
                        key={
                          item?.id ||
                          index
                        }
                        style={{
                          textAlign:
                            "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td
                          style={{
                            padding:
                              "15px",
                          }}
                        >
                          {item?.date ||
                            "-"}
                        </td>

                        <td>
                          {item?.notes ||
                            "Follow-up scheduled"}
                        </td>

                        <td>
                          {item?.employee ||
                            "-"}
                        </td>

                        <td>
                          <span
                            style={{
                              background:
                                item?.status ===
                                "Completed"
                                  ? "#22C55E"
                                  : item?.status ===
                                    "Scheduled"
                                  ? "#3B82F6"
                                  : item?.status ===
                                    "Cancelled"
                                  ? "#EF4444"
                                  : "#F59E0B",
                              color:
                                "#fff",
                              padding:
                                "5px 12px",
                              borderRadius:
                                "20px",
                            }}
                          >
                            {item?.status ||
                              "-"}
                          </span>
                        </td>
                      </tr>
                    )
                  )}

                {followUps.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="4"
                      style={{
                        padding:
                          "20px",
                        textAlign:
                          "center",
                        color:
                          "#64748B",
                      }}
                    >
                      No recent activity
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================
// CARD STYLE
// =========================

const cardStyle = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

// =========================
// INPUT STYLE
// =========================

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default FollowUp;