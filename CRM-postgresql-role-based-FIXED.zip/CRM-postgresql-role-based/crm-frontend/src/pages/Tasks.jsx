import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch, FaCheckCircle, FaClock, FaExclamationCircle } from "react-icons/fa";

const emptyTask = { title: "", assignedTo: "", priority: "Medium", dueDate: "" };

function Tasks() {
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [task, setTask] = useState(emptyTask);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/tasks");
        setTasks(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };
    fetchTasks();
  }, []);

  const addTask = async () => {
    if (!task.title || !task.assignedTo || !task.dueDate) {
      alert("Please fill all task details");
      return;
    }
    try {
      const response = await axios.post("http://localhost:5000/api/tasks", task);
      setTasks((currentTasks) => [...currentTasks, response.data.task]);
      alert(response.data.message);
      setTask(emptyTask);
      setShowModal(false);
    } catch (error) {
      alert("Failed to add task");
    }
  };

  const filteredTasks = tasks.filter((item) => item.title.toLowerCase().includes(search.toLowerCase()));
  const completed = tasks.filter((item) => item.status === "Completed").length;
  const pending = tasks.filter((item) => item.status === "Pending").length;
  const highPriority = tasks.filter((item) => item.priority === "High").length;
  const setField = (field, value) => setTask({ ...task, [field]: value });

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1 }}>
        <Navbar />
        <main style={{ padding: "30px" }}>
          <div style={headerStyle}><div><h1 style={{ margin: 0, color: "#1E293B" }}>Task Management</h1><p style={{ color: "#64748B" }}>Manage and track employee tasks</p></div><button onClick={() => setShowModal(true)} style={addButtonStyle}><FaPlus /> Add Task</button></div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "20px", marginBottom: "25px" }}>
            <Card icon={<FaClock size={30} color="#4F46E5" />} title="Total Tasks" value={tasks.length} />
            <Card icon={<FaCheckCircle size={30} color="#22C55E" />} title="Completed" value={completed} />
            <Card icon={<FaClock size={30} color="#F59E0B" />} title="Pending" value={pending} />
            <Card icon={<FaExclamationCircle size={30} color="#EF4444" />} title="High Priority" value={highPriority} />
          </div>

          <div style={searchBoxStyle}><FaSearch color="#64748B" /><input type="text" placeholder="Search Tasks..." value={search} onChange={(event) => setSearch(event.target.value)} style={searchInputStyle} /></div>

          <div style={tableBoxStyle}><table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr style={{ background: "#4F46E5", color: "#fff" }}><th style={{ padding: "15px" }}>ID</th><th>Task</th><th>Assigned To</th><th>Priority</th><th>Due Date</th><th>Status</th></tr></thead><tbody>
            {filteredTasks.map((item) => <tr key={item.id} style={rowStyle}><td style={{ padding: "15px" }}>{item.id}</td><td>{item.title}</td><td>{item.assignedTo}</td><td><span style={{ ...badgeStyle, ...priorityStyle(item.priority) }}>{item.priority}</span></td><td>{item.dueDate}</td><td><span style={{ ...badgeStyle, ...statusStyle(item.status) }}>{item.status}</span></td></tr>)}
            {filteredTasks.length === 0 && <tr><td colSpan="6" style={{ padding: "30px", textAlign: "center", color: "#64748B" }}>No tasks found.</td></tr>}
          </tbody></table></div>
        </main>
      </div>

      {showModal && <div style={overlayStyle}><div style={modalStyle}><h2>Add Task</h2><input placeholder="Task Title" value={task.title} onChange={(event) => setField("title", event.target.value)} style={inputStyle} /><input placeholder="Assigned To" value={task.assignedTo} onChange={(event) => setField("assignedTo", event.target.value)} style={inputStyle} /><select value={task.priority} onChange={(event) => setField("priority", event.target.value)} style={inputStyle}><option value="High">High</option><option value="Medium">Medium</option><option value="Low">Low</option></select><input type="date" value={task.dueDate} onChange={(event) => setField("dueDate", event.target.value)} style={inputStyle} /><div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}><button onClick={addTask} style={saveButtonStyle}>Save</button><button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button></div></div></div>}
    </div>
  );
}

function Card({ icon, title, value }) {
  return <div style={cardStyle}>{icon}<p>{title}</p><h2>{value}</h2></div>;
}

const priorityStyle = (priority) => priority === "High" ? { background: "#FEE2E2", color: "#991B1B" } : priority === "Medium" ? { background: "#FEF3C7", color: "#92400E" } : { background: "#DCFCE7", color: "#166534" };
const statusStyle = (status) => status === "Completed" ? { background: "#DCFCE7", color: "#166534" } : { background: "#FEF3C7", color: "#92400E" };
const headerStyle = { display: "flex", justifyContent: "space-between", marginBottom: "25px" };
const addButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "12px 20px", borderRadius: "8px", cursor: "pointer", fontWeight: "600" };
const cardStyle = { background: "#fff", padding: "22px", borderRadius: "14px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const searchBoxStyle = { background: "#fff", padding: "15px 20px", borderRadius: "10px", display: "flex", gap: "12px", alignItems: "center", marginBottom: "20px" };
const searchInputStyle = { flex: 1, border: "none", outline: "none", fontSize: "14px" };
const tableBoxStyle = { background: "#fff", borderRadius: "14px", overflow: "hidden", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const rowStyle = { textAlign: "center", borderBottom: "1px solid #E2E8F0" };
const badgeStyle = { display: "inline-block", padding: "6px 12px", borderRadius: "20px", fontSize: "12px", fontWeight: "600" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", marginBottom: "15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Tasks;
