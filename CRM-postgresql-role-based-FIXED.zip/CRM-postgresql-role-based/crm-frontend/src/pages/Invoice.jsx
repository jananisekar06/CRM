import { useEffect, useState } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaPlus,
  FaSearch,
  FaEye,
  FaDownload,
  FaFileInvoiceDollar,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/invoices";

const emptyInvoice = {
  customer: "",
  gst: "",
  items: "",
  tax: "",
  total: "",
  status: "Pending",
};

function Invoice() {
  const [search, setSearch] = useState("");
  const [invoices, setInvoices] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [invoice, setInvoice] = useState(emptyInvoice);

  // =========================
  // FETCH INVOICES
  // =========================

  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      const response = await axios.get(API_URL);

      setInvoices(
        Array.isArray(response.data)
          ? response.data
          : response.data.invoices || []
      );
    } catch (error) {
      console.error("Error fetching invoices:", error);
      alert(
        "Backend is not running. Start the backend and refresh."
      );
    }
  };

  // =========================
  // CREATE INVOICE
  // =========================

  const createInvoice = async () => {
    if (
      !invoice.customer ||
      !invoice.gst ||
      !invoice.items ||
      !invoice.tax ||
      !invoice.total
    ) {
      alert("Please fill all invoice details");
      return;
    }

    try {
      const response = await axios.post(API_URL, {
        ...invoice,
        items: Number(invoice.items),
      });

      setInvoices((currentInvoices) => [
        ...currentInvoices,
        response.data.invoice,
      ]);

      alert(
        response.data.message ||
          "Invoice created successfully"
      );

      setInvoice(emptyInvoice);
      setShowModal(false);
    } catch (error) {
      console.error("Error creating invoice:", error);
      alert("Failed to create invoice");
    }
  };

  // =========================
  // SET FIELD
  // =========================

  const setField = (field, value) => {
    setInvoice((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // =========================
  // DOWNLOAD INVOICE PDF
  // =========================

  const handleDownload = (item) => {
    try {
      const doc = new jsPDF();

      const invoiceId = item.id || "INV000";
      const customer = item.customer || "N/A";
      const gst = item.gst || "N/A";
      const items = item.items || 0;
      const tax = item.tax || 0;
      const total = item.total || 0;
      const status = item.status || "Pending";

      const currentDate =
        new Date().toLocaleDateString("en-IN");

      // =========================
      // HEADER
      // =========================

      doc.setFontSize(24);
      doc.setFont("helvetica", "bold");
      doc.text("CRM SYSTEM", 20, 25);

      doc.setFontSize(18);
      doc.text("INVOICE", 150, 25);

      doc.setLineWidth(0.5);
      doc.line(20, 32, 190, 32);

      // =========================
      // INVOICE INFORMATION
      // =========================

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");

      doc.text(
        `Invoice Number: ${invoiceId}`,
        20,
        45
      );

      doc.text(
        `Invoice Date: ${currentDate}`,
        20,
        53
      );

      doc.text(
        `Status: ${status}`,
        20,
        61
      );

      // =========================
      // CUSTOMER INFORMATION
      // =========================

      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");

      doc.text("Bill To", 20, 78);

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");

      doc.text(
        `Customer Name: ${customer}`,
        20,
        88
      );

      doc.text(
        `GST Number: ${gst}`,
        20,
        96
      );

      // =========================
      // INVOICE TABLE
      // =========================

      doc.setFillColor(79, 70, 229);
      doc.setTextColor(255, 255, 255);

      doc.rect(20, 110, 170, 12, "F");

      doc.setFont("helvetica", "bold");

      doc.text("Description", 25, 118);
      doc.text("Quantity", 95, 118);
      doc.text("Tax", 125, 118);
      doc.text("Total", 160, 118);

      // =========================
      // TABLE DATA
      // =========================

      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");

      doc.rect(20, 122, 170, 15);

      doc.text("Products / Services", 25, 131);

      doc.text(String(items), 98, 131);

      doc.text(String(tax), 125, 131);

      doc.text(String(total), 160, 131);

      // =========================
      // TOTAL
      // =========================

      doc.setFont("helvetica", "bold");
      doc.setFontSize(14);

      doc.text("Grand Total:", 125, 155);

      doc.text(
        String(total),
        165,
        155
      );

      // =========================
      // PAYMENT STATUS
      // =========================

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");

      doc.text(
        `Payment Status: ${status}`,
        20,
        175
      );

      // =========================
      // FOOTER
      // =========================

      doc.setLineWidth(0.5);
      doc.line(20, 260, 190, 260);

      doc.setFontSize(10);

      doc.text(
        "Thank you for doing business with us.",
        20,
        270
      );

      doc.text(
        "Generated by CRM System",
        20,
        278
      );

      // =========================
      // DOWNLOAD
      // =========================

      doc.save(`${invoiceId}.pdf`);
    } catch (error) {
      console.error(
        "Invoice PDF Error:",
        error
      );

      alert(
        "Unable to download invoice PDF."
      );
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredInvoices = invoices.filter(
    (item) =>
      String(item.customer || "")
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      String(item.id || "")
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      String(item.gst || "")
        .toLowerCase()
        .includes(search.toLowerCase())
  );

  // =========================
  // COUNTS
  // =========================

  const paidCount = invoices.filter(
    (item) => item.status === "Paid"
  ).length;

  const pendingCount = invoices.filter(
    (item) => item.status === "Pending"
  ).length;

  // =========================
  // UI
  // =========================

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Invoice Management
              </h1>

              <p
                style={{
                  color: "#64748B",
                }}
              >
                Generate GST Invoices for Customers
              </p>
            </div>

            <button
              onClick={() => {
                setInvoice(emptyInvoice);
                setShowModal(true);
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Create Invoice
            </button>
          </div>

          {/* SEARCH */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                position: "relative",
                width: "350px",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Invoice..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* INVOICE TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={thStyle}>
                    Invoice No
                  </th>

                  <th>Customer</th>
                  <th>GST Number</th>
                  <th>Items</th>
                  <th>Tax</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredInvoices.map(
                  (item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign:
                          "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {item.id}
                      </td>

                      <td>
                        {item.customer}
                      </td>

                      <td>
                        {item.gst}
                      </td>

                      <td>
                        {item.items}
                      </td>

                      <td>
                        {item.tax}
                      </td>

                      <td>
                        {item.total}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item.status ===
                              "Paid"
                                ? "#22C55E"
                                : "#F59E0B",
                            color:
                              "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize:
                              "12px",
                          }}
                        >
                          {item.status}
                        </span>
                      </td>

                      <td>
                        {/* VIEW */}

                        <button
                          onClick={() =>
                            alert(
                              `Invoice Details\n\n` +
                                `Invoice: ${item.id}\n` +
                                `Customer: ${item.customer}\n` +
                                `GST: ${item.gst}\n` +
                                `Items: ${item.items}\n` +
                                `Tax: ${item.tax}\n` +
                                `Total: ${item.total}\n` +
                                `Status: ${item.status}`
                            )
                          }
                          style={{
                            background:
                              "#3B82F6",
                            color:
                              "#fff",
                            border:
                              "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            marginRight:
                              "8px",
                            cursor:
                              "pointer",
                          }}
                          title="View Invoice"
                        >
                          <FaEye />
                        </button>

                        {/* DOWNLOAD */}

                        <button
                          onClick={() =>
                            handleDownload(
                              item
                            )
                          }
                          style={{
                            background:
                              "#10B981",
                            color:
                              "#fff",
                            border:
                              "none",
                            padding:
                              "8px 10px",
                            borderRadius:
                              "6px",
                            cursor:
                              "pointer",
                          }}
                          title="Download Invoice"
                        >
                          <FaDownload />
                        </button>
                      </td>
                    </tr>
                  )
                )}

                {filteredInvoices.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="8"
                      style={{
                        textAlign:
                          "center",
                        padding: "20px",
                        color:
                          "#64748B",
                      }}
                    >
                      No Invoice Found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* SUMMARY CARDS */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(3,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background:
                  "#EEF2FF",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <FaFileInvoiceDollar
                size={28}
                color="#4F46E5"
              />

              <h3>Total Invoices</h3>

              <h1>
                {invoices.length}
              </h1>
            </div>

            <div
              style={{
                background:
                  "#DCFCE7",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <h3>Paid</h3>

              <h1>
                {paidCount}
              </h1>
            </div>

            <div
              style={{
                background:
                  "#FEF3C7",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <h3>Pending</h3>

              <h1>
                {pendingCount}
              </h1>
            </div>
          </div>
        </div>
      </div>

      {/* CREATE INVOICE MODAL */}

      {showModal && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background:
              "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent:
              "center",
            alignItems:
              "center",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: "30px",
              width: "450px",
              borderRadius: "12px",
            }}
          >
            <h2
              style={{
                marginTop: 0,
                color: "#334155",
              }}
            >
              Create Invoice
            </h2>

            <input
              placeholder="Customer Name"
              value={invoice.customer}
              onChange={(e) =>
                setField(
                  "customer",
                  e.target.value
                )
              }
              style={inputStyle}
            />

            <input
              placeholder="GST Number"
              value={invoice.gst}
              onChange={(e) =>
                setField(
                  "gst",
                  e.target.value
                )
              }
              style={inputStyle}
            />

            <input
              type="number"
              placeholder="Number of Items"
              value={invoice.items}
              onChange={(e) =>
                setField(
                  "items",
                  e.target.value
                )
              }
              style={inputStyle}
            />

            <input
              placeholder="Tax"
              value={invoice.tax}
              onChange={(e) =>
                setField(
                  "tax",
                  e.target.value
                )
              }
              style={inputStyle}
            />

            <input
              placeholder="Total"
              value={invoice.total}
              onChange={(e) =>
                setField(
                  "total",
                  e.target.value
                )
              }
              style={inputStyle}
            />

            <select
              value={invoice.status}
              onChange={(e) =>
                setField(
                  "status",
                  e.target.value
                )
              }
              style={inputStyle}
            >
              <option value="Paid">
                Paid
              </option>

              <option value="Pending">
                Pending
              </option>
            </select>

            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between",
                marginTop: "10px",
              }}
            >
              <button
                onClick={createInvoice}
                style={
                  saveButtonStyle
                }
              >
                Save Invoice
              </button>

              <button
                onClick={() => {
                  setShowModal(false);
                  setInvoice(
                    emptyInvoice
                  );
                }}
                style={
                  closeButtonStyle
                }
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// =========================
// STYLES
// =========================

const thStyle = {
  padding: "15px",
};

const inputStyle = {
  width: "100%",
  padding: "11px",
  marginBottom: "14px",
  border: "1px solid #CBD5E1",
  borderRadius: "7px",
  outline: "none",
  boxSizing: "border-box",
};

const saveButtonStyle = {
  background: "#4F46E5",
  color: "#fff",
  border: "none",
  padding: "10px 20px",
  borderRadius: "8px",
  cursor: "pointer",
};

const closeButtonStyle = {
  background: "#EF4444",
  color: "#fff",
  border: "none",
  padding: "10px 20px",
  borderRadius: "8px",
  cursor: "pointer",
};

export default Invoice;