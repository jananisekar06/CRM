
import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaWhatsapp,
  FaSearch,
  FaPlus,
  FaPaperPlane,
  FaCheckCircle,
  FaClock,
  FaEdit,
  FaTrash,
} from "react-icons/fa";

function WhatsApp() {
  const [search, setSearch] = useState("");

  const [messages, setMessages] = useState([]);

  const [form, setForm] = useState({
    customer: "",
    phone: "",
    type: "Meeting Reminder",
    message: "",
  });

  const [editingId, setEditingId] = useState(null);

  // GET ALL WHATSAPP MESSAGES
  const fetchMessages = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/whatsapp"
      );

      setMessages(response.data);
    } catch (error) {
      console.error("Error fetching WhatsApp messages:", error);
      alert("Unable to fetch WhatsApp messages");
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  // FORM INPUT CHANGE
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // Turn any phone number the user typed into a wa.me compatible number.
  // wa.me needs digits only, with country code, no "+", spaces or dashes.
  // If the number looks like a plain 10-digit Indian mobile number with
  // no country code, default it to +91 (India) automatically.
  const toWhatsAppNumber = (rawPhone) => {
    const digitsOnly = String(rawPhone || "").replace(/\D/g, "");

    if (digitsOnly.length === 10) {
      return `91${digitsOnly}`;
    }

    return digitsOnly;
  };

  // FREE WhatsApp send: opens WhatsApp's official "click to chat" link
  // (https://wa.me) with the message pre-filled. This needs no paid
  // WhatsApp Business API / no API key - it is completely free. The
  // user just has to press the Send button inside WhatsApp once it opens.
  const openWhatsAppChat = (phone, message) => {
    const number = toWhatsAppNumber(phone);

    if (!number) {
      alert("Enter a valid phone number to send the WhatsApp message");
      return false;
    }

    const url = `https://wa.me/${number}?text=${encodeURIComponent(
      message || ""
    )}`;

    window.open(url, "_blank");
    return true;
  };

  // SEND / UPDATE MESSAGE
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.customer || !form.phone || !form.message) {
      alert("Please fill all required fields");
      return;
    }

    try {
      if (editingId) {
        // UPDATE (just editing an existing record, don't re-send)
        await axios.put(
          `http://localhost:5000/api/whatsapp/${editingId}`,
          {
            ...form,
            status: "Pending",
          }
        );

        alert("WhatsApp message updated successfully");
      } else {
        // Actually open WhatsApp (free, wa.me link) with the message ready to send
        const opened = openWhatsAppChat(form.phone, form.message);

        // CREATE - save the record, marking it Sent once WhatsApp was opened
        await axios.post(
          "http://localhost:5000/api/whatsapp",
          {
            ...form,
            status: opened ? "Sent" : "Pending",
          }
        );

        alert(
          opened
            ? "WhatsApp opened with your message ready - press Send inside WhatsApp."
            : "WhatsApp message saved"
        );
      }

      resetForm();
      fetchMessages();
    } catch (error) {
      console.error("Error saving WhatsApp message:", error);
      alert("Unable to save WhatsApp message");
    }
  };

  // Resend an existing (e.g. Pending) message from the table
  const handleResend = async (item) => {
    const opened = openWhatsAppChat(item.phone, item.message || item.type);

    if (!opened) return;

    try {
      await axios.put(`http://localhost:5000/api/whatsapp/${item.id}`, {
        ...item,
        status: "Sent",
      });

      fetchMessages();
    } catch (error) {
      console.error("Error updating message status:", error);
    }
  };

  // EDIT
  const handleEdit = (item) => {
    setEditingId(item.id);

    setForm({
      customer: item.customer || "",
      phone: item.phone || "",
      type: item.type || "Meeting Reminder",
      message: item.message || "",
    });

    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth",
    });
  };

  // DELETE
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this message?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(
        `http://localhost:5000/api/whatsapp/${id}`
      );

      alert("WhatsApp message deleted successfully");

      fetchMessages();
    } catch (error) {
      console.error("Error deleting message:", error);
      alert("Unable to delete WhatsApp message");
    }
  };

  // RESET
  const resetForm = () => {
    setForm({
      customer: "",
      phone: "",
      type: "Meeting Reminder",
      message: "",
    });

    setEditingId(null);
  };

  // SEARCH
  const filteredMessages = messages.filter(
    (item) =>
      item.customer
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      item.phone?.includes(search)
  );

  // SUMMARY
  const totalMessages = messages.length;

  const meetingReminders = messages.filter(
    (item) => item.type === "Meeting Reminder"
  ).length;

  const delivered = messages.filter(
    (item) => item.status === "Delivered" || item.status === "Sent"
  ).length;

  const pending = messages.filter(
    (item) => item.status === "Pending"
  ).length;

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  color: "#334155",
                  margin: 0,
                }}
              >
                WhatsApp Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Send and manage WhatsApp notifications to customers.
              </p>
            </div>

            <button
              onClick={() =>
                document
                  .getElementById("whatsapp-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  })
              }
              style={{
                background: "#25D366",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                display: "flex",
                gap: "10px",
                alignItems: "center",
                cursor: "pointer",
              }}
            >
              <FaPlus />
              New Message
            </button>
          </div>

          {/* DASHBOARD CARDS */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <FaWhatsapp
                size={30}
                color="#25D366"
              />

              <h3>Total Messages</h3>
              <h2>{totalMessages}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaPaperPlane
                size={30}
                color="#2563EB"
              />

              <h3>Meeting Reminders</h3>
              <h2>{meetingReminders}</h2>
            </div>

            <div style={card("#EEF2FF")}>
              <FaCheckCircle
                size={30}
                color="#16A34A"
              />

              <h3>Delivered</h3>
              <h2>{delivered}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaClock
                size={30}
                color="#D97706"
              />

              <h3>Pending</h3>
              <h2>{pending}</h2>
            </div>
          </div>

          {/* SEARCH */}

          <div
            style={{
              position: "relative",
              width: "350px",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position: "absolute",
                left: "15px",
                top: "14px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search Customer or Phone..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              style={{
                width: "100%",
                padding: "12px 15px 12px 45px",
                borderRadius: "8px",
                border: "1px solid #CBD5E1",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
          </div>

          {/* WHATSAPP TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#25D366",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    ID
                  </th>

                  <th>Customer</th>
                  <th>Phone</th>
                  <th>Message Type</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredMessages.length > 0 ? (
                  filteredMessages.map((item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td style={{ padding: "15px" }}>
                        {item.id}
                      </td>

                      <td>{item.customer}</td>

                      <td>{item.phone}</td>

                      <td>{item.type}</td>

                      <td>{item.date}</td>

                      <td>
                        <span
                          style={{
                            background:
                              item.status === "Delivered" ||
                              item.status === "Sent"
                                ? "#22C55E"
                                : "#F59E0B",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                          }}
                        >
                          {item.status}
                        </span>
                      </td>

                      <td>
                        <button
                          onClick={() =>
                            handleResend(item)
                          }
                          title="Send via WhatsApp (free)"
                          style={{
                            background: "#25D366",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                          }}
                        >
                          <FaPaperPlane />
                        </button>

                        <button
                          onClick={() =>
                            handleEdit(item)
                          }
                          style={{
                            background: "#F59E0B",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                          }}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(item.id)
                          }
                          style={{
                            background: "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            cursor: "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        padding: "25px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No WhatsApp messages found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* SEND WHATSAPP FORM */}

          <div
            id="whatsapp-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Update WhatsApp Message"
                : "Send WhatsApp Message"}
            </h2>

            <form onSubmit={handleSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2,1fr)",
                  gap: "20px",
                }}
              >
                <div>
                  <label>Customer Name</label>

                  <input
                    type="text"
                    name="customer"
                    value={form.customer}
                    onChange={handleChange}
                    placeholder="Enter Customer Name"
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label>Phone Number</label>

                  <input
                    type="text"
                    name="phone"
                    value={form.phone}
                    onChange={handleChange}
                    placeholder="+91 9876543210"
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label>Message Type</label>

                  <select
                    name="type"
                    value={form.type}
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option>
                      Meeting Reminder
                    </option>

                    <option>Invoice</option>

                    <option>Offer</option>

                    <option>
                      Payment Reminder
                    </option>
                  </select>
                </div>

                <div>
                  <label>Status</label>

                  <input
                    type="text"
                    value="Pending"
                    disabled
                    style={{
                      ...inputStyle,
                      background: "#F1F5F9",
                    }}
                  />
                </div>

                <div
                  style={{
                    gridColumn: "1 / span 2",
                  }}
                >
                  <label>Message</label>

                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows="6"
                    placeholder="Type your WhatsApp message..."
                    style={{
                      ...inputStyle,
                      resize: "vertical",
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "15px",
                  marginTop: "25px",
                }}
              >
                <button
                  type="button"
                  onClick={resetForm}
                  style={{
                    background: "#E5E7EB",
                    color: "#334155",
                    border: "none",
                    padding: "12px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  Reset
                </button>

                <button
                  type="submit"
                  style={{
                    background: "#25D366",
                    color: "#fff",
                    border: "none",
                    padding: "12px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  {editingId
                    ? "Update WhatsApp"
                    : "Send WhatsApp"}
                </button>
              </div>
            </form>
          </div>

          {/* MESSAGE HISTORY */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Recent Message History
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#25D366",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "12px" }}>
                    Customer
                  </th>

                  <th>Message</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {messages.slice(-5).map((item) => (
                  <tr
                    key={item.id}
                    style={{
                      textAlign: "center",
                      borderBottom:
                        "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "12px" }}>
                      {item.customer}
                    </td>

                    <td>
                      {item.message || item.type}
                    </td>

                    <td>{item.date}</td>

                    <td>
                      <span
                        style={{
                          background:
                            item.status === "Delivered" ||
                            item.status === "Sent"
                              ? "#22C55E"
                              : "#F59E0B",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                        }}
                      >
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default WhatsApp;
