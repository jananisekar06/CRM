import { useEffect, useState } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaSearch,
  FaPlus,
  FaPhone,
  FaMicrophone,
  FaPhoneAlt,
  FaEdit,
  FaTrash,
  FaSave,
  FaTimes,
  FaPlay,
  FaPause,
} from "react-icons/fa";

function Communication() {
  const API_URL = "http://localhost:5000/api/communication";

  // =========================
  // STATES
  // =========================

  const [calls, setCalls] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  // Recording states
  const [selectedRecording, setSelectedRecording] = useState(null);
  const [showRecordingPlayer, setShowRecordingPlayer] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const [formData, setFormData] = useState({
    customer: "",
    phone: "",
    duration: "",
    employee: "",
    status: "Completed",
  });

  // =========================
  // GET CALLS
  // =========================

  const fetchCalls = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await axios.get(`${API_URL}/calls`);

      console.log("COMMUNICATION API:", response.data);

      if (response.data.success) {
        setCalls(response.data.calls || []);
      } else {
        setCalls([]);
        setError(
          response.data.message ||
            "Unable to load communication data"
        );
      }
    } catch (err) {
      console.error("FETCH COMMUNICATION ERROR:", err);

      setError(
        "Unable to load communication data. Please check backend server."
      );

      setCalls([]);
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // LOAD DATA
  // =========================

  useEffect(() => {
    fetchCalls();
  }, []);

  // =========================
  // FORM CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // OPEN CREATE FORM
  // =========================

  const openCreateForm = () => {
    setEditingId(null);

    setFormData({
      customer: "",
      phone: "",
      duration: "",
      employee: "",
      status: "Completed",
    });

    setShowForm(true);
  };

  // =========================
  // OPEN EDIT FORM
  // =========================

  const openEditForm = (call) => {
    setEditingId(call.id);

    setFormData({
      customer: call.customer || "",
      phone: call.phone || "",
      duration: call.duration || "",
      employee: call.employee || "",
      status: call.status || "Completed",
    });

    setShowForm(true);
  };

  // =========================
  // RESET FORM
  // =========================

  const resetForm = () => {
    setEditingId(null);

    setFormData({
      customer: "",
      phone: "",
      duration: "",
      employee: "",
      status: "Completed",
    });

    setShowForm(false);
  };

  // =========================
  // SAVE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.customer.trim() ||
      !formData.phone.trim() ||
      !formData.employee.trim()
    ) {
      alert("Please enter Customer, Phone and Employee");
      return;
    }

    try {
      if (editingId) {
        const response = await axios.put(
          `${API_URL}/calls/${editingId}`,
          formData
        );

        console.log("UPDATE CALL RESPONSE:", response.data);

        if (response.data.success) {
          alert("Call record updated successfully!");
          await fetchCalls();
          resetForm();
        }
      } else {
        const response = await axios.post(
          `${API_URL}/calls`,
          formData
        );

        console.log("CREATE CALL RESPONSE:", response.data);

        if (response.data.success) {
          alert("Call record created successfully!");
          await fetchCalls();
          resetForm();
        }
      }
    } catch (err) {
      console.error("SAVE CALL ERROR:", err);

      alert(
        err.response?.data?.message ||
          "Unable to save call record"
      );
    }
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this call record?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await axios.delete(
        `${API_URL}/calls/${id}`
      );

      console.log("DELETE CALL RESPONSE:", response.data);

      if (response.data.success) {
        alert("Call record deleted successfully!");
        await fetchCalls();
      }
    } catch (err) {
      console.error("DELETE CALL ERROR:", err);

      alert(
        err.response?.data?.message ||
          "Unable to delete call record"
      );
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredCalls = calls.filter((call) => {
    const searchText = search.toLowerCase();

    return (
      call.customer?.toLowerCase().includes(searchText) ||
      call.phone?.toLowerCase().includes(searchText) ||
      call.employee?.toLowerCase().includes(searchText) ||
      call.status?.toLowerCase().includes(searchText)
    );
  });

  // =========================
  // STATISTICS
  // =========================

  const totalCalls = calls.length;

  const completedCalls = calls.filter(
    (call) => call.status === "Completed"
  ).length;

  const missedCalls = calls.filter(
    (call) => call.status === "Missed"
  ).length;

  const ongoingCalls = calls.filter(
    (call) => call.status === "Ongoing"
  ).length;

  // =========================
  // PLAY RECORDING
  // =========================

  const handlePlayRecording = (recording) => {
    setSelectedRecording(recording);
    setShowRecordingPlayer(true);
    setIsPlaying(true);
  };

  // =========================
  // CLOSE RECORDING
  // =========================

  const closeRecordingPlayer = () => {
    setSelectedRecording(null);
    setShowRecordingPlayer(false);
    setIsPlaying(false);
  };

  // =========================
  // UI
  // =========================

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "20px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Communication
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginTop: "8px",
                }}
              >
                Manage calls, meetings and voice
                communication.
              </p>
            </div>

            <button
              onClick={openCreateForm}
              style={primaryButton}
            >
              <FaPlus />
              New Communication
            </button>
          </div>

          {/* ================= ERROR ================= */}

          {error && (
            <div
              style={{
                background: "#FEE2E2",
                color: "#B91C1C",
                padding: "15px",
                borderRadius: "8px",
                marginBottom: "20px",
                border: "1px solid #FCA5A5",
              }}
            >
              {error}
            </div>
          )}

          {/* ================= CARDS ================= */}

          <div style={cardsContainer}>

            <div style={card("#EEF2FF")}>
              <FaPhone size={28} color="#4F46E5" />
              <h3>Total Calls</h3>
              <h2>{totalCalls}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaPhoneAlt size={28} color="#16A34A" />
              <h3>Completed Calls</h3>
              <h2>{completedCalls}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <FaPhone size={28} color="#EF4444" />
              <h3>Missed Calls</h3>
              <h2>{missedCalls}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaMicrophone size={28} color="#D97706" />
              <h3>Ongoing Calls</h3>
              <h2>{ongoingCalls}</h2>
            </div>

          </div>

          {/* ================= SEARCH ================= */}

          <div style={sectionStyle}>

            <div
              style={{
                width: "350px",
                maxWidth: "100%",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Customer, Phone, Employee..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

          </div>

          {/* ================= FORM ================= */}

          {showForm && (
            <div style={sectionStyle}>

              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "20px",
                }}
              >
                <h2
                  style={{
                    color: "#334155",
                    margin: 0,
                  }}
                >
                  {editingId ? "Update Call" : "New Call"}
                </h2>

                <button
                  onClick={resetForm}
                  style={closeButton}
                >
                  <FaTimes />
                </button>
              </div>

              <form onSubmit={handleSubmit}>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(2, 1fr)",
                    gap: "20px",
                  }}
                >

                  <div>
                    <label>Customer Name</label>

                    <input
                      name="customer"
                      value={formData.customer}
                      onChange={handleChange}
                      placeholder="John Smith"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Phone Number</label>

                    <input
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="9876543210"
                      maxLength="10"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Duration</label>

                    <input
                      name="duration"
                      value={formData.duration}
                      onChange={handleChange}
                      placeholder="08:30"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Employee</label>

                    <input
                      name="employee"
                      value={formData.employee}
                      onChange={handleChange}
                      placeholder="Priya"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Status</label>

                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      style={inputStyle}
                    >
                      <option value="Completed">
                        Completed
                      </option>

                      <option value="Missed">
                        Missed
                      </option>

                      <option value="Ongoing">
                        Ongoing
                      </option>
                    </select>
                  </div>

                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "15px",
                    marginTop: "25px",
                  }}
                >

                  <button
                    type="button"
                    onClick={resetForm}
                    style={cancelButton}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    style={primaryButton}
                  >
                    <FaSave />

                    {editingId
                      ? "Update Call"
                      : "Save Call"}
                  </button>

                </div>

              </form>
            </div>
          )}

          {/* ================= CALL TABLE ================= */}

          <div style={sectionStyle}>

            <h2 style={sectionTitle}>
              Call Records
            </h2>

            <table style={tableStyle}>

              <thead style={tableHeadStyle}>
                <tr>
                  <th style={thStyle}>Call ID</th>
                  <th>Customer</th>
                  <th>Phone</th>
                  <th>Duration</th>
                  <th>Employee</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>

                {loading ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={emptyStyle}
                    >
                      Loading call records...
                    </td>
                  </tr>
                ) : filteredCalls.length === 0 ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={emptyStyle}
                    >
                      No call records found.
                    </td>
                  </tr>
                ) : (
                  filteredCalls.map((call) => (
                    <tr
                      key={call.id}
                      style={centerRow}
                    >

                      <td
                        style={{
                          padding: "15px",
                          fontWeight: "600",
                        }}
                      >
                        {call.id}
                      </td>

                      <td>{call.customer}</td>

                      <td>{call.phone}</td>

                      <td>{call.duration}</td>

                      <td>{call.employee}</td>

                      <td>
                        <StatusBadge
                          color={
                            call.status === "Completed"
                              ? "#22C55E"
                              : call.status === "Missed"
                              ? "#EF4444"
                              : "#F59E0B"
                          }
                          text={call.status}
                        />
                      </td>

                      <td>

                        <button
                          onClick={() =>
                            openEditForm(call)
                          }
                          style={editButton}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(call.id)
                          }
                          style={deleteButton}
                        >
                          <FaTrash />
                        </button>

                      </td>

                    </tr>
                  ))
                )}

              </tbody>

            </table>

          </div>

          {/* ================= CALL RECORDINGS ================= */}

          <div style={sectionStyle}>

            <h2 style={sectionTitle}>
              Call Recordings
            </h2>

            <table style={tableStyle}>

              <thead style={tableHeadStyle}>
                <tr>
                  <th style={thStyle}>
                    Recording ID
                  </th>

                  <th>Customer</th>
                  <th>Date</th>
                  <th>Duration</th>
                  <th>Playback</th>
                </tr>
              </thead>

              <tbody>

                <tr style={centerRow}>

                  <td style={tdStyle}>
                    REC001
                  </td>

                  <td>
                    John Smith
                  </td>

                  <td>
                    05-08-2026
                  </td>

                  <td>
                    08:30
                  </td>

                  <td>

                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "REC001",
                          customer: "John Smith",
                          date: "05-08-2026",
                          duration: "08:30",
                          audioUrl:
                            "/recordings/rec001.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>

                  </td>

                </tr>

                <tr style={centerRow}>

                  <td style={tdStyle}>
                    REC002
                  </td>

                  <td>
                    Priya
                  </td>

                  <td>
                    06-08-2026
                  </td>

                  <td>
                    05:45
                  </td>

                  <td>

                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "REC002",
                          customer: "Priya",
                          date: "06-08-2026",
                          duration: "05:45",
                          audioUrl:
                            "/recordings/rec002.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>

                  </td>

                </tr>

                <tr style={centerRow}>

                  <td style={tdStyle}>
                    REC003
                  </td>

                  <td>
                    Rahul
                  </td>

                  <td>
                    08-08-2026
                  </td>

                  <td>
                    12:15
                  </td>

                  <td>

                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "REC003",
                          customer: "Rahul",
                          date: "08-08-2026",
                          duration: "12:15",
                          audioUrl:
                            "/recordings/rec003.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>

                  </td>

                </tr>

              </tbody>

            </table>

          </div>

          {/* ================= VIDEO MEETINGS ================= */}

          <div style={sectionStyle}>

            <h2 style={sectionTitle}>
              Video Meetings
            </h2>

            <table style={tableStyle}>

              <thead style={tableHeadStyle}>
                <tr>
                  <th style={thStyle}>
                    Meeting ID
                  </th>
                  <th>Platform</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Organizer</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>

                <tr style={centerRow}>
                  <td style={tdStyle}>MT001</td>
                  <td>Google Meet</td>
                  <td>10-08-2026</td>
                  <td>10:00 AM</td>
                  <td>John</td>

                  <td>
                    <StatusBadge
                      color="#22C55E"
                      text="Scheduled"
                    />
                  </td>
                </tr>

                <tr style={centerRow}>
                  <td style={tdStyle}>MT002</td>
                  <td>Zoom</td>
                  <td>11-08-2026</td>
                  <td>02:00 PM</td>
                  <td>Priya</td>

                  <td>
                    <StatusBadge
                      color="#3B82F6"
                      text="Completed"
                    />
                  </td>
                </tr>

                <tr style={centerRow}>
                  <td style={tdStyle}>MT003</td>
                  <td>Microsoft Teams</td>
                  <td>12-08-2026</td>
                  <td>11:30 AM</td>
                  <td>Rahul</td>

                  <td>
                    <StatusBadge
                      color="#F59E0B"
                      text="Ongoing"
                    />
                  </td>
                </tr>

              </tbody>

            </table>

          </div>

          {/* ================= VOICE NOTES ================= */}

          <div style={sectionStyle}>

            <h2 style={sectionTitle}>
              Voice Notes
            </h2>

            <table style={tableStyle}>

              <thead style={tableHeadStyle}>
                <tr>
                  <th style={thStyle}>Voice ID</th>
                  <th>Customer</th>
                  <th>Recorded By</th>
                  <th>Duration</th>
                  <th>Playback</th>
                </tr>
              </thead>

              <tbody>

                <tr style={centerRow}>
                  <td style={tdStyle}>VN001</td>
                  <td>John Smith</td>
                  <td>Priya</td>
                  <td>01:20</td>

                  <td>
                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "VN001",
                          customer: "John Smith",
                          date: "Voice Note",
                          duration: "01:20",
                          audioUrl:
                            "/recordings/vn001.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>
                  </td>
                </tr>

                <tr style={centerRow}>
                  <td style={tdStyle}>VN002</td>
                  <td>Rahul</td>
                  <td>David</td>
                  <td>02:45</td>

                  <td>
                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "VN002",
                          customer: "Rahul",
                          date: "Voice Note",
                          duration: "02:45",
                          audioUrl:
                            "/recordings/vn002.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>
                  </td>
                </tr>

                <tr style={centerRow}>
                  <td style={tdStyle}>VN003</td>
                  <td>Sneha</td>
                  <td>John</td>
                  <td>03:15</td>

                  <td>
                    <button
                      onClick={() =>
                        handlePlayRecording({
                          id: "VN003",
                          customer: "Sneha",
                          date: "Voice Note",
                          duration: "03:15",
                          audioUrl:
                            "/recordings/vn003.mp3",
                        })
                      }
                      style={playButton}
                    >
                      <FaPlay />
                      Play
                    </button>
                  </td>
                </tr>

              </tbody>

            </table>

          </div>

          {/* ================= SUMMARY ================= */}

          <div style={cardsContainer}>

            <div style={card("#EEF2FF")}>
              <h3>Total Calls</h3>
              <h2>{totalCalls}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <h3>Completed Calls</h3>
              <h2>{completedCalls}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Missed Calls</h3>
              <h2>{missedCalls}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Ongoing Calls</h3>
              <h2>{ongoingCalls}</h2>
            </div>

          </div>

        </div>
      </div>

      {/* ================= RECORDING PLAYER MODAL ================= */}

      {showRecordingPlayer && selectedRecording && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.65)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 2000,
            padding: "20px",
          }}
        >

          <div
            style={{
              background: "#fff",
              width: "480px",
              maxWidth: "100%",
              borderRadius: "18px",
              padding: "28px",
              boxShadow:
                "0 20px 60px rgba(0,0,0,.3)",
            }}
          >

            {/* PLAYER HEADER */}

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >

              <div>

                <h2
                  style={{
                    margin: 0,
                    color: "#334155",
                  }}
                >
                  Call Recording
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#64748B",
                  }}
                >
                  {selectedRecording.customer}
                </p>

              </div>

              <button
                onClick={closeRecordingPlayer}
                style={closeButton}
              >
                <FaTimes />
              </button>

            </div>

            {/* RECORDING INFORMATION */}

            <div
              style={{
                background: "#F8FAFC",
                padding: "16px",
                borderRadius: "10px",
                marginBottom: "20px",
              }}
            >

              <p>
                <strong>Recording ID:</strong>{" "}
                {selectedRecording.id}
              </p>

              <p>
                <strong>Customer:</strong>{" "}
                {selectedRecording.customer}
              </p>

              <p>
                <strong>Date:</strong>{" "}
                {selectedRecording.date}
              </p>

              <p>
                <strong>Duration:</strong>{" "}
                {selectedRecording.duration}
              </p>

            </div>

            {/* AUDIO PLAYER */}

            <audio
              controls
              autoPlay
              style={{
                width: "100%",
              }}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            >
              <source
                src={selectedRecording.audioUrl}
                type="audio/mpeg"
              />

              Your browser does not support audio
              playback.
            </audio>

            {/* PLAYER STATUS */}

            <div
              style={{
                textAlign: "center",
                marginTop: "15px",
                color: "#64748B",
              }}
            >
              {isPlaying ? (
                <>
                  <FaPause /> Playing recording...
                </>
              ) : (
                <>
                  <FaPlay /> Recording paused
                </>
              )}
            </div>

            {/* CLOSE */}

            <button
              onClick={closeRecordingPlayer}
              style={{
                width: "100%",
                marginTop: "20px",
                padding: "12px",
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "600",
              }}
            >
              Close
            </button>

          </div>
        </div>
      )}

    </div>
  );
}

// =========================
// STYLES
// =========================

const primaryButton = {
  background: "#4F46E5",
  color: "#fff",
  border: "none",
  padding: "12px 22px",
  borderRadius: "8px",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  gap: "10px",
  fontWeight: "600",
};

const cardsContainer = {
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gap: "20px",
  marginBottom: "30px",
};

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const sectionStyle = {
  marginTop: "25px",
  background: "#fff",
  borderRadius: "15px",
  padding: "20px",
  boxShadow: "0 5px 15px rgba(0,0,0,.08)",
  overflowX: "auto",
};

const sectionTitle = {
  marginTop: 0,
  color: "#334155",
  marginBottom: "20px",
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  minWidth: "700px",
};

const tableHeadStyle = {
  background: "#4F46E5",
  color: "#fff",
};

const thStyle = {
  padding: "15px",
};

const tdStyle = {
  padding: "15px",
};

const centerRow = {
  textAlign: "center",
  borderBottom: "1px solid #E2E8F0",
};

const emptyStyle = {
  padding: "35px",
  textAlign: "center",
  color: "#64748B",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

const playButton = {
  background: "#4F46E5",
  color: "#fff",
  border: "none",
  padding: "8px 16px",
  borderRadius: "6px",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  gap: "7px",
};

const editButton = {
  background: "#F59E0B",
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  marginRight: "8px",
  cursor: "pointer",
};

const deleteButton = {
  background: "#EF4444",
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  cursor: "pointer",
};

const closeButton = {
  background: "#FEE2E2",
  color: "#DC2626",
  border: "none",
  width: "36px",
  height: "36px",
  borderRadius: "50%",
  cursor: "pointer",
};

const cancelButton = {
  background: "#E5E7EB",
  color: "#334155",
  border: "none",
  padding: "12px 25px",
  borderRadius: "8px",
  cursor: "pointer",
};

function StatusBadge({ color, text }) {
  return (
    <span
      style={{
        background: color,
        color: "#fff",
        padding: "5px 12px",
        borderRadius: "20px",
        fontSize: "12px",
      }}
    >
      {text}
    </span>
  );
}

export default Communication;