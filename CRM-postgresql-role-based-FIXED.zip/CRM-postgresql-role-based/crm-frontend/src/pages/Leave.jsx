import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch, FaCheckCircle, FaClock, FaTimesCircle } from "react-icons/fa";

const emptyLeave = { employee: "", department: "", type: "Casual Leave", from: "", to: "" };

function Leave() {
  const [search, setSearch] = useState("");
  const [leaves, setLeaves] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [leave, setLeave] = useState(emptyLeave);

  useEffect(() => {
    const fetchLeaves = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/leaves");
        setLeaves(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };
    fetchLeaves();
  }, []);

  const applyLeave = async () => {
    if (!leave.employee || !leave.department || !leave.from || !leave.to) {
      alert("Please fill all leave details");
      return;
    }
    try {
      const response = await axios.post("http://localhost:5000/api/leaves", leave);
      setLeaves((currentLeaves) => [...currentLeaves, response.data.leave]);
      alert(response.data.message);
      setLeave(emptyLeave);
      setShowModal(false);
    } catch (error) {
      alert("Failed to apply leave");
    }
  };

  const filteredLeaves = leaves.filter((item) => item.employee.toLowerCase().includes(search.toLowerCase()));
  const approvedCount = leaves.filter((item) => item.status === "Approved").length;
  const pendingCount = leaves.filter((item) => item.status === "Pending").length;
  const rejectedCount = leaves.filter((item) => item.status === "Rejected").length;
  const setField = (field, value) => setLeave({ ...leave, [field]: value });

  const getStatusStyle = (status) => {
    if (status === "Approved") return { background: "#DCFCE7", color: "#166534" };
    if (status === "Pending") return { background: "#FEF3C7", color: "#92400E" };
    return { background: "#FEE2E2", color: "#991B1B" };
  };

  const cards = [
    { title: "Total Requests", value: leaves.length, icon: <FaClock size={32} color="#4F46E5" />, color: "#4F46E5" },
    { title: "Approved", value: approvedCount, icon: <FaCheckCircle size={32} color="#22C55E" />, color: "#22C55E" },
    { title: "Pending", value: pendingCount, icon: <FaClock size={32} color="#F59E0B" />, color: "#F59E0B" },
    { title: "Rejected", value: rejectedCount, icon: <FaTimesCircle size={32} color="#EF4444" />, color: "#EF4444" },
  ];

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1 }}>
        <Navbar />
        <main style={{ padding: "30px" }}>
          <div style={headerRowStyle}>
            <div><h1 style={{ margin: 0, color: "#1E293B" }}>Leave Management</h1><p style={{ marginTop: "8px", color: "#64748B" }}>Manage employee leave requests</p></div>
            <button onClick={() => setShowModal(true)} style={applyButtonStyle}><FaPlus /> Apply Leave</button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "20px", marginBottom: "25px" }}>
            {cards.map((card) => <div key={card.title} style={summaryCardStyle}><div><p style={{ margin: 0, color: "#64748B" }}>{card.title}</p><h2 style={{ margin: "8px 0 0", color: card.color }}>{card.value}</h2></div>{card.icon}</div>)}
          </div>

          <div style={searchBoxStyle}><div style={{ position: "relative", width: "350px" }}><FaSearch style={{ position: "absolute", left: "15px", top: "14px", color: "#64748B" }} /><input type="text" placeholder="Search Employee..." value={search} onChange={(event) => setSearch(event.target.value)} style={searchInputStyle} /></div></div>

          <div style={tableBoxStyle}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#4F46E5", color: "#fff" }}><tr><th style={{ padding: "15px" }}>ID</th><th>Employee</th><th>Department</th><th>Leave Type</th><th>From</th><th>To</th><th>Status</th></tr></thead>
              <tbody>
                {filteredLeaves.map((item) => <tr key={item.id} style={{ textAlign: "center", borderBottom: "1px solid #E2E8F0" }}><td style={{ padding: "15px" }}>{item.id}</td><td>{item.employee}</td><td>{item.department}</td><td>{item.type}</td><td>{item.from}</td><td>{item.to}</td><td><span style={{ display: "inline-block", padding: "6px 14px", borderRadius: "20px", fontSize: "12px", fontWeight: "600", ...getStatusStyle(item.status) }}>{item.status}</span></td></tr>)}
                {filteredLeaves.length === 0 && <tr><td colSpan="7" style={{ padding: "30px", textAlign: "center", color: "#64748B" }}>No leave requests found.</td></tr>}
              </tbody>
            </table>
          </div>
        </main>
      </div>

      {showModal && <div style={overlayStyle}><div style={modalStyle}><h2>Apply Leave</h2><input placeholder="Employee Name" value={leave.employee} onChange={(event) => setField("employee", event.target.value)} style={inputStyle} /><input placeholder="Department" value={leave.department} onChange={(event) => setField("department", event.target.value)} style={inputStyle} /><select value={leave.type} onChange={(event) => setField("type", event.target.value)} style={inputStyle}><option>Casual Leave</option><option>Sick Leave</option><option>Vacation</option></select><label>From</label><input type="date" value={leave.from} onChange={(event) => setField("from", event.target.value)} style={inputStyle} /><label>To</label><input type="date" value={leave.to} onChange={(event) => setField("to", event.target.value)} style={inputStyle} /><div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}><button onClick={applyLeave} style={saveButtonStyle}>Save</button><button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button></div></div></div>}
    </div>
  );
}

const headerRowStyle = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "25px" };
const applyButtonStyle = { display: "flex", alignItems: "center", gap: "8px", background: "#4F46E5", color: "#fff", border: "none", padding: "12px 20px", borderRadius: "8px", cursor: "pointer", fontWeight: "600" };
const summaryCardStyle = { background: "#fff", padding: "22px", borderRadius: "14px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)", display: "flex", justifyContent: "space-between", alignItems: "center" };
const searchBoxStyle = { background: "#fff", padding: "20px", borderRadius: "14px", marginBottom: "20px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const searchInputStyle = { width: "100%", boxSizing: "border-box", padding: "12px 15px 12px 45px", borderRadius: "8px", border: "1px solid #CBD5E1", outline: "none" };
const tableBoxStyle = { background: "#fff", borderRadius: "14px", overflow: "hidden", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", margin: "8px 0 15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Leave;
