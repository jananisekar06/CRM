import { useState, useEffect } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaEye,
  FaTimes,
  FaCalendarAlt,
  FaClock,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/meetings";

function MeetingScheduler() {
  const [search, setSearch] = useState("");
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(false);

  // Modal
  const [showModal, setShowModal] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState(null);

  // View Modal
  const [viewMeeting, setViewMeeting] = useState(null);

  // Form
  const [formData, setFormData] = useState({
    title: "",
    date: "",
    time: "",
    platform: "Google Meet",
    organizer: "",
    status: "Scheduled",
  });

  // =====================================================
  // RESET FORM
  // =====================================================

  const resetForm = () => {
    setFormData({
      title: "",
      date: "",
      time: "",
      platform: "Google Meet",
      organizer: "",
      status: "Scheduled",
    });
  };

  // =====================================================
  // FETCH MEETINGS
  // =====================================================

  const fetchMeetings = async () => {
    try {
      setLoading(true);

      const response = await axios.get(API_URL);

      console.log("Meeting API Response:", response.data);

      const data = Array.isArray(response.data)
        ? response.data
        : response.data.meetings ||
          response.data.data ||
          [];

      setMeetings(data);
    } catch (error) {
      console.error("Meeting Fetch Error:", error);

      if (
        error.code === "ERR_NETWORK" ||
        error.code === "ECONNREFUSED"
      ) {
        alert(
          "Network Error!\n\nPlease make sure your backend server is running on port 5000."
        );
      } else {
        alert(
          error.response?.data?.message ||
            "Failed to load meetings"
        );
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMeetings();
  }, []);

  // =====================================================
  // OPEN ADD MODAL
  // =====================================================

  const openAddModal = () => {
    setEditingMeeting(null);
    resetForm();
    setShowModal(true);
  };

  // =====================================================
  // OPEN EDIT MODAL
  // =====================================================

  const openEditModal = (meeting) => {
    setEditingMeeting(meeting);

    setFormData({
      title: meeting.title || "",
      date: meeting.date || "",
      time: meeting.time || "",
      platform: meeting.platform || "Google Meet",
      organizer: meeting.organizer || "",
      status: meeting.status || "Scheduled",
    });

    setShowModal(true);
  };

  // =====================================================
  // CLOSE MODAL
  // =====================================================

  const closeModal = () => {
    setShowModal(false);
    setEditingMeeting(null);
    resetForm();
  };

  // =====================================================
  // FORM CHANGE
  // =====================================================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =====================================================
  // ADD / UPDATE MEETING
  // =====================================================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.title.trim() ||
      !formData.date ||
      !formData.time ||
      !formData.organizer.trim()
    ) {
      alert(
        "Please fill in Meeting Title, Date, Time and Organizer."
      );
      return;
    }

    try {
      setLoading(true);

      // =================================================
      // UPDATE
      // =================================================

      if (editingMeeting) {
        console.log(
          "Updating Meeting:",
          editingMeeting.id
        );

        const response = await axios.put(
          `${API_URL}/${editingMeeting.id}`,
          {
            title: formData.title.trim(),
            date: formData.date,
            time: formData.time,
            platform: formData.platform,
            organizer: formData.organizer.trim(),
            status: formData.status,
          }
        );

        console.log(
          "UPDATE RESPONSE:",
          response.data
        );

        if (response.data.success) {
          alert(
            response.data.message ||
              "Meeting updated successfully"
          );

          closeModal();
          await fetchMeetings();
        } else {
          alert(
            response.data.message ||
              "Failed to update meeting"
          );
        }

        return;
      }

      // =================================================
      // ADD
      // =================================================
      // ID IS GENERATED BY BACKEND
      // Example: MT001, MT002, MT003
      // =================================================

      const newMeeting = {
        title: formData.title.trim(),
        date: formData.date,
        time: formData.time,
        platform: formData.platform,
        organizer: formData.organizer.trim(),
        status: formData.status,
      };

      console.log(
        "Adding Meeting:",
        newMeeting
      );

      const response = await axios.post(
        API_URL,
        newMeeting
      );

      console.log(
        "ADD RESPONSE:",
        response.data
      );

      if (response.data.success) {
        alert(
          response.data.message ||
            "Meeting scheduled successfully"
        );

        closeModal();
        await fetchMeetings();
      } else {
        alert(
          response.data.message ||
            "Failed to schedule meeting"
        );
      }
    } catch (error) {
      console.error(
        "Meeting Save Error:",
        error.response?.data || error
      );

      const serverMessage =
        error.response?.data?.message;

      const serverError =
        error.response?.data?.error;

      if (
        error.code === "ERR_NETWORK" ||
        error.code === "ECONNREFUSED"
      ) {
        alert(
          "Network Error!\n\nPlease make sure your backend server is running on port 5000."
        );
      } else {
        alert(
          serverMessage ||
            serverError ||
            error.message ||
            "Failed to save meeting"
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // =====================================================
  // DELETE MEETING
  // =====================================================

  const handleDelete = async (meeting) => {
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${meeting.id}?`
    );

    if (!confirmDelete) return;

    try {
      setLoading(true);

      await axios.delete(
        `${API_URL}/${meeting.id}`
      );

      alert("Meeting deleted successfully");

      setMeetings((prev) =>
        prev.filter(
          (item) => item.id !== meeting.id
        )
      );
    } catch (error) {
      console.error(
        "Meeting Delete Error:",
        error
      );

      alert(
        error.response?.data?.message ||
          "Failed to delete meeting"
      );
    } finally {
      setLoading(false);
    }
  };

  // =====================================================
  // SEARCH
  // =====================================================

  const filteredMeetings = meetings.filter(
    (meeting) => {
      const value = search
        .toLowerCase()
        .trim();

      return (
        String(meeting.id || "")
          .toLowerCase()
          .includes(value) ||
        String(meeting.title || "")
          .toLowerCase()
          .includes(value) ||
        String(meeting.platform || "")
          .toLowerCase()
          .includes(value) ||
        String(meeting.organizer || "")
          .toLowerCase()
          .includes(value) ||
        String(meeting.status || "")
          .toLowerCase()
          .includes(value)
      );
    }
  );

  // =====================================================
  // STATUS STYLE
  // =====================================================

  const getStatusStyle = (status) => {
    if (status === "Completed") {
      return {
        background: "#DCFCE7",
        color: "#15803D",
      };
    }

    if (status === "Cancelled") {
      return {
        background: "#FEE2E2",
        color: "#DC2626",
      };
    }

    if (status === "Rescheduled") {
      return {
        background: "#DBEAFE",
        color: "#2563EB",
      };
    }

    return {
      background: "#FEF3C7",
      color: "#B45309",
    };
  };

  // =====================================================
  // RENDER
  // =====================================================

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div
        style={{
          marginLeft: "260px",
          minHeight: "100vh",
        }}
      >
        <Navbar />

        <main
          style={{
            padding: "30px",
            maxWidth: "1600px",
            margin: "0 auto",
          }}
        >
          {/* =====================================================
              HEADER
          ===================================================== */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "20px",
              flexWrap: "wrap",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                  fontSize: "30px",
                  fontWeight: "700",
                }}
              >
                Meeting Scheduler
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginTop: "8px",
                }}
              >
                Schedule and manage your meetings
              </p>
            </div>

            <button
              type="button"
              onClick={openAddModal}
              disabled={loading}
              style={{
                background: loading
                  ? "#9CA3AF"
                  : "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: loading
                  ? "not-allowed"
                  : "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                fontSize: "14px",
                fontWeight: "600",
              }}
            >
              <FaPlus />
              Schedule Meeting
            </button>
          </div>

          {/* =====================================================
              SEARCH
          ===================================================== */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                position: "relative",
                width: "350px",
                maxWidth: "100%",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Meeting..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  boxSizing: "border-box",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  fontSize: "14px",
                }}
              />
            </div>
          </div>

          {/* =====================================================
              MEETING TABLE
          ===================================================== */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                padding: "20px",
                borderBottom:
                  "1px solid #E2E8F0",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#334155",
                  fontSize: "20px",
                }}
              >
                Meeting Records
              </h2>
            </div>

            <div
              style={{
                width: "100%",
                overflowX: "auto",
              }}
            >
              <table
                style={{
                  width: "100%",
                  minWidth: "1000px",
                  borderCollapse: "collapse",
                }}
              >
                <thead
                  style={{
                    background: "#4F46E5",
                    color: "#fff",
                  }}
                >
                  <tr>
                    {[
                      "ID",
                      "Title",
                      "Date",
                      "Time",
                      "Platform",
                      "Organizer",
                      "Status",
                      "Action",
                    ].map((heading) => (
                      <th
                        key={heading}
                        style={{
                          padding: "15px",
                          fontSize: "13px",
                          fontWeight: "600",
                          textAlign: "center",
                        }}
                      >
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {filteredMeetings.map(
                    (meeting) => (
                      <tr
                        key={meeting.id}
                        style={{
                          textAlign: "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td
                          style={{
                            padding: "15px",
                            fontWeight: "600",
                            color: "#334155",
                          }}
                        >
                          {meeting.id}
                        </td>

                        <td>
                          {meeting.title || "-"}
                        </td>

                        <td>
                          {meeting.date || "-"}
                        </td>

                        <td>
                          {meeting.time || "-"}
                        </td>

                        <td>
                          {meeting.platform || "-"}
                        </td>

                        <td>
                          {meeting.organizer || "-"}
                        </td>

                        <td>
                          <span
                            style={{
                              ...getStatusStyle(
                                meeting.status
                              ),
                              display:
                                "inline-block",
                              padding:
                                "6px 13px",
                              borderRadius:
                                "20px",
                              fontSize: "12px",
                              fontWeight: "600",
                            }}
                          >
                            {meeting.status ||
                              "Scheduled"}
                          </span>
                        </td>

                        <td>
                          {/* VIEW */}

                          <button
                            type="button"
                            title="View"
                            onClick={() =>
                              setViewMeeting(
                                meeting
                              )
                            }
                            style={{
                              background:
                                "#DBEAFE",
                              color:
                                "#2563EB",
                              border: "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "8px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaEye />
                          </button>

                          {/* EDIT */}

                          <button
                            type="button"
                            title="Edit"
                            onClick={() =>
                              openEditModal(
                                meeting
                              )
                            }
                            style={{
                              background:
                                "#FEF3C7",
                              color:
                                "#D97706",
                              border: "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "8px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaEdit />
                          </button>

                          {/* DELETE */}

                          <button
                            type="button"
                            title="Delete"
                            onClick={() =>
                              handleDelete(
                                meeting
                              )
                            }
                            style={{
                              background:
                                "#FEE2E2",
                              color:
                                "#DC2626",
                              border: "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    )
                  )}

                  {filteredMeetings.length ===
                    0 && (
                    <tr>
                      <td
                        colSpan="8"
                        style={{
                          padding: "40px",
                          textAlign: "center",
                          color: "#64748B",
                        }}
                      >
                        {loading
                          ? "Loading meetings..."
                          : "No meeting records found."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* =====================================================
          ADD / EDIT MEETING MODAL
      ===================================================== */}

      {showModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,

            background:
              "rgba(15, 23, 42, 0.60)",

            zIndex: 99999,

            overflowY: "auto",
            overflowX: "hidden",

            padding: "20px",

            boxSizing: "border-box",

            display: "flex",
            justifyContent: "center",
            alignItems: "flex-start",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: "550px",

              maxHeight:
                "calc(100vh - 40px)",

              background: "#fff",

              borderRadius: "15px",

              boxShadow:
                "0 20px 50px rgba(0,0,0,.25)",

              display: "flex",
              flexDirection: "column",

              overflow: "hidden",

              margin: "0 auto",
            }}
          >
            {/* MODAL HEADER */}

            <div
              style={{
                background: "#4F46E5",
                color: "#fff",

                padding: "18px 20px",

                display: "flex",
                justifyContent:
                  "space-between",
                alignItems: "center",

                flexShrink: 0,
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: "20px",
                  fontWeight: "700",
                }}
              >
                {editingMeeting
                  ? "Edit Meeting"
                  : "Schedule Meeting"}
              </h2>

              <button
                type="button"
                onClick={closeModal}
                style={{
                  background:
                    "transparent",
                  border: "none",
                  color: "#fff",
                  fontSize: "20px",
                  cursor: "pointer",
                  padding: "5px",
                }}
              >
                <FaTimes />
              </button>
            </div>

            {/* FORM */}

            <form
              onSubmit={handleSubmit}
              style={{
                padding: "25px",

                overflowY: "auto",

                flex: 1,

                boxSizing: "border-box",
              }}
            >
              {/* Meeting Title */}

              <div
                style={{
                  marginBottom: "18px",
                }}
              >
                <label
                  style={{
                    display: "block",
                    marginBottom: "7px",
                    color: "#334155",
                    fontWeight: "600",
                    fontSize: "14px",
                  }}
                >
                  Meeting Title *
                </label>

                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Enter meeting title"
                  required
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "12px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "8px",
                    outline: "none",
                    fontSize: "14px",
                  }}
                />
              </div>

              {/* Date & Time */}

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "1fr 1fr",
                  gap: "15px",
                  marginBottom: "18px",
                }}
              >
                <div>
                  <label
                    style={{
                      display: "block",
                      marginBottom: "7px",
                      color: "#334155",
                      fontWeight: "600",
                      fontSize: "14px",
                    }}
                  >
                    <FaCalendarAlt
                      style={{
                        marginRight: "6px",
                      }}
                    />
                    Date *
                  </label>

                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    required
                    style={{
                      width: "100%",
                      boxSizing:
                        "border-box",
                      padding: "12px",
                      border:
                        "1px solid #CBD5E1",
                      borderRadius: "8px",
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      marginBottom: "7px",
                      color: "#334155",
                      fontWeight: "600",
                      fontSize: "14px",
                    }}
                  >
                    <FaClock
                      style={{
                        marginRight: "6px",
                      }}
                    />
                    Time *
                  </label>

                  <input
                    type="time"
                    name="time"
                    value={formData.time}
                    onChange={handleChange}
                    required
                    style={{
                      width: "100%",
                      boxSizing:
                        "border-box",
                      padding: "12px",
                      border:
                        "1px solid #CBD5E1",
                      borderRadius: "8px",
                      outline: "none",
                    }}
                  />
                </div>
              </div>

              {/* Platform */}

              <div
                style={{
                  marginBottom: "18px",
                }}
              >
                <label
                  style={{
                    display: "block",
                    marginBottom: "7px",
                    color: "#334155",
                    fontWeight: "600",
                    fontSize: "14px",
                  }}
                >
                  Platform
                </label>

                <select
                  name="platform"
                  value={formData.platform}
                  onChange={handleChange}
                  style={{
                    width: "100%",
                    padding: "12px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "8px",
                    outline: "none",
                    background: "#fff",
                  }}
                >
                  <option value="Google Meet">
                    Google Meet
                  </option>

                  <option value="Zoom">
                    Zoom
                  </option>

                  <option value="Microsoft Teams">
                    Microsoft Teams
                  </option>

                  <option value="In Person">
                    In Person
                  </option>
                </select>
              </div>

              {/* Organizer */}

              <div
                style={{
                  marginBottom: "18px",
                }}
              >
                <label
                  style={{
                    display: "block",
                    marginBottom: "7px",
                    color: "#334155",
                    fontWeight: "600",
                    fontSize: "14px",
                  }}
                >
                  Organizer *
                </label>

                <input
                  type="text"
                  name="organizer"
                  value={formData.organizer}
                  onChange={handleChange}
                  placeholder="Enter organizer name"
                  required
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "12px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "8px",
                    outline: "none",
                  }}
                />
              </div>

              {/* Status */}

              <div
                style={{
                  marginBottom: "25px",
                }}
              >
                <label
                  style={{
                    display: "block",
                    marginBottom: "7px",
                    color: "#334155",
                    fontWeight: "600",
                    fontSize: "14px",
                  }}
                >
                  Status
                </label>

                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  style={{
                    width: "100%",
                    padding: "12px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "8px",
                    outline: "none",
                    background: "#fff",
                  }}
                >
                  <option value="Scheduled">
                    Scheduled
                  </option>

                  <option value="Rescheduled">
                    Rescheduled
                  </option>

                  <option value="Completed">
                    Completed
                  </option>

                  <option value="Cancelled">
                    Cancelled
                  </option>
                </select>
              </div>

              {/* BUTTONS */}

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "10px",
                  paddingTop: "5px",
                  paddingBottom: "5px",
                }}
              >
                <button
                  type="button"
                  onClick={closeModal}
                  style={{
                    background: "#E2E8F0",
                    color: "#334155",
                    border: "none",
                    padding:
                      "11px 20px",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontWeight: "600",
                  }}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: loading
                      ? "#9CA3AF"
                      : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding:
                      "11px 22px",
                    borderRadius: "8px",
                    cursor: loading
                      ? "not-allowed"
                      : "pointer",
                    fontWeight: "600",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingMeeting
                    ? "Update Meeting"
                    : "Schedule Meeting"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================
          VIEW MEETING MODAL
      ===================================================== */}

      {viewMeeting && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background:
              "rgba(15, 23, 42, 0.55)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 99999,
            padding: "20px",
            overflowY: "auto",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: "500px",
              maxHeight:
                "calc(100vh - 40px)",
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 20px 50px rgba(0,0,0,.2)",
            }}
          >
            <div
              style={{
                background: "#4F46E5",
                color: "#fff",
                padding: "20px",
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems: "center",
              }}
            >
              <h2
                style={{
                  margin: 0,
                }}
              >
                Meeting Details
              </h2>

              <button
                type="button"
                onClick={() =>
                  setViewMeeting(null)
                }
                style={{
                  background:
                    "transparent",
                  border: "none",
                  color: "#fff",
                  fontSize: "20px",
                  cursor: "pointer",
                }}
              >
                <FaTimes />
              </button>
            </div>

            <div
              style={{
                padding: "25px",
                overflowY: "auto",
              }}
            >
              {[
                ["Meeting ID", viewMeeting.id],
                ["Title", viewMeeting.title],
                ["Date", viewMeeting.date],
                ["Time", viewMeeting.time],
                [
                  "Platform",
                  viewMeeting.platform,
                ],
                [
                  "Organizer",
                  viewMeeting.organizer,
                ],
                [
                  "Status",
                  viewMeeting.status,
                ],
              ].map(([label, value]) => (
                <div
                  key={label}
                  style={{
                    display: "flex",
                    justifyContent:
                      "space-between",
                    padding: "12px 0",
                    borderBottom:
                      "1px solid #E2E8F0",
                    gap: "20px",
                  }}
                >
                  <strong
                    style={{
                      color: "#64748B",
                    }}
                  >
                    {label}
                  </strong>

                  <span
                    style={{
                      color: "#1E293B",
                      fontWeight: "600",
                      textAlign: "right",
                    }}
                  >
                    {value || "-"}
                  </span>
                </div>
              ))}

              <button
                type="button"
                onClick={() =>
                  setViewMeeting(null)
                }
                style={{
                  width: "100%",
                  marginTop: "20px",
                  background: "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding: "12px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "600",
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MeetingScheduler;