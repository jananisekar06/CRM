import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaSearch,
  FaPlus,
  FaComments,
  FaUsers,
  FaFileAlt,
  FaBullhorn,
  FaEdit,
  FaTrash,
  FaTimes,
  FaDownload,
} from "react-icons/fa";

function Collaboration() {
  const [search, setSearch] = useState("");
  const [teamChats, setTeamChats] = useState([]);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    employee: "",
    type: "One-to-One",
    lastMessage: "",
    status: "Online",
  });

  const API_URL = "http://localhost:5000/api/collaborations";

  // =========================
  // GET COLLABORATIONS
  // =========================
  const fetchCollaborations = async () => {
    try {
      const response = await axios.get(API_URL);
      setTeamChats(response.data);
    } catch (error) {
      console.error("Error fetching collaborations:", error);
      alert("Unable to load collaboration data");
    }
  };

  useEffect(() => {
    fetchCollaborations();
  }, []);

  // =========================
  // SEARCH
  // =========================
  const filteredChats = teamChats.filter(
    (chat) =>
      chat.employee?.toLowerCase().includes(search.toLowerCase()) ||
      chat.type?.toLowerCase().includes(search.toLowerCase()) ||
      chat.lastMessage?.toLowerCase().includes(search.toLowerCase())
  );

  // =========================
  // FORM INPUT
  // =========================
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // =========================
  // OPEN ADD MODAL
  // =========================
  const handleAdd = () => {
    setEditingId(null);

    setForm({
      employee: "",
      type: "One-to-One",
      lastMessage: "",
      status: "Online",
    });

    setShowModal(true);
  };

  // =========================
  // OPEN EDIT MODAL
  // =========================
  const handleEdit = (chat) => {
    setEditingId(chat.id);

    setForm({
      employee: chat.employee,
      type: chat.type,
      lastMessage: chat.lastMessage,
      status: chat.status,
    });

    setShowModal(true);
  };

  // =========================
  // SAVE / UPDATE
  // =========================
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !form.employee.trim() ||
      !form.type.trim() ||
      !form.lastMessage.trim() ||
      !form.status.trim()
    ) {
      alert("Please fill all fields");
      return;
    }

    try {
      if (editingId) {
        await axios.put(`${API_URL}/${editingId}`, form);
        alert("Collaboration updated successfully");
      } else {
        await axios.post(API_URL, form);
        alert("Collaboration added successfully");
      }

      setShowModal(false);

      setForm({
        employee: "",
        type: "One-to-One",
        lastMessage: "",
        status: "Online",
      });

      setEditingId(null);

      fetchCollaborations();
    } catch (error) {
      console.error("Save error:", error);

      alert(
        error.response?.data?.message ||
          "Something went wrong while saving"
      );
    }
  };

  // =========================
  // DELETE
  // =========================
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this collaboration?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(`${API_URL}/${id}`);

      alert("Collaboration deleted successfully");

      fetchCollaborations();
    } catch (error) {
      console.error("Delete error:", error);

      alert(
        error.response?.data?.message ||
          "Unable to delete collaboration"
      );
    }
  };

  // =========================
  // DOWNLOAD DOCUMENT
  // =========================
  const handleDownload = (fileName) => {
    try {
      const fileUrl = `/documents/${fileName}`;

      const link = document.createElement("a");
      link.href = fileUrl;
      link.download = fileName;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Download error:", error);
      alert("Unable to download file");
    }
  };

  // =========================
  // STATUS COLOR
  // =========================
  const getStatusColor = (status) => {
    if (status === "Online") return "#22C55E";
    if (status === "Offline") return "#EF4444";
    return "#F59E0B";
  };

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Collaboration
              </h1>

              <p style={{ color: "#64748B" }}>
                Team collaboration and communication
              </p>
            </div>

            <button
              onClick={handleAdd}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              New Collaboration
            </button>
          </div>

          {/* ================= DASHBOARD CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={cardStyle("#EEF2FF")}>
              <FaComments size={28} color="#4F46E5" />

              <h3>Active Chats</h3>

              <h2>
                {
                  teamChats.filter(
                    (chat) => chat.status === "Online"
                  ).length
                }
              </h2>
            </div>

            <div style={cardStyle("#DCFCE7")}>
              <FaUsers size={28} color="#16A34A" />

              <h3>Team Members</h3>

              <h2>
                {new Set(
                  teamChats.map((chat) => chat.employee)
                ).size}
              </h2>
            </div>

            <div style={cardStyle("#DBEAFE")}>
              <FaFileAlt size={28} color="#2563EB" />

              <h3>Shared Files</h3>

              <h2>324</h2>
            </div>

            <div style={cardStyle("#FEF3C7")}>
              <FaBullhorn size={28} color="#D97706" />

              <h3>Announcements</h3>

              <h2>17</h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Team Member..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TEAM CHAT TABLE ================= */}

          <div style={sectionStyle}>
            <h2 style={sectionTitle}>
              Team Collaboration
            </h2>

            <div style={{ overflowX: "auto" }}>
              <table style={tableStyle}>
                <thead style={theadStyle}>
                  <tr>
                    <th style={thStyle}>Chat ID</th>
                    <th>Employee</th>
                    <th>Chat Type</th>
                    <th>Last Message</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredChats.map((chat) => (
                    <tr
                      key={chat.id}
                      style={rowStyle}
                    >
                      <td style={tdStyle}>
                        {chat.id}
                      </td>

                      <td>{chat.employee}</td>

                      <td>{chat.type}</td>

                      <td>{chat.lastMessage}</td>

                      <td>
                        <Status
                          text={chat.status}
                          color={getStatusColor(chat.status)}
                        />
                      </td>

                      <td>
                        <button
                          onClick={() => handleEdit(chat)}
                          style={editButton}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(chat.id)
                          }
                          style={deleteButton}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))}

                  {filteredChats.length === 0 && (
                    <tr>
                      <td
                        colSpan="6"
                        style={{
                          padding: "25px",
                          textAlign: "center",
                          color: "#64748B",
                        }}
                      >
                        No team chats found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* ================= SHARED CALENDAR ================= */}

          <div style={sectionStyle}>
            <h2 style={sectionTitle}>
              Shared Calendar
            </h2>

            <table style={tableStyle}>
              <thead style={theadStyle}>
                <tr>
                  <th style={thStyle}>Event ID</th>
                  <th>Event</th>
                  <th>Date</th>
                  <th>Department</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={rowStyle}>
                  <td style={tdStyle}>EV001</td>
                  <td>Project Meeting</td>
                  <td>15-08-2026</td>
                  <td>Development</td>
                  <td>
                    <Status
                      text="Scheduled"
                      color="#22C55E"
                    />
                  </td>
                </tr>

                <tr style={rowStyle}>
                  <td style={tdStyle}>EV002</td>
                  <td>Independence Day</td>
                  <td>15-08-2026</td>
                  <td>Holiday</td>
                  <td>
                    <Status
                      text="Holiday"
                      color="#3B82F6"
                    />
                  </td>
                </tr>

                <tr style={rowStyle}>
                  <td style={tdStyle}>EV003</td>
                  <td>Employee Birthday</td>
                  <td>20-08-2026</td>
                  <td>HR</td>
                  <td>
                    <Status
                      text="Upcoming"
                      color="#F59E0B"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ================= SHARED DOCUMENTS ================= */}

          <div style={sectionStyle}>
            <h2 style={sectionTitle}>
              Shared Documents
            </h2>

            <table style={tableStyle}>
              <thead style={theadStyle}>
                <tr>
                  <th style={thStyle}>Document</th>
                  <th>Uploaded By</th>
                  <th>Shared With</th>
                  <th>Permission</th>
                  <th>Download</th>
                </tr>
              </thead>

              <tbody>

                {/* Project Plan */}
                <tr style={rowStyle}>
                  <td style={tdStyle}>
                    ProjectPlan.pdf
                  </td>

                  <td>John</td>

                  <td>Development Team</td>

                  <td>
                    <Status
                      text="Read/Write"
                      color="#22C55E"
                    />
                  </td>

                  <td>
                    <button
                      onClick={() =>
                        handleDownload("ProjectPlan.pdf")
                      }
                      style={downloadButton}
                    >
                      <FaDownload />
                      <span>Download</span>
                    </button>
                  </td>
                </tr>

                {/* Sales Report */}
                <tr style={rowStyle}>
                  <td style={tdStyle}>
                    SalesReport.xlsx
                  </td>

                  <td>Priya</td>

                  <td>Sales Team</td>

                  <td>
                    <Status
                      text="Read Only"
                      color="#3B82F6"
                    />
                  </td>

                  <td>
                    <button
                      onClick={() =>
                        handleDownload("SalesReport.xlsx")
                      }
                      style={downloadButton}
                    >
                      <FaDownload />
                      <span>Download</span>
                    </button>
                  </td>
                </tr>

                {/* HR Policy */}
                <tr style={rowStyle}>
                  <td style={tdStyle}>
                    HRPolicy.docx
                  </td>

                  <td>HR Manager</td>

                  <td>All Employees</td>

                  <td>
                    <Status
                      text="Restricted"
                      color="#F59E0B"
                    />
                  </td>

                  <td>
                    <button
                      onClick={() =>
                        handleDownload("HRPolicy.docx")
                      }
                      style={downloadButton}
                    >
                      <FaDownload />
                      <span>Download</span>
                    </button>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>

          {/* ================= ANNOUNCEMENTS ================= */}

          <div style={sectionStyle}>
            <h2 style={sectionTitle}>
              Team Announcements
            </h2>

            <table style={tableStyle}>
              <thead style={theadStyle}>
                <tr>
                  <th style={thStyle}>Announcement ID</th>
                  <th>Title</th>
                  <th>Department</th>
                  <th>Posted By</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={rowStyle}>
                  <td style={tdStyle}>ANN001</td>
                  <td>HR Policy Update</td>
                  <td>HR</td>
                  <td>HR Manager</td>
                  <td>10-08-2026</td>
                  <td>
                    <Status
                      text="Read"
                      color="#22C55E"
                    />
                  </td>
                </tr>

                <tr style={rowStyle}>
                  <td style={tdStyle}>ANN002</td>
                  <td>Monthly Sales Meeting</td>
                  <td>Sales</td>
                  <td>Sales Manager</td>
                  <td>12-08-2026</td>
                  <td>
                    <Status
                      text="Unread"
                      color="#F59E0B"
                    />
                  </td>
                </tr>

                <tr style={rowStyle}>
                  <td style={tdStyle}>ANN003</td>
                  <td>Office Holiday Notice</td>
                  <td>Admin</td>
                  <td>Administrator</td>
                  <td>15-08-2026</td>
                  <td>
                    <Status
                      text="Published"
                      color="#3B82F6"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ================= SUMMARY ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginTop: "35px",
            }}
          >
            <div style={summaryCard("#EEF2FF")}>
              <h3>Active Chats</h3>

              <h2>
                {
                  teamChats.filter(
                    (chat) => chat.status === "Online"
                  ).length
                }
              </h2>
            </div>

            <div style={summaryCard("#DCFCE7")}>
              <h3>Shared Files</h3>
              <h2>324</h2>
            </div>

            <div style={summaryCard("#DBEAFE")}>
              <h3>Calendar Events</h3>
              <h2>42</h2>
            </div>

            <div style={summaryCard("#FEF3C7")}>
              <h3>Announcements</h3>
              <h2>17</h2>
            </div>
          </div>

        </div>
      </div>

      {/* ================= MODAL ================= */}

      {showModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.55)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
            padding: "20px",
          }}
        >
          <div
            style={{
              background: "#fff",
              width: "450px",
              maxWidth: "100%",
              borderRadius: "15px",
              padding: "25px",
              boxShadow: "0 20px 50px rgba(0,0,0,.25)",
            }}
          >

            {/* Modal Header */}

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                {editingId
                  ? "Edit Collaboration"
                  : "New Collaboration"}
              </h2>

              <button
                onClick={() => setShowModal(false)}
                style={{
                  background: "#F1F5F9",
                  border: "none",
                  width: "35px",
                  height: "35px",
                  borderRadius: "50%",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <FaTimes />
              </button>
            </div>

            {/* Form */}

            <form onSubmit={handleSubmit}>

              <label style={labelStyle}>
                Employee
              </label>

              <input
                type="text"
                name="employee"
                value={form.employee}
                onChange={handleChange}
                placeholder="Enter employee name"
                style={inputStyle}
              />

              <label style={labelStyle}>
                Chat Type
              </label>

              <select
                name="type"
                value={form.type}
                onChange={handleChange}
                style={inputStyle}
              >
                <option value="One-to-One">
                  One-to-One
                </option>

                <option value="Group Chat">
                  Group Chat
                </option>
              </select>

              <label style={labelStyle}>
                Last Message
              </label>

              <input
                type="text"
                name="lastMessage"
                value={form.lastMessage}
                onChange={handleChange}
                placeholder="Enter last message"
                style={inputStyle}
              />

              <label style={labelStyle}>
                Status
              </label>

              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                style={inputStyle}
              >
                <option value="Online">
                  Online
                </option>

                <option value="Offline">
                  Offline
                </option>

                <option value="Busy">
                  Busy
                </option>
              </select>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "10px",
                  marginTop: "20px",
                }}
              >
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  style={{
                    background: "#64748B",
                    color: "#fff",
                    border: "none",
                    padding: "10px 18px",
                    borderRadius: "7px",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  style={{
                    background: "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding: "10px 20px",
                    borderRadius: "7px",
                    cursor: "pointer",
                  }}
                >
                  {editingId ? "Update" : "Save"}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// =========================
// STYLES
// =========================

const cardStyle = (background) => ({
  background,
  padding: "20px",
  borderRadius: "12px",
});

const sectionStyle = {
  marginTop: "35px",
  background: "#fff",
  borderRadius: "15px",
  padding: "20px",
  boxShadow: "0 5px 15px rgba(0,0,0,.08)",
  overflowX: "auto",
};

const sectionTitle = {
  marginTop: 0,
  color: "#334155",
  marginBottom: "20px",
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  minWidth: "750px",
};

const theadStyle = {
  background: "#4F46E5",
  color: "#fff",
};

const thStyle = {
  padding: "12px 15px",
  whiteSpace: "nowrap",
};

const rowStyle = {
  textAlign: "center",
  borderBottom: "1px solid #E2E8F0",
};

const tdStyle = {
  padding: "12px 15px",
};

const downloadButton = {
  background: "#4F46E5",
  color: "#fff",
  border: "none",
  padding: "8px 13px",
  borderRadius: "6px",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  gap: "7px",
};

const editButton = {
  background: "#F59E0B",
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  marginRight: "8px",
  cursor: "pointer",
};

const deleteButton = {
  background: "#EF4444",
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  cursor: "pointer",
};

const summaryCard = (background) => ({
  background,
  padding: "20px",
  borderRadius: "12px",
});

const labelStyle = {
  display: "block",
  marginBottom: "7px",
  marginTop: "14px",
  color: "#334155",
  fontWeight: "600",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "11px 12px",
  border: "1px solid #CBD5E1",
  borderRadius: "7px",
  outline: "none",
};

function Status({ text, color }) {
  return (
    <span
      style={{
        background: color,
        color: "#fff",
        padding: "5px 12px",
        borderRadius: "20px",
        fontSize: "12px",
      }}
    >
      {text}
    </span>
  );
}

export default Collaboration;