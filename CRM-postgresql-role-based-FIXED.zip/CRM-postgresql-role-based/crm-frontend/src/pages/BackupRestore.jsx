
import { useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaDatabase,
  FaDownload,
  FaUpload,
  FaRedo,
  FaSearch,
  FaPlus,
  FaCheckCircle,
  FaExclamationCircle,
} from "react-icons/fa";

function BackupRestore() {
  const [search, setSearch] = useState("");

  const [backups, setBackups] = useState([
    {
      id: "BK001",
      type: "Automatic",
      date: "05-08-2026",
      time: "02:00 AM",
      size: "150 MB",
      status: "Completed",
    },
    {
      id: "BK002",
      type: "Manual",
      date: "06-08-2026",
      time: "10:30 AM",
      size: "155 MB",
      status: "Completed",
    },
    {
      id: "BK003",
      type: "Automatic",
      date: "07-08-2026",
      time: "02:00 AM",
      size: "160 MB",
      status: "Scheduled",
    },
  ]);

  const [backupName, setBackupName] = useState("");
  const [backupType, setBackupType] = useState("Automatic");
  const [storageLocation, setStorageLocation] =
    useState("Local Storage");
  const [backupFile, setBackupFile] = useState(null);
  const [backupFrequency, setBackupFrequency] = useState("Daily");
  const [backupTime, setBackupTime] = useState("");

  const [restoreFile, setRestoreFile] = useState(null);
  const [restoreMessage, setRestoreMessage] = useState("");
  const [restoreLoading, setRestoreLoading] = useState(false);

  const [backupMessage, setBackupMessage] = useState("");

  // Search
  const filteredBackups = backups.filter((item) =>
    item.id.toLowerCase().includes(search.toLowerCase())
  );

  // Manual Backup
  const handleManualBackup = () => {
    const newBackup = {
      id: `BK${String(backups.length + 1).padStart(3, "0")}`,
      type: "Manual",
      date: new Date().toLocaleDateString("en-GB"),
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      size: "0 MB",
      status: "Completed",
    };

    setBackups((prev) => [newBackup, ...prev]);

    setBackupMessage("Manual backup created successfully.");

    setTimeout(() => {
      setBackupMessage("");
    }, 3000);
  };

  // Start Backup
  const handleStartBackup = () => {
    if (!backupName.trim()) {
      setBackupMessage("Please enter a backup name.");
      return;
    }

    const newBackup = {
      id: `BK${String(backups.length + 1).padStart(3, "0")}`,
      type: backupType,
      date: new Date().toLocaleDateString("en-GB"),
      time: backupTime || "Now",
      size: "0 MB",
      status: "Completed",
    };

    setBackups((prev) => [newBackup, ...prev]);

    setBackupMessage("Backup started successfully.");

    setBackupName("");
    setBackupTime("");
    setBackupFile(null);

    setTimeout(() => {
      setBackupMessage("");
    }, 3000);
  };

  // Select Restore File
  const handleRestoreFileChange = (e) => {
    const file = e.target.files[0];

    if (!file) {
      setRestoreFile(null);
      setRestoreMessage("");
      return;
    }

    setRestoreFile(file);
    setRestoreMessage("");
  };

  // Restore Backup
  const handleRestore = async () => {
    if (!restoreFile) {
      setRestoreMessage("Please select a backup file first.");
      return;
    }

    const confirmRestore = window.confirm(
      `Are you sure you want to restore "${restoreFile.name}"?`
    );

    if (!confirmRestore) return;

    setRestoreLoading(true);
    setRestoreMessage("");

    try {
      const formData = new FormData();

      formData.append("backupFile", restoreFile);

      const response = await axios.post(
        "http://localhost:5000/api/backup/restore",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setRestoreMessage(
        response.data.message || "Backup restored successfully!"
      );

      setRestoreFile(null);

      // Reset file input
      const fileInput = document.getElementById("restoreFileInput");

      if (fileInput) {
        fileInput.value = "";
      }
    } catch (error) {
      console.error("Restore Error:", error);

      setRestoreMessage(
        error.response?.data?.message ||
          "Restore failed. Please check the backend server."
      );
    } finally {
      setRestoreLoading(false);
    }
  };

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
            maxWidth: "1400px",
            margin: "0 auto",
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          {/* Header */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              flexWrap: "wrap",
              gap: "15px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Backup & Restore
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginBottom: 0,
                }}
              >
                Securely backup and restore company data.
              </p>
            </div>

            <button
              onClick={handleManualBackup}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <FaPlus />
              Manual Backup
            </button>
          </div>

          {/* Backup Message */}

          {backupMessage && (
            <div
              style={{
                background: "#DCFCE7",
                color: "#166534",
                padding: "12px 15px",
                borderRadius: "8px",
                marginBottom: "20px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaCheckCircle />
              {backupMessage}
            </div>
          )}

          {/* Dashboard Cards */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaDatabase size={30} color="#4F46E5" />

              <h3>Total Backups</h3>

              <h2>{backups.length}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaDownload size={30} color="#16A34A" />

              <h3>Automatic</h3>

              <h2>
                {
                  backups.filter(
                    (backup) => backup.type === "Automatic"
                  ).length
                }
              </h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaUpload size={30} color="#2563EB" />

              <h3>Manual</h3>

              <h2>
                {
                  backups.filter(
                    (backup) => backup.type === "Manual"
                  ).length
                }
              </h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaRedo size={30} color="#D97706" />

              <h3>Restores</h3>

              <h2>18</h2>
            </div>
          </div>

          {/* Search */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "100%",
                maxWidth: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  top: "14px",
                  left: "15px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Backup ID..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* Backup History */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                minWidth: "750px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>Backup ID</th>
                  <th>Type</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>File Size</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {filteredBackups.map((item) => (
                  <tr
                    key={item.id}
                    style={{
                      textAlign: "center",
                      borderBottom:
                        "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>
                      {item.id}
                    </td>

                    <td>{item.type}</td>

                    <td>{item.date}</td>

                    <td>{item.time}</td>

                    <td>{item.size}</td>

                    <td>
                      <span
                        style={{
                          background:
                            item.status === "Completed"
                              ? "#22C55E"
                              : "#F59E0B",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                          fontSize: "12px",
                        }}
                      >
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}

                {filteredBackups.length === 0 && (
                  <tr>
                    <td
                      colSpan="6"
                      style={{
                        padding: "25px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No backup records found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Backup & Restore Form */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginTop: 0,
                marginBottom: "20px",
              }}
            >
              Backup & Restore
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(280px, 1fr))",
                gap: "20px",
              }}
            >
              {/* Backup Name */}

              <div>
                <label
                  style={labelStyle}
                >
                  Backup Name
                </label>

                <input
                  type="text"
                  placeholder="Daily Backup"
                  value={backupName}
                  onChange={(e) =>
                    setBackupName(e.target.value)
                  }
                  style={inputStyle}
                />
              </div>

              {/* Backup Type */}

              <div>
                <label style={labelStyle}>
                  Backup Type
                </label>

                <select
                  value={backupType}
                  onChange={(e) =>
                    setBackupType(e.target.value)
                  }
                  style={inputStyle}
                >
                  <option>Automatic</option>
                  <option>Manual</option>
                </select>
              </div>

              {/* Storage */}

              <div>
                <label style={labelStyle}>
                  Storage Location
                </label>

                <select
                  value={storageLocation}
                  onChange={(e) =>
                    setStorageLocation(e.target.value)
                  }
                  style={inputStyle}
                >
                  <option>Local Storage</option>
                  <option>Cloud Storage</option>
                </select>
              </div>

              {/* Backup File */}

              <div>
                <label style={labelStyle}>
                  Backup File
                </label>

                <input
                  type="file"
                  accept=".sql,.json,.zip"
                  onChange={(e) =>
                    setBackupFile(
                      e.target.files[0] || null
                    )
                  }
                  style={inputStyle}
                />

                {backupFile && (
                  <small
                    style={{
                      color: "#64748B",
                      display: "block",
                      marginTop: "6px",
                    }}
                  >
                    Selected: {backupFile.name}
                  </small>
                )}
              </div>

              {/* Automatic Backup */}

              <div>
                <label style={labelStyle}>
                  Automatic Backup
                </label>

                <select
                  value={backupFrequency}
                  onChange={(e) =>
                    setBackupFrequency(e.target.value)
                  }
                  style={inputStyle}
                >
                  <option>Daily</option>
                  <option>Weekly</option>
                  <option>Monthly</option>
                </select>
              </div>

              {/* Backup Time */}

              <div>
                <label style={labelStyle}>
                  Backup Time
                </label>

                <input
                  type="time"
                  value={backupTime}
                  onChange={(e) =>
                    setBackupTime(e.target.value)
                  }
                  style={inputStyle}
                />
              </div>

              {/* Restore File */}

              <div
                style={{
                  gridColumn: "1 / -1",
                  background: "#F8FAFC",
                  padding: "20px",
                  borderRadius: "10px",
                  border:
                    "1px solid #E2E8F0",
                }}
              >
                <label
                  style={{
                    ...labelStyle,
                    fontSize: "16px",
                    fontWeight: "600",
                  }}
                >
                  Select Backup File to Restore
                </label>

                <input
                  id="restoreFileInput"
                  type="file"
                  accept=".sql,.json,.zip"
                  onChange={handleRestoreFileChange}
                  style={inputStyle}
                />

                {restoreFile && (
                  <div
                    style={{
                      marginTop: "10px",
                      color: "#334155",
                      fontSize: "14px",
                    }}
                  >
                    Selected file:{" "}
                    <strong>
                      {restoreFile.name}
                    </strong>
                  </div>
                )}

                {restoreMessage && (
                  <div
                    style={{
                      marginTop: "12px",
                      padding: "10px 12px",
                      borderRadius: "7px",
                      background:
                        restoreMessage
                          .toLowerCase()
                          .includes("failed")
                          ? "#FEE2E2"
                          : "#DCFCE7",
                      color:
                        restoreMessage
                          .toLowerCase()
                          .includes("failed")
                          ? "#B91C1C"
                          : "#166534",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    {restoreMessage
                      .toLowerCase()
                      .includes("failed") ? (
                      <FaExclamationCircle />
                    ) : (
                      <FaCheckCircle />
                    )}

                    {restoreMessage}
                  </div>
                )}
              </div>
            </div>

            {/* Buttons */}

            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: "15px",
                marginTop: "25px",
                flexWrap: "wrap",
              }}
            >
              <button
                onClick={handleStartBackup}
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <FaDatabase />
                Start Backup
              </button>

              <button
                onClick={handleRestore}
                disabled={
                  !restoreFile || restoreLoading
                }
                style={{
                  background:
                    !restoreFile || restoreLoading
                      ? "#94A3B8"
                      : "#16A34A",
                  color: "#fff",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor:
                    !restoreFile || restoreLoading
                      ? "not-allowed"
                      : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <FaRedo />

                {restoreLoading
                  ? "Restoring..."
                  : "Restore Backup"}
              </button>
            </div>
          </div>

          {/* Backup Statistics */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Successful</h3>
              <h2>115</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Scheduled</h3>
              <h2>5</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Restored</h3>
              <h2>18</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Failed</h3>
              <h2>2</h2>
            </div>
          </div>

          {/* Recent Restore History */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
              overflowX: "auto",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginTop: 0,
              }}
            >
              Recent Restore History
            </h2>

            <table
              style={{
                width: "100%",
                minWidth: "650px",
                marginTop: "20px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "12px" }}>
                    Backup ID
                  </th>

                  <th>Restore Date</th>

                  <th>Restored By</th>

                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr
                  style={{
                    textAlign: "center",
                    borderBottom:
                      "1px solid #E2E8F0",
                  }}
                >
                  <td style={{ padding: "12px" }}>
                    BK001
                  </td>

                  <td>05-08-2026</td>

                  <td>Admin</td>

                  <td>
                    <span style={successBadge}>
                      Success
                    </span>
                  </td>
                </tr>

                <tr
                  style={{
                    textAlign: "center",
                    borderBottom:
                      "1px solid #E2E8F0",
                  }}
                >
                  <td style={{ padding: "12px" }}>
                    BK002
                  </td>

                  <td>06-08-2026</td>

                  <td>Super Admin</td>

                  <td>
                    <span style={successBadge}>
                      Success
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Card */

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

/* Input */

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

/* Label */

const labelStyle = {
  color: "#334155",
  fontWeight: "500",
};

/* Success Badge */

const successBadge = {
  background: "#22C55E",
  color: "#fff",
  padding: "5px 12px",
  borderRadius: "20px",
  fontSize: "12px",
};

export default BackupRestore;
