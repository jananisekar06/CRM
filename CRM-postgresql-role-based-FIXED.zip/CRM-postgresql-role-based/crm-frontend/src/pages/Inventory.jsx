import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaBoxes,
} from "react-icons/fa";

function Inventory() {
  const [search, setSearch] = useState("");
const [products, setProducts] = useState([]);
useEffect(() => {
  fetchProducts();
}, []);
const [editingId, setEditingId] = useState(null);
const [form, setForm] = useState({
  id: "",
  name: "",
  stock: "",
  purchase: "",
  sales: "",
  status: "In Stock",
});

const [showForm, setShowForm] = useState(false);
  useEffect(() => {
  axios
    .get("http://localhost:5000/api/inventory")
    .then((response) => {
      setProducts(response.data);
    })
    .catch((error) => {
      console.error("Error fetching products:", error);
    });
}, []);

const handleSubmit = async (e) => {
  e.preventDefault();

  if (
    !form.id.trim() ||
    !form.name.trim() ||
    !form.stock ||
    !form.purchase ||
    !form.sales
  ) {
    alert("Please fill all fields");
    return;
  }

  try {
    // UPDATE
    if (editingId !== null) {
      const response = await axios.put(
        `http://localhost:5000/api/inventory/${editingId}`,
        form
      );

      setProducts(
        products.map((product) =>
          String(product.id) === String(editingId)
            ? response.data.product
            : product
        )
      );

      alert("Product Updated Successfully");

      setEditingId(null);
    }

    // ADD
    else {
      const response = await axios.post(
        "http://localhost:5000/api/inventory",
        form
      );

      setProducts([...products, response.data.product]);

      alert("Product Added Successfully");
    }

    setForm({
      id: "",
      name: "",
      stock: "",
      purchase: "",
      sales: "",
      status: "In Stock",
    });

    setShowForm(false);

  } catch (error) {
    console.error("Error saving product:", error);
    alert("Failed to save product");
  }
};
const handleDelete = async (id) => {
  if (!window.confirm("Are you sure you want to delete this product?")) {
    return;
  }

  try {
    await axios.delete(
      `http://localhost:5000/api/inventory/${id}`
    );

    setProducts(
      products.filter((product) => product.id !== id)
    );

    alert("Product Deleted Successfully");
 } catch (error) {
  console.error("Delete Error:", error);
  console.log("Response:", error.response?.data);
  alert(
    error.response?.data?.message || "Failed to delete product"
  );
}
};
const fetchProducts = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/inventory"
    );

    setProducts(response.data);
  } catch (error) {
    console.error("Error fetching products:", error);
  }
};
const handleEdit = (product) => {
  setEditingId(product.id);

  setForm({
    id: product.id,
    name: product.name,
    stock: product.stock,
    purchase: product.purchase,
    sales: product.sales,
    status: product.status,
  });

  setShowForm(true);
};
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
   <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* Header */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1 style={{ margin: 0, color: "#334155" }}>
                Inventory Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage products and stock
              </p>
            </div>

            <button
             onClick={() => setShowForm(true)}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Add Product
            </button>
          </div>


{showForm && (
  <div
    style={{
      background: "#fff",
      padding: "25px",
      borderRadius: "12px",
      marginBottom: "25px",
      boxShadow: "0 5px 15px rgba(0,0,0,.08)",
    }}
  >
    <h2 style={{ marginTop: 0 }}>Add Product</h2>

    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(2, 1fr)",
        gap: "20px",
      }}
    >
      <input
        type="text"
        placeholder="Product ID"
        value={form.id}
        onChange={(e) =>
          setForm({ ...form, id: e.target.value })
        }
        style={inputStyle}
      />

      <input
        type="text"
        placeholder="Product Name"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
        style={inputStyle}
      />

      <input
        type="number"
        placeholder="Stock"
        value={form.stock}
        onChange={(e) =>
          setForm({ ...form, stock: e.target.value })
        }
        style={inputStyle}
      />

      <input
        type="number"
        placeholder="Purchase"
        value={form.purchase}
        onChange={(e) =>
          setForm({ ...form, purchase: e.target.value })
        }
        style={inputStyle}
      />

      <input
        type="number"
        placeholder="Sales"
        value={form.sales}
        onChange={(e) =>
          setForm({ ...form, sales: e.target.value })
        }
        style={inputStyle}
      />

      <select
        value={form.status}
        onChange={(e) =>
          setForm({ ...form, status: e.target.value })
        }
        style={inputStyle}
      >
        <option value="In Stock">In Stock</option>
        <option value="Low Stock">Low Stock</option>
      </select>
    </div>

    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        gap: "10px",
        marginTop: "20px",
      }}
    >
      <button
        type="button"
        onClick={() => {
  setShowForm(false);
  setEditingId(null);

  setForm({
    id: "",
    name: "",
    stock: "",
    purchase: "",
    sales: "",
    status: "In Stock",
  });
}}
        style={{
          background: "#64748B",
          color: "#fff",
          border: "none",
          padding: "10px 20px",
          borderRadius: "7px",
          cursor: "pointer",
        }}
      >
        Cancel
      </button>
<button
  type="button"
  onClick={handleSubmit}
        style={{
          background: "#4F46E5",
          color: "#fff",
          border: "none",
          padding: "10px 20px",
          borderRadius: "7px",
          cursor: "pointer",
        }}
      >
        Save Product
      </button>
    </div>
  </div>
)}


          {/* Search */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Product..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                }}
              />
            </div>
          </div>

          {/* Table */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>Product ID</th>
                  <th>Product</th>
                  <th>Stock</th>
                  <th>Purchase</th>
                  <th>Sales</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredProducts.map((product) => (
                  <tr
                    key={product.id}
                    style={{
                      textAlign: "center",
                      borderBottom: "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>{product.id}</td>
                    <td>{product.name}</td>
                    <td>{product.stock}</td>
                    <td>{product.purchase}</td>
                    <td>{product.sales}</td>

                    <td>
                      <span
                        style={{
                          background:
                            product.status === "In Stock"
                              ? "#22C55E"
                              : "#EF4444",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                          fontSize: "12px",
                        }}
                      >
                        {product.status}
                      </span>
                    </td>

                    <td>
                      <button
                      onClick={() => handleEdit(product)}
                        style={{
                          background: "#F59E0B",
                          color: "#fff",
                          border: "none",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          marginRight: "8px",
                          cursor: "pointer",
                        }}
                      >
                        <FaEdit />
                      </button>

                     <button
  onClick={() => handleDelete(product.id)}
  style={{
    background: "#EF4444",
    color: "#fff",
    border: "none",
    padding: "8px 10px",
    borderRadius: "6px",
    cursor: "pointer",
  }}
>
  <FaTrash />
</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary Cards */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaBoxes size={30} color="#4F46E5" />
              <h3>Total Products</h3>
              <h2>{products.length}</h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Total Purchase</h3>
              <h2>
                {products.reduce((sum, p) => sum + p.purchase, 0)}
              </h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Total Sales</h3>
              <h2>
                {products.reduce((sum, p) => sum + p.sales, 0)}
              </h2>
            </div>

            <div
              style={{
                background: "#FEE2E2",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Low Stock</h3>
              <h2>
                {
                  products.filter(
                    (p) => p.status === "Low Stock"
                  ).length
                }
              </h2>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "12px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};
export default Inventory;