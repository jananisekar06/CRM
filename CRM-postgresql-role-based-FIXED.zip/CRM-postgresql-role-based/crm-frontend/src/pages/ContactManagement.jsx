
import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaAddressBook,
  FaBuilding,
  FaUsers,
  FaPhone,
  FaEnvelope,
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
} from "react-icons/fa";

function ContactManagement() {
  const [search, setSearch] = useState("");
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [contactData, setContactData] = useState({
    company: "",
    name: "",
    role: "Manager",
    phone: "",
    email: "",
    primaryContact: "Yes",
    status: "Active",
    notes: "",
  });

  // =========================
  // FETCH CONTACTS
  // =========================

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/contacts"
      );

      setContacts(
        Array.isArray(response.data) ? response.data : []
      );
    } catch (error) {
      console.error("Contact Fetch Error:", error);
      alert("Failed to fetch contacts");
      setContacts([]);
    }
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setContactData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // SAVE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !contactData.company ||
      !contactData.name ||
      !contactData.phone ||
      !contactData.email
    ) {
      alert("Please fill all required fields");
      return;
    }

    try {
      setLoading(true);

      if (editingId) {
        // UPDATE
        const response = await axios.put(
          `http://localhost:5000/api/contacts/${editingId}`,
          contactData
        );

        setContacts((prev) =>
          prev.map((contact) =>
            contact.id === editingId
              ? response.data.contact
              : contact
          )
        );

        alert(
          response.data.message ||
            "Contact updated successfully"
        );
      } else {
        // CREATE
        const response = await axios.post(
          "http://localhost:5000/api/contacts",
          contactData
        );

        if (response.data.contact) {
          setContacts((prev) => [
            ...prev,
            response.data.contact,
          ]);
        }

        alert(
          response.data.message ||
            "Contact created successfully"
        );
      }

      handleReset();
    } catch (error) {
      console.error("Contact Save Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to save contact"
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // EDIT
  // =========================

  const handleEdit = (contact) => {
    setEditingId(contact.id);

    setContactData({
      company: contact.company || "",
      name: contact.name || "",
      role: contact.role || "Manager",
      phone: contact.phone || "",
      email: contact.email || "",
      primaryContact: contact.primaryContact || "Yes",
      status: contact.status || "Active",
      notes: contact.notes || "",
    });

    document
      .getElementById("contact-form")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this contact?"
    );

    if (!confirmDelete) return;

    try {
      const response = await axios.delete(
        `http://localhost:5000/api/contacts/${id}`
      );

      setContacts((prev) =>
        prev.filter((contact) => contact.id !== id)
      );

      if (editingId === id) {
        handleReset();
      }

      alert(
        response.data.message ||
          "Contact deleted successfully"
      );
    } catch (error) {
      console.error("Contact Delete Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete contact"
      );
    }
  };

  // =========================
  // RESET
  // =========================

  const handleReset = () => {
    setContactData({
      company: "",
      name: "",
      role: "Manager",
      phone: "",
      email: "",
      primaryContact: "Yes",
      status: "Active",
      notes: "",
    });

    setEditingId(null);
  };

  // =========================
  // SEARCH
  // =========================

  const filteredContacts = contacts.filter((contact) => {
    const searchText = search.toLowerCase();

    return (
      String(contact.company || "")
        .toLowerCase()
        .includes(searchText) ||
      String(contact.name || "")
        .toLowerCase()
        .includes(searchText) ||
      String(contact.role || "")
        .toLowerCase()
        .includes(searchText) ||
      String(contact.phone || "")
        .toLowerCase()
        .includes(searchText) ||
      String(contact.email || "")
        .toLowerCase()
        .includes(searchText)
    );
  });

  // =========================
  // STATISTICS
  // =========================

  const companiesCount = new Set(
    contacts
      .map((contact) => contact.company)
      .filter(Boolean)
  ).size;

  const primaryContacts = contacts.filter(
    (contact) => contact.primaryContact === "Yes"
  ).length;

  const managers = contacts.filter(
    (contact) => contact.role === "Manager"
  ).length;

  const hrContacts = contacts.filter(
    (contact) => contact.role === "HR"
  ).length;

  const ceos = contacts.filter(
    (contact) => contact.role === "CEO"
  ).length;

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Contact Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage multiple contacts for customer
                companies.
              </p>
            </div>

            <button
              onClick={() => {
                handleReset();

                document
                  .getElementById("contact-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  });
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Add Contact
            </button>
          </div>

          {/* ================= DASHBOARD CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaBuilding
                size={30}
                color="#4F46E5"
              />

              <h3>Companies</h3>
              <h2>{companiesCount}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaUsers
                size={30}
                color="#16A34A"
              />

              <h3>Total Contacts</h3>
              <h2>{contacts.length}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaPhone
                size={30}
                color="#2563EB"
              />

              <h3>Calls Today</h3>
              <h2>0</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaEnvelope
                size={30}
                color="#D97706"
              />

              <h3>Emails Sent</h3>
              <h2>0</h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              position: "relative",
              width: "350px",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position: "absolute",
                top: "14px",
                left: "15px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search Contact..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              style={{
                width: "100%",
                padding:
                  "12px 15px 12px 45px",
                border:
                  "1px solid #CBD5E1",
                borderRadius: "8px",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
          </div>

          {/* ================= CONTACT TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Contact ID
                  </th>

                  <th>Company</th>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredContacts.map(
                  (contact) => (
                    <tr
                      key={contact.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {contact.id}
                      </td>

                      <td>
                        {contact.company}
                      </td>

                      <td>{contact.name}</td>

                      <td>{contact.role}</td>

                      <td>{contact.phone}</td>

                      <td>{contact.email}</td>

                      <td>
                        <span
                          style={{
                            background:
                              contact.status ===
                              "Active"
                                ? "#22C55E"
                                : "#EF4444",
                            color: "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize: "12px",
                          }}
                        >
                          {contact.status}
                        </span>
                      </td>

                      <td>
                        <button
                          onClick={() =>
                            handleEdit(contact)
                          }
                          style={{
                            background:
                              "#F59E0B",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 12px",
                            borderRadius:
                              "6px",
                            cursor: "pointer",
                            marginRight: "8px",
                          }}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(
                              contact.id
                            )
                          }
                          style={{
                            background:
                              "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding:
                              "8px 12px",
                            borderRadius:
                              "6px",
                            cursor: "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  )
                )}

                {filteredContacts.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="8"
                      style={{
                        padding: "25px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No contacts found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= ADD / UPDATE FORM ================= */}

          <div
            id="contact-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Update Contact"
                : "Add New Contact"}
            </h2>

            <form onSubmit={handleSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2,1fr)",
                  gap: "20px",
                }}
              >
                {/* COMPANY */}

                <div>
                  <label>
                    Company Name
                  </label>

                  <input
                    type="text"
                    name="company"
                    value={
                      contactData.company
                    }
                    onChange={handleChange}
                    placeholder="ABC Company"
                    style={inputStyle}
                  />
                </div>

                {/* NAME */}

                <div>
                  <label>
                    Contact Name
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={
                      contactData.name
                    }
                    onChange={handleChange}
                    placeholder="John Smith"
                    style={inputStyle}
                  />
                </div>

                {/* ROLE */}

                <div>
                  <label>Role</label>

                  <select
                    name="role"
                    value={
                      contactData.role
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Manager">
                      Manager
                    </option>

                    <option value="HR">
                      HR
                    </option>

                    <option value="CEO">
                      CEO
                    </option>

                    <option value="Accounts">
                      Accounts
                    </option>

                    <option value="Sales Head">
                      Sales Head
                    </option>

                    <option value="Support">
                      Support
                    </option>
                  </select>
                </div>

                {/* PHONE */}

                <div>
                  <label>
                    Phone Number
                  </label>

                  <input
                    type="tel"
                    name="phone"
                    value={
                      contactData.phone
                    }
                    onChange={handleChange}
                    placeholder="+91 9876543210"
                    style={inputStyle}
                  />
                </div>

                {/* EMAIL */}

                <div>
                  <label>
                    Email Address
                  </label>

                  <input
                    type="email"
                    name="email"
                    value={
                      contactData.email
                    }
                    onChange={handleChange}
                    placeholder="john@abc.com"
                    style={inputStyle}
                  />
                </div>

                {/* PRIMARY */}

                <div>
                  <label>
                    Primary Contact
                  </label>

                  <select
                    name="primaryContact"
                    value={
                      contactData.primaryContact
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Yes">
                      Yes
                    </option>

                    <option value="No">
                      No
                    </option>
                  </select>
                </div>

                {/* STATUS */}

                <div>
                  <label>Status</label>

                  <select
                    name="status"
                    value={
                      contactData.status
                    }
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Active">
                      Active
                    </option>

                    <option value="Inactive">
                      Inactive
                    </option>
                  </select>
                </div>

                {/* NOTES */}

                <div
                  style={{
                    gridColumn:
                      "1 / span 2",
                  }}
                >
                  <label>Notes</label>

                  <textarea
                    name="notes"
                    value={
                      contactData.notes
                    }
                    onChange={handleChange}
                    rows="4"
                    placeholder="Enter notes..."
                    style={{
                      ...inputStyle,
                      resize: "vertical",
                    }}
                  />
                </div>
              </div>

              {/* BUTTONS */}

              <div
                style={{
                  display: "flex",
                  justifyContent:
                    "flex-end",
                  gap: "15px",
                  marginTop: "25px",
                }}
              >
                <button
                  type="button"
                  onClick={handleReset}
                  style={{
                    background: "#E5E7EB",
                    color: "#334155",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: loading
                      ? "#9CA3AF"
                      : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding:
                      "12px 25px",
                    borderRadius: "8px",
                    cursor: loading
                      ? "not-allowed"
                      : "pointer",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingId
                    ? "Update Contact"
                    : "Save Contact"}
                </button>
              </div>
            </form>
          </div>

          {/* ================= CONTACT STATISTICS ================= */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Primary Contacts</h3>
              <h2>{primaryContacts}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Managers</h3>
              <h2>{managers}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>HR Contacts</h3>
              <h2>{hrContacts}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>CEOs</h3>
              <h2>{ceos}</h2>
            </div>
          </div>

          {/* ================= RECENT ACTIVITY ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
              }}
            >
              Recent Contact Activity
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse:
                  "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th
                    style={{
                      padding: "12px",
                    }}
                  >
                    Company
                  </th>

                  <th>Contact</th>
                  <th>Role</th>
                  <th>Activity</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {contacts
                  .slice(-3)
                  .reverse()
                  .map((contact) => (
                    <tr
                      key={contact.id}
                      style={{
                        textAlign:
                          "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "12px",
                        }}
                      >
                        {contact.company}
                      </td>

                      <td>
                        {contact.name}
                      </td>

                      <td>
                        {contact.role}
                      </td>

                      <td>
                        Contact Added /
                        Updated
                      </td>

                      <td>
                        {contact.status}
                      </td>
                    </tr>
                  ))}

                {contacts.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="5"
                      style={{
                        padding: "20px",
                        textAlign:
                          "center",
                        color:
                          "#64748B",
                      }}
                    >
                      No recent activity
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================
// CARD STYLE
// =========================

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

// =========================
// INPUT STYLE
// =========================

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default ContactManagement;
