import { useState, useEffect } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaClipboardList,
  FaSearch,
  FaUserShield,
  FaExchangeAlt,
  FaSignInAlt,
  FaEdit,
  FaTrash,
  FaPlus,
} from "react-icons/fa";

function AuditLog() {
  const [search, setSearch] = useState("");
  const [logs, setLogs] = useState([]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    user: "",
    action: "",
    oldValue: "",
    newValue: "",
    date: "",
    status: "Success",
  });

  // =========================
  // GET AUDIT LOGS
  // =========================

  const fetchLogs = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/audit-logs"
      );

      setLogs(response.data);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  // =========================
  // FORM INPUT
  // =========================

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // =========================
  // OPEN ADD FORM
  // =========================

  const handleAddLog = () => {
    setEditingId(null);

    setForm({
      user: "",
      action: "",
      oldValue: "",
      newValue: "",
      date: "",
      status: "Success",
    });

    setShowForm(true);
  };

  // =========================
  // CLOSE FORM
  // =========================

  const resetForm = () => {
    setForm({
      user: "",
      action: "",
      oldValue: "",
      newValue: "",
      date: "",
      status: "Success",
    });

    setEditingId(null);
    setShowForm(false);
  };

  // =========================
  // CREATE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editingId) {
        await axios.put(
          `http://localhost:5000/api/audit-logs/${editingId}`,
          form
        );

        alert("Audit log updated successfully");
      } else {
        await axios.post(
          "http://localhost:5000/api/audit-logs",
          form
        );

        alert("Audit log created successfully");
      }

      resetForm();
      fetchLogs();
    } catch (error) {
      console.error("Error saving audit log:", error);

      if (error.response) {
        console.error("Backend response:", error.response.data);
      }

      alert("Failed to save audit log");
    }
  };

  // =========================
  // EDIT
  // =========================

  const handleEdit = (log) => {
    setForm({
      user: log.user || "",
      action: log.action || "",
      oldValue: log.oldValue || "",
      newValue: log.newValue || "",
      date: log.date || "",
      status: log.status || "Success",
    });

    setEditingId(log.id);
    setShowForm(true);
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this audit log?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(
        `http://localhost:5000/api/audit-logs/${id}`
      );

      alert("Audit log deleted successfully");

      fetchLogs();
    } catch (error) {
      console.error("Error deleting audit log:", error);
      alert("Failed to delete audit log");
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredLogs = logs.filter(
    (log) =>
      log.user
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      log.action
        ?.toLowerCase()
        .includes(search.toLowerCase())
  );

  // =========================
  // STATISTICS
  // =========================

  const totalLogs = logs.length;

  const activeUsers = new Set(
    logs.map((log) => log.user)
  ).size;

  const updatedRecords = logs.filter((log) =>
    log.action?.toLowerCase().includes("updated")
  ).length;

  const today = new Date()
    .toISOString()
    .split("T")[0];

  const loginsToday = logs.filter(
    (log) =>
      log.action?.toLowerCase().includes("login") &&
      log.date === today
  ).length;

  const createdRecords = logs.filter((log) =>
    log.action?.toLowerCase().includes("created")
  ).length;

  const deletedRecords = logs.filter((log) =>
    log.action?.toLowerCase().includes("deleted")
  ).length;

  const failedLogins = logs.filter(
    (log) =>
      log.action?.toLowerCase().includes("login") &&
      log.status === "Failed"
  ).length;

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  color: "#334155",
                  margin: 0,
                }}
              >
                Audit Log
              </h1>

              <p style={{ color: "#64748B" }}>
                Track all administrator and user activities.
              </p>
            </div>

            {/* ADD LOG BUTTON */}

            <button
              type="button"
              onClick={handleAddLog}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                fontSize: "14px",
              }}
            >
              <FaPlus />
              Add Log
            </button>
          </div>

          {/* DASHBOARD CARDS */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaClipboardList
                size={30}
                color="#4F46E5"
              />

              <h3>Total Logs</h3>
              <h2>{totalLogs}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaUserShield
                size={30}
                color="#16A34A"
              />

              <h3>Active Users</h3>
              <h2>{activeUsers}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaExchangeAlt
                size={30}
                color="#2563EB"
              />

              <h3>Updated Records</h3>
              <h2>{updatedRecords}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaSignInAlt
                size={30}
                color="#D97706"
              />

              <h3>Logins Today</h3>
              <h2>{loginsToday}</h2>
            </div>
          </div>

          {/* SEARCH */}

          <div
            style={{
              position: "relative",
              width: "350px",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position: "absolute",
                left: "15px",
                top: "14px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search User or Action..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              style={{
                width: "100%",
                padding: "12px 15px 12px 45px",
                border: "1px solid #CBD5E1",
                borderRadius: "8px",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
          </div>

          {/* ADD / EDIT FORM */}

          {showForm && (
            <div
              style={{
                background: "#fff",
                padding: "25px",
                borderRadius: "15px",
                marginBottom: "30px",
                boxShadow:
                  "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <h2
                style={{
                  color: "#334155",
                  marginBottom: "20px",
                }}
              >
                {editingId
                  ? "Update Audit Log"
                  : "Add Audit Log"}
              </h2>

              <form onSubmit={handleSubmit}>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(2,1fr)",
                    gap: "20px",
                  }}
                >

                  <div>
                    <label>User</label>

                    <input
                      type="text"
                      name="user"
                      value={form.user}
                      onChange={handleChange}
                      placeholder="John Smith"
                      required
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Action</label>

                    <input
                      type="text"
                      name="action"
                      value={form.action}
                      onChange={handleChange}
                      placeholder="Updated Employee"
                      required
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Old Value</label>

                    <input
                      type="text"
                      name="oldValue"
                      value={form.oldValue}
                      onChange={handleChange}
                      placeholder="Salary ₹25,000"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>New Value</label>

                    <input
                      type="text"
                      name="newValue"
                      value={form.newValue}
                      onChange={handleChange}
                      placeholder="Salary ₹28,000"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Date</label>

                    <input
                      type="date"
                      name="date"
                      value={form.date}
                      onChange={handleChange}
                      required
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label>Status</label>

                    <select
                      name="status"
                      value={form.status}
                      onChange={handleChange}
                      style={inputStyle}
                    >
                      <option value="Success">
                        Success
                      </option>

                      <option value="Completed">
                        Completed
                      </option>

                      <option value="Warning">
                        Warning
                      </option>

                      <option value="Failed">
                        Failed
                      </option>
                    </select>
                  </div>

                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "15px",
                    marginTop: "25px",
                  }}
                >
                  <button
                    type="button"
                    onClick={resetForm}
                    style={{
                      background: "#E5E7EB",
                      color: "#334155",
                      border: "none",
                      padding: "12px 25px",
                      borderRadius: "8px",
                      cursor: "pointer",
                    }}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    style={{
                      background: "#4F46E5",
                      color: "#fff",
                      border: "none",
                      padding: "12px 25px",
                      borderRadius: "8px",
                      cursor: "pointer",
                    }}
                  >
                    {editingId
                      ? "Update Log"
                      : "Save Log"}
                  </button>
                </div>

              </form>
            </div>
          )}

          {/* AUDIT LOG TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Log ID
                  </th>
                  <th>User</th>
                  <th>Action</th>
                  <th>Old Value</th>
                  <th>New Value</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredLogs.map((log) => (
                  <tr
                    key={log.id}
                    style={{
                      textAlign: "center",
                      borderBottom:
                        "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>
                      {log.id}
                    </td>

                    <td>{log.user}</td>
                    <td>{log.action}</td>
                    <td>{log.oldValue}</td>
                    <td>{log.newValue}</td>
                    <td>{log.date}</td>

                    <td>
                      <span
                        style={{
                          background:
                            log.status === "Success"
                              ? "#22C55E"
                              : log.status ===
                                "Warning"
                              ? "#F59E0B"
                              : log.status ===
                                "Failed"
                              ? "#EF4444"
                              : "#3B82F6",

                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                        }}
                      >
                        {log.status}
                      </span>
                    </td>

                    <td>
                      <button
                        type="button"
                        onClick={() =>
                          handleEdit(log)
                        }
                        style={{
                          background: "#F59E0B",
                          color: "#fff",
                          border: "none",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          marginRight: "8px",
                          cursor: "pointer",
                        }}
                      >
                        <FaEdit />
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          handleDelete(log.id)
                        }
                        style={{
                          background: "#EF4444",
                          color: "#fff",
                          border: "none",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          cursor: "pointer",
                        }}
                      >
                        <FaTrash />
                      </button>
                    </td>
                  </tr>
                ))}

                {filteredLogs.length === 0 && (
                  <tr>
                    <td
                      colSpan="8"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No audit logs found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ACTIVITY STATISTICS */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Created Records</h3>
              <h2>{createdRecords}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Updated Records</h3>
              <h2>{updatedRecords}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Deleted Records</h3>
              <h2>{deletedRecords}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Failed Logins</h3>
              <h2>{failedLogins}</h2>
            </div>
          </div>

          {/* RECENT ACTIVITIES */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Recent Activities
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "12px" }}>
                    User
                  </th>
                  <th>Activity</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {logs.slice(0, 5).map((log) => (
                  <tr
                    key={log.id}
                    style={{
                      textAlign: "center",
                    }}
                  >
                    <td style={{ padding: "12px" }}>
                      {log.user}
                    </td>

                    <td>{log.action}</td>
                    <td>{log.date}</td>

                    <td>
                      <span
                        style={{
                          background:
                            log.status === "Success"
                              ? "#22C55E"
                              : log.status ===
                                "Failed"
                              ? "#EF4444"
                              : "#F59E0B",

                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                        }}
                      >
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default AuditLog;