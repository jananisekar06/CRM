import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

function Profile() {
  const [name, setName] = useState("Priya");
  const [email, setEmail] = useState("priya@gmail.com");
  const [phone, setPhone] = useState("9876543210");
  const [department, setDepartment] = useState("Computer Science");

  const handleSave = () => {
    alert("Profile updated successfully!");
  };

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <main style={{ padding: "30px" }}>
          <h1 style={{ color: "#1E293B", marginBottom: "5px" }}>
            My Profile
          </h1>

          <p style={{ color: "#64748B", marginBottom: "25px" }}>
            Manage your personal information
          </p>

          <div
            style={{
              background: "#FFFFFF",
              padding: "30px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
              maxWidth: "800px",
            }}
          >
            {/* Profile Header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "20px",
                marginBottom: "30px",
                paddingBottom: "25px",
                borderBottom: "1px solid #E2E8F0",
              }}
            >
              <div
                style={{
                  width: "90px",
                  height: "90px",
                  borderRadius: "50%",
                  background: "#4F46E5",
                  color: "#FFFFFF",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "32px",
                  fontWeight: "bold",
                }}
              >
                P
              </div>

              <div>
                <h2 style={{ margin: 0, color: "#1E293B" }}>
                  {name}
                </h2>

                <p
                  style={{
                    margin: "7px 0",
                    color: "#64748B",
                  }}
                >
                  CRM User
                </p>

                <span
                  style={{
                    background: "#DCFCE7",
                    color: "#166534",
                    padding: "5px 12px",
                    borderRadius: "20px",
                    fontSize: "12px",
                    fontWeight: "600",
                  }}
                >
                  Active
                </span>
              </div>
            </div>

            {/* Form */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "20px",
              }}
            >
              <div>
                <label style={labelStyle}>Full Name</label>

                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={inputStyle}
                />
              </div>

              <div>
                <label style={labelStyle}>Email</label>

                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={inputStyle}
                />
              </div>

              <div>
                <label style={labelStyle}>Phone Number</label>

                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  style={inputStyle}
                />
              </div>

              <div>
                <label style={labelStyle}>Department</label>

                <input
                  value={department}
                  onChange={(e) =>
                    setDepartment(e.target.value)
                  }
                  style={inputStyle}
                />
              </div>
            </div>

            <div style={{ marginTop: "25px" }}>
              <label style={labelStyle}>Role</label>

              <input
                value="CRM Administrator"
                readOnly
                style={{
                  ...inputStyle,
                  background: "#F1F5F9",
                }}
              />
            </div>

            <button
              onClick={handleSave}
              style={{
                marginTop: "25px",
                background: "#4F46E5",
                color: "#FFFFFF",
                border: "none",
                padding: "12px 25px",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "600",
              }}
            >
              Save Changes
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}

const labelStyle = {
  display: "block",
  marginBottom: "8px",
  color: "#334155",
  fontWeight: "600",
  fontSize: "14px",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "12px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  fontSize: "14px",
};

export default Profile;