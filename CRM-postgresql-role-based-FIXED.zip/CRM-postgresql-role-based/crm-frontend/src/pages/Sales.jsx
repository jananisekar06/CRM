import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch, FaShoppingCart, FaCheckCircle, FaClock, FaTimesCircle } from "react-icons/fa";

const emptySale = { customer: "", product: "", amount: "", date: "", status: "Pending" };

function Sales() {
  const [search, setSearch] = useState("");
  const [sales, setSales] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [sale, setSale] = useState(emptySale);

  useEffect(() => {
    const fetchSales = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/sales");
        setSales(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };
    fetchSales();
  }, []);

  const addSale = async () => {
    if (!sale.customer || !sale.product || !sale.amount || !sale.date) {
      alert("Please fill all sale details");
      return;
    }
    try {
      const response = await axios.post("http://localhost:5000/api/sales", sale);
      setSales((currentSales) => [...currentSales, response.data.sale]);
      alert(response.data.message);
      setSale(emptySale);
      setShowModal(false);
    } catch (error) {
      alert("Failed to add sale");
    }
  };

  const filteredSales = sales.filter((item) => item.customer.toLowerCase().includes(search.toLowerCase()));
  const totalSales = sales.reduce((total, item) => total + Number(item.amount || 0), 0);
  const completedSales = sales.filter((item) => item.status === "Completed").reduce((total, item) => total + Number(item.amount || 0), 0);
  const pendingSales = sales.filter((item) => item.status === "Pending").reduce((total, item) => total + Number(item.amount || 0), 0);
  const setField = (field, value) => setSale({ ...sale, [field]: value });

  const cards = [
    { icon: <FaShoppingCart size={30} color="#4F46E5" />, title: "Total Sales", value: totalSales },
    { icon: <FaCheckCircle size={30} color="#22C55E" />, title: "Completed", value: completedSales },
    { icon: <FaClock size={30} color="#F59E0B" />, title: "Pending", value: pendingSales },
    { icon: <FaTimesCircle size={30} color="#EF4444" />, title: "Cancelled", value: sales.filter((item) => item.status === "Cancelled").length, count: true },
  ];

  return (
    <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1 }}><Navbar /><main style={{ padding: "30px" }}>
        <div style={headerStyle}><div><h1 style={{ margin: 0, color: "#1E293B" }}>Sales Management</h1><p style={{ color: "#64748B" }}>Manage sales and customer transactions</p></div><button onClick={() => setShowModal(true)} style={addButtonStyle}><FaPlus /> Add Sale</button></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "20px", marginBottom: "25px" }}>{cards.map((card) => <div key={card.title} style={cardStyle}>{card.icon}<p>{card.title}</p><h2>{card.count ? card.value : `₹${card.value.toLocaleString("en-IN")}`}</h2></div>)}</div>
        <div style={searchBoxStyle}><FaSearch color="#64748B" /><input type="text" placeholder="Search Customer..." value={search} onChange={(event) => setSearch(event.target.value)} style={searchInputStyle} /></div>
        <div style={tableBoxStyle}><table style={{ width: "100%", borderCollapse: "collapse" }}><thead><tr style={{ background: "#4F46E5", color: "#fff" }}><th style={{ padding: "15px" }}>ID</th><th>Customer</th><th>Product</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead><tbody>
          {filteredSales.map((item) => <tr key={item.id} style={rowStyle}><td style={{ padding: "15px" }}>{item.id}</td><td>{item.customer}</td><td>{item.product}</td><td>₹{Number(item.amount).toLocaleString("en-IN")}</td><td>{item.date}</td><td><span style={{ ...statusBadgeStyle, ...getStatusStyle(item.status) }}>{item.status}</span></td></tr>)}
          {filteredSales.length === 0 && <tr><td colSpan="6" style={{ padding: "30px", textAlign: "center", color: "#64748B" }}>No sales found.</td></tr>}
        </tbody></table></div>
      </main></div>
      {showModal && <div style={overlayStyle}><div style={modalStyle}><h2>Add Sale</h2><input placeholder="Customer Name" value={sale.customer} onChange={(event) => setField("customer", event.target.value)} style={inputStyle} /><input placeholder="Product" value={sale.product} onChange={(event) => setField("product", event.target.value)} style={inputStyle} /><input type="number" placeholder="Amount" value={sale.amount} onChange={(event) => setField("amount", event.target.value)} style={inputStyle} /><input type="date" value={sale.date} onChange={(event) => setField("date", event.target.value)} style={inputStyle} /><select value={sale.status} onChange={(event) => setField("status", event.target.value)} style={inputStyle}><option value="Completed">Completed</option><option value="Pending">Pending</option><option value="Cancelled">Cancelled</option></select><div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}><button onClick={addSale} style={saveButtonStyle}>Save</button><button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button></div></div></div>}
    </div>
  );
}

const getStatusStyle = (status) => status === "Completed" ? { background: "#DCFCE7", color: "#166534" } : status === "Pending" ? { background: "#FEF3C7", color: "#92400E" } : { background: "#FEE2E2", color: "#991B1B" };
const headerStyle = { display: "flex", justifyContent: "space-between", marginBottom: "25px" };
const addButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "12px 20px", borderRadius: "8px", cursor: "pointer", fontWeight: "600" };
const cardStyle = { background: "#fff", padding: "22px", borderRadius: "14px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const searchBoxStyle = { background: "#fff", padding: "15px 20px", borderRadius: "10px", display: "flex", gap: "12px", alignItems: "center", marginBottom: "20px" };
const searchInputStyle = { border: "none", outline: "none", flex: 1, fontSize: "14px" };
const tableBoxStyle = { background: "#fff", borderRadius: "14px", overflow: "hidden", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const rowStyle = { textAlign: "center", borderBottom: "1px solid #E2E8F0" };
const statusBadgeStyle = { padding: "6px 12px", borderRadius: "20px", fontSize: "12px", fontWeight: "600" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", marginBottom: "15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Sales;
