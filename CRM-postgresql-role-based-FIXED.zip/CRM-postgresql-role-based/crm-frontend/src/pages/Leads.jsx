import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch, FaEllipsisV } from "react-icons/fa";

const stages = ["New", "Contacted", "Meeting", "Proposal", "Negotiation", "Won", "Lost"];

const stageColors = {
  New: "#6366F1",
  Contacted: "#0EA5E9",
  Meeting: "#8B5CF6",
  Proposal: "#F59E0B",
  Negotiation: "#F97316",
  Won: "#22C55E",
  Lost: "#EF4444",
};

const emptyLead = {
  name: "",
  company: "",
  email: "",
  phone: "",
  value: "",
  status: "New",
};

function Leads() {
  const [search, setSearch] = useState("");
  const [leads, setLeads] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [lead, setLead] = useState(emptyLead);

  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/leads");
        setLeads(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };

    fetchLeads();
  }, []);

  const addLead = async () => {
    if (!lead.name || !lead.company || !lead.email || !lead.phone || !lead.value) {
      alert("Please fill all lead details");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/leads", lead);
      setLeads((currentLeads) => [...currentLeads, response.data.lead]);
      alert(response.data.message);
      setLead(emptyLead);
      setShowModal(false);
    } catch (error) {
      alert("Failed to add lead");
    }
  };

  const moveLead = async (id, status) => {
    try {
      const response = await axios.put(
        `http://localhost:5000/api/leads/${id}/status`,
        { status }
      );

      setLeads((currentLeads) =>
        currentLeads.map((item) =>
          item.id === id ? response.data.lead : item
        )
      );
    } catch (error) {
      alert("Failed to move lead");
    }
  };

  const filteredLeads = leads.filter((item) =>
    `${item.name} ${item.company} ${item.email}`.toLowerCase().includes(search.toLowerCase())
  );

  const setField = (field, value) => setLead({ ...lead, [field]: value });

  return (
    <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1, minWidth: 0 }}>
        <Navbar />
        <main style={{ padding: "30px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "30px", gap: "20px" }}>
            <div>
              <h1 style={{ margin: 0, color: "#1E293B", fontSize: "34px" }}>Lead Management</h1>
              <p style={{ margin: "10px 0 0", color: "#64748B" }}>Manage leads through the complete sales pipeline</p>
            </div>
            <button onClick={() => setShowModal(true)} style={addButtonStyle}><FaPlus /> Add Lead</button>
          </div>

          <div style={searchBoxStyle}>
            <div style={searchInputBoxStyle}>
              <FaSearch color="#64748B" />
              <input type="text" placeholder="Search leads..." value={search} onChange={(event) => setSearch(event.target.value)} style={searchInputStyle} />
            </div>
          </div>

          <div style={pipelineStyle}>
            {stages.map((stage) => {
              const stageLeads = filteredLeads.filter((item) => item.status === stage);
              return (
                <div key={stage} style={columnStyle}>
                  <div style={columnHeaderStyle}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: stageColors[stage] }} />
                      <h3 style={{ margin: 0, color: "#334155", fontSize: "15px" }}>{stage}</h3>
                    </div>
                    <span style={countStyle}>{stageLeads.length}</span>
                  </div>

                  {stageLeads.map((item) => (
                    <div key={item.id} style={leadCardStyle}>
                      <div style={cardTopStyle}>
                        <div>
                          <h4 style={{ margin: 0, color: "#1E293B", fontSize: "15px" }}>{item.name}</h4>
                          <p style={smallTextStyle}>{item.company}</p>
                        </div>
                        <FaEllipsisV color="#94A3B8" size={13} />
                      </div>
                      <p style={smallTextStyle}>{item.email}</p>
                      <p style={smallTextStyle}>Phone: {item.phone}</p>
                      <div style={valueStyle}>₹{item.value}</div>
                      <select value={item.status} onChange={(event) => moveLead(item.id, event.target.value)} style={selectStyle}>
                        {stages.map((option) => <option key={option} value={option}>Move to {option}</option>)}
                      </select>
                    </div>
                  ))}

                  {stageLeads.length === 0 && <div style={emptyStageStyle}>No leads</div>}
                </div>
              );
            })}
          </div>
        </main>
      </div>

      {showModal && (
        <div style={overlayStyle}>
          <div style={modalStyle}>
            <h2>Add Lead</h2>
            <input placeholder="Lead Name" value={lead.name} onChange={(event) => setField("name", event.target.value)} style={inputStyle} />
            <input placeholder="Company" value={lead.company} onChange={(event) => setField("company", event.target.value)} style={inputStyle} />
            <input type="email" placeholder="Email" value={lead.email} onChange={(event) => setField("email", event.target.value)} style={inputStyle} />
            <input placeholder="Phone" value={lead.phone} onChange={(event) => setField("phone", event.target.value)} style={inputStyle} />
            <input type="number" placeholder="Lead Value" value={lead.value} onChange={(event) => setField("value", event.target.value)} style={inputStyle} />
            <select value={lead.status} onChange={(event) => setField("status", event.target.value)} style={inputStyle}>
              {stages.map((option) => <option key={option} value={option}>{option}</option>)}
            </select>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}>
              <button onClick={addLead} style={saveButtonStyle}>Save</button>
              <button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const addButtonStyle = { display: "flex", alignItems: "center", gap: "9px", background: "#4F46E5", color: "#fff", border: "none", borderRadius: "9px", padding: "13px 20px", cursor: "pointer", fontWeight: "600" };
const searchBoxStyle = { background: "#fff", padding: "18px", borderRadius: "14px", marginBottom: "25px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const searchInputBoxStyle = { display: "flex", alignItems: "center", gap: "10px", border: "1px solid #CBD5E1", borderRadius: "8px", padding: "11px 14px", maxWidth: "400px" };
const searchInputStyle = { width: "100%", border: "none", outline: "none", fontSize: "14px" };
const pipelineStyle = { display: "grid", gridTemplateColumns: "repeat(7, minmax(220px, 1fr))", gap: "15px", overflowX: "auto", paddingBottom: "15px" };
const columnStyle = { background: "#E2E8F0", borderRadius: "12px", minHeight: "500px", padding: "12px" };
const columnHeaderStyle = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" };
const countStyle = { background: "#fff", color: "#64748B", borderRadius: "20px", padding: "3px 8px", fontSize: "12px", fontWeight: "600" };
const leadCardStyle = { background: "#fff", borderRadius: "10px", padding: "15px", marginBottom: "12px", boxShadow: "0 3px 8px rgba(0,0,0,0.06)" };
const cardTopStyle = { display: "flex", justifyContent: "space-between", alignItems: "flex-start" };
const smallTextStyle = { margin: "8px 0", color: "#64748B", fontSize: "12px" };
const valueStyle = { marginTop: "10px", paddingTop: "10px", borderTop: "1px solid #E2E8F0", color: "#16A34A", fontWeight: "700", fontSize: "14px" };
const selectStyle = { width: "100%", marginTop: "12px", padding: "8px", border: "1px solid #CBD5E1", borderRadius: "7px", outline: "none", fontSize: "12px", color: "#475569", background: "#fff" };
const emptyStageStyle = { textAlign: "center", padding: "30px 10px", color: "#94A3B8", fontSize: "13px" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", marginBottom: "15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Leads;
