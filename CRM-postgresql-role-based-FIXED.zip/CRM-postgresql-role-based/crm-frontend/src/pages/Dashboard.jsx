import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaUsers, FaUserTie, FaMoneyBillWave, FaClipboardList } from "react-icons/fa";

function Dashboard() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [leads, setLeads] = useState([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [customerResponse, employeeResponse, leadResponse] = await Promise.all([
          axios.get("http://localhost:5000/api/customers"),
          axios.get("http://localhost:5000/api/employees"),
          axios.get("http://localhost:5000/api/leads"),
        ]);

        setCustomers(customerResponse.data);
        setEmployees(employeeResponse.data);
        setLeads(leadResponse.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };

    fetchDashboardData();
  }, []);

  const totalLeadValue = leads.reduce(
    (total, lead) => total + Number(lead.value || 0),
    0
  );

  const cards = [
    { title: "Total Customers", value: customers.length, icon: <FaUsers size={30} color="#4F46E5" />, color: "#EEF2FF" },
    { title: "Employees", value: employees.length, icon: <FaUserTie size={30} color="#0EA5E9" />, color: "#E0F2FE" },
    { title: "Total Leads", value: leads.length, icon: <FaClipboardList size={30} color="#F59E0B" />, color: "#FEF3C7" },
    { title: "Lead Value", value: `₹${totalLeadValue.toLocaleString("en-IN")}`, icon: <FaMoneyBillWave size={30} color="#22C55E" />, color: "#DCFCE7" },
  ];

  const recentCustomers = customers.slice(-5).reverse();

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1 }}>
        <Navbar />
        <div style={{ padding: "30px" }}>
          <h1 style={{ marginBottom: "25px", color: "#334155" }}>Dashboard Overview</h1>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "20px" }}>
            {cards.map((card) => (
              <div key={card.title} style={cardStyle}>
                <div style={{ width: "60px", height: "60px", borderRadius: "50%", background: card.color, display: "flex", justifyContent: "center", alignItems: "center" }}>
                  {card.icon}
                </div>
                <h3 style={{ marginTop: "20px", color: "#64748B" }}>{card.title}</h3>
                <h1 style={{ color: "#1E293B" }}>{card.value}</h1>
              </div>
            ))}
          </div>

          <div style={sectionStyle}>
            <h2>Recent Customers</h2>
            <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
              <thead style={{ background: "#6366F1", color: "#fff" }}>
                <tr><th style={{ padding: "15px" }}>ID</th><th>Name</th><th>Email</th><th>Status</th></tr>
              </thead>
              <tbody>
                {recentCustomers.map((customer) => (
                  <tr key={customer.id} style={{ textAlign: "center", borderBottom: "1px solid #E2E8F0" }}>
                    <td style={{ padding: "15px" }}>{customer.id}</td>
                    <td>{customer.name}</td>
                    <td>{customer.email}</td>
                    <td><span style={customer.status === "Active" ? activeStyle : inactiveStyle}>{customer.status}</span></td>
                  </tr>
                ))}
                {recentCustomers.length === 0 && (
                  <tr><td colSpan="4" style={{ padding: "25px", textAlign: "center", color: "#64748B" }}>No customers added yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: "30px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
            <div style={sectionStyle}>
              <h2>Today's Summary</h2>
              <ul style={{ lineHeight: "2" }}>
                <li>{customers.length} customers added</li>
                <li>{employees.length} employees available</li>
                <li>{leads.length} leads in pipeline</li>
              </ul>
            </div>
            <div style={sectionStyle}>
              <h2>Quick Actions</h2>
              <button onClick={() => navigate("/customers")} style={customerButtonStyle}>Add Customer</button>
              <button onClick={() => navigate("/employees")} style={employeeButtonStyle}>Add Employee</button>
              <button onClick={() => navigate("/leads")} style={leadButtonStyle}>Add Lead</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const cardStyle = { background: "#fff", padding: "25px", borderRadius: "15px", boxShadow: "0 5px 15px rgba(0,0,0,.08)" };
const sectionStyle = { background: "#fff", borderRadius: "15px", padding: "25px", boxShadow: "0 5px 15px rgba(0,0,0,.08)" };
const activeStyle = { background: "#22C55E", color: "#fff", padding: "5px 12px", borderRadius: "20px", fontSize: "12px" };
const inactiveStyle = { background: "#EF4444", color: "#fff", padding: "5px 12px", borderRadius: "20px", fontSize: "12px" };
const customerButtonStyle = { padding: "12px 20px", margin: "10px", background: "#4F46E5", color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer" };
const employeeButtonStyle = { padding: "12px 20px", margin: "10px", background: "#0EA5E9", color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer" };
const leadButtonStyle = { padding: "12px 20px", margin: "10px", background: "#22C55E", color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer" };

export default Dashboard;
