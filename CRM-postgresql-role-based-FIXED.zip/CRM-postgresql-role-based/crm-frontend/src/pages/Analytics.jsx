
import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaChartBar,
  FaSearch,
  FaChartLine,
  FaUsers,
  FaUserTie,
  FaMoneyBillWave,
  FaSyncAlt,
  FaFileAlt,
} from "react-icons/fa";

function Analytics() {
  const API_URL = "http://localhost:5000/api/analytics";

  const [analytics, setAnalytics] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // ===============================
  // GET ANALYTICS
  // ===============================

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await axios.get(API_URL);

      const data = response.data;

      if (Array.isArray(data)) {
        setAnalytics(data);
      } else if (Array.isArray(data.analytics)) {
        setAnalytics(data.analytics);
      } else {
        setAnalytics([]);
      }
    } catch (err) {
      console.error("Analytics fetch error:", err);

      setError(
        "Unable to connect to analytics server. Showing sample data."
      );

      // Fallback data
      setAnalytics([
        {
          id: 1,
          category: "Sales",
          value: "₹8,50,000",
          growth: "+18%",
        },
        {
          id: 2,
          category: "Revenue",
          value: "₹12,40,000",
          growth: "+25%",
        },
        {
          id: 3,
          category: "Customer Growth",
          value: "2,350",
          growth: "+15%",
        },
        {
          id: 4,
          category: "Lead Conversion",
          value: "72%",
          growth: "+8%",
        },
        {
          id: 5,
          category: "Top Employee",
          value: "John Smith",
          growth: "Sales Champion",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  // ===============================
  // SEARCH
  // ===============================

  const filteredAnalytics = analytics.filter((item) =>
    `${item.category} ${item.value} ${item.growth}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // ===============================
  // FIND DATA
  // ===============================

  const getAnalytics = (category) => {
    return analytics.find(
      (item) =>
        item.category?.toLowerCase() === category.toLowerCase()
    );
  };

  const salesData = getAnalytics("Sales");
  const revenueData = getAnalytics("Revenue");
  const customerData = getAnalytics("Customer Growth");
  const employeeData = getAnalytics("Top Employee");

  // ===============================
  // VIEW REPORT
  // ===============================

  const handleViewReport = () => {
    alert("Analytics report opened successfully.");
  };

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
            paddingBottom: "60px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "15px",
              flexWrap: "wrap",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Analytics Dashboard
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginBottom: 0,
                }}
              >
                Business Analytics & Performance
              </p>
            </div>

            <div
              style={{
                display: "flex",
                gap: "10px",
                flexWrap: "wrap",
              }}
            >
              {/* Refresh */}

              <button
                onClick={fetchAnalytics}
                disabled={loading}
                style={{
                  background: "#E2E8F0",
                  color: "#334155",
                  border: "none",
                  padding: "12px 18px",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  fontWeight: "600",
                }}
              >
                <FaSyncAlt />

                {loading ? "Loading..." : "Refresh"}
              </button>

              {/* View Report */}

              <button
                onClick={handleViewReport}
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding: "12px 22px",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  cursor: "pointer",
                  fontWeight: "600",
                }}
              >
                <FaFileAlt />
                View Report
              </button>
            </div>
          </div>

          {/* ================= ERROR ================= */}

          {error && (
            <div
              style={{
                background: "#FEF3C7",
                color: "#92400E",
                padding: "12px 15px",
                borderRadius: "8px",
                marginBottom: "20px",
              }}
            >
              {error}
            </div>
          )}

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                maxWidth: "100%",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Analytics..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= SUMMARY CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(220px, 1fr))",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            {/* Sales */}

            <div
              style={{
                background: "#EEF2FF",
                padding: "22px",
                borderRadius: "12px",
              }}
            >
              <FaMoneyBillWave
                size={30}
                color="#4F46E5"
              />

              <h3
                style={{
                  color: "#334155",
                  marginBottom: "5px",
                }}
              >
                Sales
              </h3>

              <h2
                style={{
                  color: "#4F46E5",
                  margin: 0,
                }}
              >
                {salesData?.value || "₹0"}
              </h2>

              <p
                style={{
                  color: "#16A34A",
                  fontWeight: "600",
                }}
              >
                {salesData?.growth || "0%"} Growth
              </p>
            </div>

            {/* Revenue */}

            <div
              style={{
                background: "#DCFCE7",
                padding: "22px",
                borderRadius: "12px",
              }}
            >
              <FaChartLine
                size={30}
                color="#16A34A"
              />

              <h3
                style={{
                  color: "#334155",
                  marginBottom: "5px",
                }}
              >
                Revenue
              </h3>

              <h2
                style={{
                  color: "#16A34A",
                  margin: 0,
                }}
              >
                {revenueData?.value || "₹0"}
              </h2>

              <p
                style={{
                  color: "#16A34A",
                  fontWeight: "600",
                }}
              >
                {revenueData?.growth || "0%"} Growth
              </p>
            </div>

            {/* Customers */}

            <div
              style={{
                background: "#DBEAFE",
                padding: "22px",
                borderRadius: "12px",
              }}
            >
              <FaUsers
                size={30}
                color="#2563EB"
              />

              <h3
                style={{
                  color: "#334155",
                  marginBottom: "5px",
                }}
              >
                Customers
              </h3>

              <h2
                style={{
                  color: "#2563EB",
                  margin: 0,
                }}
              >
                {customerData?.value || "0"}
              </h2>

              <p
                style={{
                  color: "#2563EB",
                  fontWeight: "600",
                }}
              >
                {customerData?.growth || "0%"} Growth
              </p>
            </div>

            {/* Top Employee */}

            <div
              style={{
                background: "#FEF3C7",
                padding: "22px",
                borderRadius: "12px",
              }}
            >
              <FaUserTie
                size={30}
                color="#D97706"
              />

              <h3
                style={{
                  color: "#334155",
                  marginBottom: "5px",
                }}
              >
                Top Employee
              </h3>

              <h2
                style={{
                  color: "#D97706",
                  margin: 0,
                  fontSize: "20px",
                }}
              >
                {employeeData?.value || "N/A"}
              </h2>

              <p
                style={{
                  color: "#D97706",
                  fontWeight: "600",
                }}
              >
                {employeeData?.growth || ""}
              </p>
            </div>
          </div>

          {/* ================= ANALYTICS TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                minWidth: "650px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    ID
                  </th>

                  <th>Category</th>

                  <th>Value</th>

                  <th>Growth</th>
                </tr>
              </thead>

              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="4"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      Loading analytics...
                    </td>
                  </tr>
                ) : filteredAnalytics.length === 0 ? (
                  <tr>
                    <td
                      colSpan="4"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No Analytics Found
                    </td>
                  </tr>
                ) : (
                  filteredAnalytics.map((item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {item.id}
                      </td>

                      <td>{item.category}</td>

                      <td
                        style={{
                          fontWeight: "600",
                          color: "#334155",
                        }}
                      >
                        {item.value}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item.growth
                                ?.toString()
                                .startsWith("-")
                                ? "#FEE2E2"
                                : "#DCFCE7",
                            color:
                              item.growth
                                ?.toString()
                                .startsWith("-")
                                ? "#DC2626"
                                : "#16A34A",
                            padding:
                              "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                            fontWeight: "600",
                          }}
                        >
                          {item.growth}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* ================= FOOTER INFO ================= */}

          <div
            style={{
              marginTop: "25px",
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.06)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: "10px",
              }}
            >
              <div>
                <h3
                  style={{
                    margin: 0,
                    color: "#334155",
                  }}
                >
                  Analytics Summary
                </h3>

                <p
                  style={{
                    marginBottom: 0,
                    color: "#64748B",
                  }}
                >
                  Total analytics records:{" "}
                  {analytics.length}
                </p>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  color: "#16A34A",
                  fontWeight: "600",
                }}
              >
                <FaChartBar />
                Analytics Active
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Analytics;
