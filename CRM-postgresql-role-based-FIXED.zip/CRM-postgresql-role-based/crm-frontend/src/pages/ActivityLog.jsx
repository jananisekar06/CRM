
import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaSearch,
  FaEye,
  FaTrash,
  FaDownload,
  FaHistory,
} from "react-icons/fa";

function ActivityLog() {
  const [search, setSearch] = useState("");
  const [logs, setLogs] = useState([]);
  const [selectedLog, setSelectedLog] = useState(null);

  // GET ACTIVITY LOGS
  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/activity-logs"
      );

      setLogs(response.data);
    } catch (error) {
      console.error("Error fetching activity logs:", error);
    }
  };

  // DELETE ACTIVITY LOG
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this activity log?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(
        `http://localhost:5000/api/activity-logs/${id}`
      );

      setLogs((prevLogs) =>
        prevLogs.filter((log) => log.id !== id)
      );

      alert("Activity log deleted successfully");
    } catch (error) {
      console.error("Error deleting activity log:", error);
      alert("Failed to delete activity log");
    }
  };

  // VIEW ACTIVITY
  const handleView = (log) => {
    setSelectedLog(log);
  };

  // SEARCH
  const filteredLogs = logs.filter(
    (log) =>
      log.user?.toLowerCase().includes(search.toLowerCase()) ||
      log.activity?.toLowerCase().includes(search.toLowerCase())
  );

  // EXPORT LOG
  const handleExport = () => {
    if (logs.length === 0) {
      alert("No activity logs available to export");
      return;
    }

    const headers = [
      "Log ID",
      "User",
      "Activity",
      "Date",
      "Time",
      "Status",
    ];

    const rows = logs.map((log) => [
      log.id,
      log.user,
      log.activity,
      log.date,
      log.time,
      log.status,
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "activity-log.csv";
    link.click();

    URL.revokeObjectURL(url);
  };

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Activity Log
              </h1>

              <p style={{ color: "#64748B" }}>
                Monitor all CRM user activities
              </p>
            </div>

            <button
              onClick={handleExport}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 20px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <FaDownload />
              Export Log
            </button>
          </div>

          {/* SEARCH */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Activity..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>Log ID</th>
                  <th>User</th>
                  <th>Activity</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredLogs.length > 0 ? (
                  filteredLogs.map((log) => (
                    <tr
                      key={log.id}
                      style={{
                        textAlign: "center",
                        borderBottom: "1px solid #E2E8F0",
                      }}
                    >
                      <td style={{ padding: "15px" }}>
                        {log.id}
                      </td>

                      <td>{log.user}</td>

                      <td>{log.activity}</td>

                      <td>{log.date}</td>

                      <td>{log.time}</td>

                      <td>
                        <span
                          style={{
                            background:
                              log.status === "Success"
                                ? "#22C55E"
                                : "#3B82F6",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                          }}
                        >
                          {log.status}
                        </span>
                      </td>

                      <td>
                        {/* VIEW */}

                        <button
                          onClick={() => handleView(log)}
                          style={{
                            background: "#3B82F6",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                          }}
                        >
                          <FaEye />
                        </button>

                        {/* DELETE */}

                        <button
                          onClick={() => handleDelete(log.id)}
                          style={{
                            background: "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            cursor: "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No activity logs found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* SUMMARY CARDS */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaHistory size={30} color="#4F46E5" />

              <h3>Total Activities</h3>

              <h2>{logs.length}</h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Logins</h3>

              <h2>
                {
                  logs.filter(
                    (l) => l.activity === "Login"
                  ).length
                }
              </h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Invoices</h3>

              <h2>
                {
                  logs.filter(
                    (l) =>
                      l.activity === "Invoice Created"
                  ).length
                }
              </h2>
            </div>

            <div
              style={{
                background: "#FDE68A",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Reports</h3>

              <h2>
                {
                  logs.filter(
                    (l) =>
                      l.activity === "Report Downloaded"
                  ).length
                }
              </h2>
            </div>
          </div>

          {/* VIEW MODAL */}

          {selectedLog && (
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0,0,0,0.5)",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                zIndex: 999,
              }}
            >
              <div
                style={{
                  background: "#fff",
                  width: "450px",
                  padding: "30px",
                  borderRadius: "15px",
                  boxShadow:
                    "0 10px 30px rgba(0,0,0,.2)",
                }}
              >
                <h2
                  style={{
                    color: "#334155",
                    marginTop: 0,
                  }}
                >
                  Activity Details
                </h2>

                <p>
                  <strong>Log ID:</strong>{" "}
                  {selectedLog.id}
                </p>

                <p>
                  <strong>User:</strong>{" "}
                  {selectedLog.user}
                </p>

                <p>
                  <strong>Activity:</strong>{" "}
                  {selectedLog.activity}
                </p>

                <p>
                  <strong>Date:</strong>{" "}
                  {selectedLog.date}
                </p>

                <p>
                  <strong>Time:</strong>{" "}
                  {selectedLog.time}
                </p>

                <p>
                  <strong>Status:</strong>{" "}
                  {selectedLog.status}
                </p>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    marginTop: "25px",
                  }}
                >
                  <button
                    onClick={() => setSelectedLog(null)}
                    style={{
                      background: "#4F46E5",
                      color: "#fff",
                      border: "none",
                      padding: "10px 25px",
                      borderRadius: "8px",
                      cursor: "pointer",
                    }}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

export default ActivityLog;
