import { useState, useEffect } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
  FaMoneyBillWave,
  FaWallet,
  FaFileInvoiceDollar,
  FaShoppingCart,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/finance";

function FinanceManagement() {
  const [search, setSearch] = useState("");
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);

  // ==========================================
  // FORMAT FINANCE DATA
  // ==========================================
  const formatFinanceData = (data) => {
    if (!Array.isArray(data)) return [];

    return data.map((item, index) => {
      const rawId = String(item.id ?? "").trim();

      // Never allow EXPundefined to appear.
      const numericPart = rawId.replace(/^EXP/i, "");
      const generatedId =
        numericPart && !Number.isNaN(Number(numericPart))
          ? `EXP${String(Number(numericPart)).padStart(3, "0")}`
          : `EXP${String(index + 1).padStart(3, "0")}`;

      return {
        id: rawId ? (rawId.startsWith("EXP") ? rawId : generatedId) : generatedId,
        category: item.title || item.category || "Expense",
        employee: item.employee || "Admin",
        amount: Number(item.amount || 0),
        date: item.date || "-",
        status: item.status || "Pending",
        description: item.description || "",
        type: item.type || "Expense",
      };
    });
  };

  // ==========================================
  // GET FINANCE ARRAY FROM API RESPONSE
  // ==========================================
  const getFinanceArray = (responseData) => {
    if (Array.isArray(responseData)) {
      return responseData;
    }

    return (
      responseData?.finance ||
      responseData?.data ||
      responseData?.finances ||
      []
    );
  };

  // ==========================================
  // FETCH FINANCE DATA
  // ==========================================
  const fetchFinances = async () => {
    try {
      setLoading(true);

      const response = await axios.get(API_URL);
      console.log("Finance API Response:", response.data);

      const data = getFinanceArray(response.data);
      setExpenses(formatFinanceData(data));
    } catch (error) {
      console.error("Finance Fetch Error:", error);

      if (
        error.code === "ERR_NETWORK" ||
        error.code === "ECONNREFUSED"
      ) {
        alert(
          "Network Error!\n\nCannot connect to the backend.\n\nPlease make sure your backend server is running on port 5000."
        );
      } else {
        alert(
          error.response?.data?.message ||
            "Failed to load finance records"
        );
      }

      // Do NOT insert fake/sample records when the API fails.
      setExpenses([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFinances();
  }, []);

  // ==========================================
  // ADD EXPENSE
  // ==========================================
  const addExpense = async () => {
    try {
      setLoading(true);

      const response = await axios.post(API_URL, {
        // ID is intentionally NOT sent.
        // Backend will generate EXP001, EXP002, etc.
        title: "Office Expense",
        amount: 5000,
        type: "Expense",
        description: "Office maintenance",
        date: "2026-08-29",
        employee: "Admin",
        status: "Pending",
      });

      console.log("ADD FINANCE RESPONSE:", response.data);

      if (response.data?.success) {
        alert("Expense added successfully");
        await fetchFinances();
      } else {
        alert(
          response.data?.message ||
            "Failed to create finance record"
        );
      }
    } catch (error) {
      console.error(
        "ADD FINANCE ERROR:",
        error.response?.data || error
      );

      if (
        error.code === "ERR_NETWORK" ||
        error.code === "ECONNREFUSED"
      ) {
        alert(
          "Network Error!\n\nPlease make sure the backend server is running on port 5000."
        );
      } else {
        alert(
          error.response?.data?.message ||
            error.message ||
            "Failed to create finance record"
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // ==========================================
  // EDIT EXPENSE
  // ==========================================
  const editExpense = (expense) => {
    alert(`Edit feature selected for ${expense.id}`);
  };

  // ==========================================
  // DELETE EXPENSE
  // ==========================================
  const deleteExpense = async (expense) => {
    const confirmDelete = window.confirm(
      `Delete ${expense.id}?`
    );

    if (!confirmDelete) return;

    try {
      setLoading(true);

      // EXP001 -> 001 -> 1
      const numericId = String(expense.id)
        .replace(/^EXP/i, "")
        .trim();

      if (!numericId || Number.isNaN(Number(numericId))) {
        alert("Invalid finance record ID.");
        return;
      }

      const deleteUrl = `${API_URL}/${Number(numericId)}`;

      console.log("Delete URL:", deleteUrl);

      await axios.delete(deleteUrl);

      alert("Finance record deleted successfully");

      await fetchFinances();
    } catch (error) {
      console.error("Delete Finance Error:", error);

      if (
        error.code === "ERR_NETWORK" ||
        error.code === "ECONNREFUSED"
      ) {
        alert(
          "Network Error!\n\nPlease make sure the backend server is running."
        );
      } else {
        alert(
          error.response?.data?.message ||
            "Failed to delete finance record"
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // ==========================================
  // SEARCH
  // ==========================================
  const filteredExpenses = expenses.filter((expense) => {
    const value = search.toLowerCase().trim();

    return (
      expense.id.toLowerCase().includes(value) ||
      expense.category.toLowerCase().includes(value) ||
      expense.employee.toLowerCase().includes(value) ||
      expense.status.toLowerCase().includes(value)
    );
  });

  // ==========================================
  // TOTAL EXPENSE
  // ==========================================
  const totalExpenses = expenses.reduce(
    (total, expense) => total + Number(expense.amount || 0),
    0
  );

  const formatCurrency = (amount) =>
    `₹${Number(amount || 0).toLocaleString("en-IN")}`;

  // ==========================================
  // EXPORT EXCEL
  // ==========================================
  const exportToExcel = () => {
    try {
      if (expenses.length === 0) {
        alert("No finance records available to export.");
        return;
      }

      const excelData = expenses.map((expense) => ({
        "Expense ID": expense.id,
        Category: expense.category,
        Employee: expense.employee,
        Amount: expense.amount,
        Date: expense.date,
        Status: expense.status,
        Description: expense.description,
        Type: expense.type,
      }));

      const worksheet = XLSX.utils.json_to_sheet(excelData);

      worksheet["!cols"] = [
        { wch: 15 },
        { wch: 25 },
        { wch: 20 },
        { wch: 15 },
        { wch: 15 },
        { wch: 15 },
        { wch: 35 },
        { wch: 15 },
      ];

      const workbook = XLSX.utils.book_new();

      XLSX.utils.book_append_sheet(
        workbook,
        worksheet,
        "Finance Records"
      );

      const fileName = `Finance_Report_${new Date()
        .toISOString()
        .slice(0, 10)}.xlsx`;

      XLSX.writeFile(workbook, fileName);

      alert("Excel file downloaded successfully.");
    } catch (error) {
      console.error("Excel Export Error:", error);
      alert("Failed to export Excel file.");
    }
  };

  // ==========================================
  // EXPORT PDF
  // ==========================================
  const exportToPDF = () => {
    try {
      if (expenses.length === 0) {
        alert("No finance records available to export.");
        return;
      }

      const doc = new jsPDF({
        orientation: "landscape",
        unit: "mm",
        format: "a4",
      });

      doc.setFontSize(18);
      doc.text("Finance Management Report", 14, 18);

      doc.setFontSize(10);
      doc.text(
        `Generated: ${new Date().toLocaleDateString("en-IN")}`,
        14,
        26
      );

      doc.text(
        `Total Expenses: ${formatCurrency(totalExpenses)}`,
        14,
        32
      );

      const tableData = expenses.map((expense) => [
        expense.id,
        expense.category,
        expense.employee,
        formatCurrency(expense.amount),
        expense.date,
        expense.status,
      ]);

      autoTable(doc, {
        startY: 38,
        head: [
          [
            "Expense ID",
            "Category",
            "Employee",
            "Amount",
            "Date",
            "Status",
          ],
        ],
        body: tableData,
        theme: "grid",
        styles: {
          fontSize: 9,
          cellPadding: 3,
          halign: "center",
        },
        headStyles: {
          fontSize: 9,
          fontStyle: "bold",
        },
      });

      const fileName = `Finance_Report_${new Date()
        .toISOString()
        .slice(0, 10)}.pdf`;

      // Browser downloads the PDF to the user's normal Downloads folder.
      doc.save(fileName);
    } catch (error) {
      console.error("PDF Export Error:", error);
      alert("Failed to export PDF file.");
    }
  };

  // ==========================================
  // STATUS STYLE
  // ==========================================
  const getStatusStyle = (status) => {
    if (status === "Paid") {
      return {
        background: "#DCFCE7",
        color: "#15803D",
      };
    }

    if (status === "Approved") {
      return {
        background: "#DBEAFE",
        color: "#1D4ED8",
      };
    }

    if (status === "Rejected") {
      return {
        background: "#FEE2E2",
        color: "#DC2626",
      };
    }

    return {
      background: "#FEF3C7",
      color: "#B45309",
    };
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div
        style={{
          marginLeft: "260px",
          minHeight: "100vh",
        }}
      >
        <Navbar />

        <main
          style={{
            padding: "30px",
            maxWidth: "1600px",
            margin: "0 auto",
          }}
        >
          {/* HEADER */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "28px",
              gap: "20px",
              flexWrap: "wrap",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  fontSize: "30px",
                  fontWeight: "700",
                  color: "#1E293B",
                }}
              >
                Finance Management
              </h1>

              <p
                style={{
                  marginTop: "8px",
                  marginBottom: 0,
                  color: "#64748B",
                  fontSize: "15px",
                }}
              >
                Manage expenses, budgets, purchase orders and tax reports
              </p>
            </div>

            <button
              onClick={addExpense}
              disabled={loading}
              style={{
                background: loading ? "#9CA3AF" : "#4F46E5",
                color: "#FFFFFF",
                border: "none",
                padding: "12px 20px",
                borderRadius: "8px",
                cursor: loading ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                gap: "9px",
                fontSize: "14px",
                fontWeight: "600",
              }}
            >
              <FaPlus />
              {loading ? "Please wait..." : "Add Expense"}
            </button>
          </div>

          {/* SUMMARY CARDS */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(220px, 1fr))",
              gap: "20px",
              marginBottom: "28px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "22px",
                borderRadius: "14px",
              }}
            >
              <FaMoneyBillWave size={30} color="#4F46E5" />

              <p
                style={{
                  color: "#64748B",
                  marginBottom: "5px",
                }}
              >
                Total Expenses
              </p>

              <h2
                style={{
                  margin: 0,
                  color: "#1E293B",
                }}
              >
                {formatCurrency(totalExpenses)}
              </h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "22px",
                borderRadius: "14px",
              }}
            >
              <FaWallet size={30} color="#16A34A" />

              <p
                style={{
                  color: "#64748B",
                  marginBottom: "5px",
                }}
              >
                Total Budget
              </p>

              <h2
                style={{
                  margin: 0,
                  color: "#1E293B",
                }}
              >
                ₹10,00,000
              </h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "22px",
                borderRadius: "14px",
              }}
            >
              <FaShoppingCart size={30} color="#2563EB" />

              <p
                style={{
                  color: "#64748B",
                  marginBottom: "5px",
                }}
              >
                Purchase Orders
              </p>

              <h2
                style={{
                  margin: 0,
                  color: "#1E293B",
                }}
              >
                42
              </h2>
            </div>

            <div
              style={{
                background: "#FEF3C7",
                padding: "22px",
                borderRadius: "14px",
              }}
            >
              <FaFileInvoiceDollar size={30} color="#D97706" />

              <p
                style={{
                  color: "#64748B",
                  marginBottom: "5px",
                }}
              >
                Tax Reports
              </p>

              <h2
                style={{
                  margin: 0,
                  color: "#1E293B",
                }}
              >
                18
              </h2>
            </div>
          </div>

          {/* SEARCH */}
          <div
            style={{
              background: "#FFFFFF",
              padding: "18px",
              borderRadius: "14px",
              border: "1px solid #E2E8F0",
              marginBottom: "20px",
            }}
          >
            <div
              style={{
                width: "100%",
                maxWidth: "400px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#94A3B8",
                }}
              />

              <input
                type="text"
                placeholder="Search Expense..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  boxSizing: "border-box",
                  padding: "12px 15px 12px 43px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  fontSize: "14px",
                }}
              />
            </div>
          </div>

          {/* EXPENSE TABLE */}
          <div
            style={{
              background: "#FFFFFF",
              borderRadius: "14px",
              overflow: "hidden",
              border: "1px solid #E2E8F0",
            }}
          >
            <div
              style={{
                padding: "20px",
                borderBottom: "1px solid #E2E8F0",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: "19px",
                  color: "#1E293B",
                }}
              >
                Expense Records
              </h2>
            </div>

            <div
              style={{
                width: "100%",
                overflowX: "auto",
              }}
            >
              <table
                style={{
                  width: "100%",
                  minWidth: "850px",
                  borderCollapse: "collapse",
                }}
              >
                <thead
                  style={{
                    background: "#4F46E5",
                    color: "#FFFFFF",
                  }}
                >
                  <tr>
                    {[
                      "Expense ID",
                      "Category",
                      "Employee",
                      "Amount",
                      "Date",
                      "Status",
                      "Action",
                    ].map((heading) => (
                      <th
                        key={heading}
                        style={{
                          padding: "15px",
                          fontSize: "13px",
                          textAlign: "center",
                        }}
                      >
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {filteredExpenses.map((expense) => (
                    <tr
                      key={expense.id}
                      style={{
                        textAlign: "center",
                        borderBottom: "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "16px",
                          fontWeight: "600",
                        }}
                      >
                        {expense.id}
                      </td>

                      <td>{expense.category}</td>

                      <td>{expense.employee}</td>

                      <td
                        style={{
                          fontWeight: "600",
                        }}
                      >
                        {formatCurrency(expense.amount)}
                      </td>

                      <td>{expense.date}</td>

                      <td>
                        <span
                          style={{
                            ...getStatusStyle(expense.status),
                            display: "inline-block",
                            padding: "6px 13px",
                            borderRadius: "20px",
                            fontSize: "12px",
                            fontWeight: "600",
                          }}
                        >
                          {expense.status}
                        </span>
                      </td>

                      <td>
                        <button
                          title="Edit"
                          onClick={() => editExpense(expense)}
                          style={{
                            background: "#FEF3C7",
                            color: "#D97706",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                          }}
                        >
                          <FaEdit />
                        </button>

                        <button
                          title="Delete"
                          onClick={() => deleteExpense(expense)}
                          style={{
                            background: "#FEE2E2",
                            color: "#DC2626",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            cursor: "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))}

                  {filteredExpenses.length === 0 && (
                    <tr>
                      <td
                        colSpan="7"
                        style={{
                          padding: "35px",
                          textAlign: "center",
                          color: "#64748B",
                        }}
                      >
                        {loading
                          ? "Loading finance records..."
                          : "No expense records found."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* BUDGET PLANNING */}
          <section style={{ marginTop: "35px" }}>
            <h2 style={{ color: "#1E293B" }}>
              Budget Planning
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(200px, 1fr))",
                gap: "18px",
              }}
            >
              {[
                ["Marketing", "₹2,00,000"],
                ["Sales", "₹3,00,000"],
                ["HR", "₹1,50,000"],
                ["IT", "₹3,50,000"],
              ].map(([department, amount]) => (
                <div
                  key={department}
                  style={{
                    background: "#FFFFFF",
                    padding: "20px",
                    borderRadius: "12px",
                    border: "1px solid #E2E8F0",
                  }}
                >
                  <h3>{department}</h3>

                  <p style={{ color: "#64748B" }}>
                    Allocated
                  </p>

                  <h2>{amount}</h2>
                </div>
              ))}
            </div>
          </section>

          {/* PURCHASE ORDERS */}
          <section
            style={{
              marginTop: "35px",
              background: "#FFFFFF",
              borderRadius: "14px",
              overflow: "hidden",
            }}
          >
            <h2
              style={{
                padding: "20px",
                margin: 0,
              }}
            >
              Purchase Orders
            </h2>

            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#FFFFFF",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>PO No</th>
                  <th>Vendor</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {[
                  [
                    "PO1001",
                    "ABC Technologies",
                    "₹85,000",
                    "Approved",
                  ],
                  [
                    "PO1002",
                    "Global Supplies",
                    "₹42,000",
                    "Pending",
                  ],
                  [
                    "PO1003",
                    "Tech World",
                    "₹1,20,000",
                    "Completed",
                  ],
                ].map((po) => (
                  <tr
                    key={po[0]}
                    style={{
                      textAlign: "center",
                      borderBottom: "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>
                      {po[0]}
                    </td>
                    <td>{po[1]}</td>
                    <td>{po[2]}</td>
                    <td>{po[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          {/* TAX REPORTS / EXPORT */}
          <section
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(220px, 1fr))",
              gap: "18px",
            }}
          >
            {[
              ["GST Report", "₹82,500"],
              ["Tax Summary", "₹1,45,000"],
              ["Monthly Tax", "₹38,000"],
            ].map(([title, amount]) => (
              <div
                key={title}
                style={{
                  background: "#FFFFFF",
                  padding: "20px",
                  borderRadius: "12px",
                  border: "1px solid #E2E8F0",
                }}
              >
                <h3>{title}</h3>
                <h2>{amount}</h2>
              </div>
            ))}

            <div
              style={{
                background: "#FFFFFF",
                padding: "20px",
                borderRadius: "12px",
                border: "1px solid #E2E8F0",
              }}
            >
              <h3>Export</h3>

              <button
                onClick={exportToPDF}
                disabled={expenses.length === 0}
                style={{
                  background:
                    expenses.length === 0 ? "#9CA3AF" : "#4F46E5",
                  color: "#FFFFFF",
                  border: "none",
                  padding: "10px 18px",
                  borderRadius: "7px",
                  cursor:
                    expenses.length === 0
                      ? "not-allowed"
                      : "pointer",
                  marginRight: "8px",
                }}
              >
                PDF
              </button>

              <button
                onClick={exportToExcel}
                disabled={expenses.length === 0}
                style={{
                  background:
                    expenses.length === 0 ? "#9CA3AF" : "#16A34A",
                  color: "#FFFFFF",
                  border: "none",
                  padding: "10px 18px",
                  borderRadius: "7px",
                  cursor:
                    expenses.length === 0
                      ? "not-allowed"
                      : "pointer",
                }}
              >
                Excel
              </button>
            </div>
          </section>

          {/* CREDIT & DEBIT NOTES */}
          <section
            style={{
              marginTop: "35px",
              marginBottom: "30px",
              background: "#FFFFFF",
              borderRadius: "14px",
              overflow: "hidden",
            }}
          >
            <h2
              style={{
                padding: "20px",
                margin: 0,
              }}
            >
              Credit & Debit Notes
            </h2>

            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#FFFFFF",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>Note No</th>
                  <th>Invoice No</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>CN001</td>
                  <td>INV1001</td>
                  <td>Credit Note</td>
                  <td>₹5,000</td>
                  <td>
                    <span
                      style={{
                        background: "#DCFCE7",
                        color: "#15803D",
                        padding: "6px 12px",
                        borderRadius: "20px",
                      }}
                    >
                      Issued
                    </span>
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>DN001</td>
                  <td>INV1002</td>
                  <td>Debit Note</td>
                  <td>₹2,500</td>
                  <td>
                    <span
                      style={{
                        background: "#FEF3C7",
                        color: "#B45309",
                        padding: "6px 12px",
                        borderRadius: "20px",
                      }}
                    >
                      Pending
                    </span>
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>CN002</td>
                  <td>INV1003</td>
                  <td>Credit Note</td>
                  <td>₹8,200</td>
                  <td>
                    <span
                      style={{
                        background: "#DBEAFE",
                        color: "#1D4ED8",
                        padding: "6px 12px",
                        borderRadius: "20px",
                      }}
                    >
                      Approved
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </section>
        </main>
      </div>
    </div>
  );
}

export default FinanceManagement;
