import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch, FaEdit, FaTrash } from "react-icons/fa";

const emptyCustomer = {
  name: "",
  email: "",
  phone: "",
  city: "",
  status: "Active",
};

function Customers() {
  const [search, setSearch] = useState("");
  const [customers, setCustomers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [customer, setCustomer] = useState(emptyCustomer);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/customers");
        setCustomers(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };

    fetchCustomers();
  }, []);

  const addCustomer = async () => {
    if (!customer.name || !customer.email || !customer.phone || !customer.city) {
      alert("Please fill all customer details");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/customers",
        customer
      );

      setCustomers((currentCustomers) => [
        ...currentCustomers,
        response.data.customer,
      ]);
      alert(response.data.message);
      setCustomer(emptyCustomer);
      setShowModal(false);
    } catch (error) {
      alert("Failed to add customer");
    }
  };

  const filteredCustomers = customers.filter((currentCustomer) =>
    currentCustomer.name.toLowerCase().includes(search.toLowerCase())
  );

  const setField = (field, value) => {
    setCustomer({ ...customer, [field]: value });
  };

  return (
   <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "25px" }}>
            <div>
              <h1 style={{ margin: 0, color: "#334155" }}>Customer Management</h1>
              <p style={{ color: "#64748B" }}>Manage all customer details</p>
            </div>

            <button onClick={() => setShowModal(true)} style={addButtonStyle}>
              <FaPlus />
              Add Customer
            </button>
          </div>

          <div style={searchBoxStyle}>
            <div style={{ position: "relative", width: "350px" }}>
              <FaSearch style={{ position: "absolute", left: "15px", top: "14px", color: "#64748B" }} />
              <input
                type="text"
                placeholder="Search Customer..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                style={searchInputStyle}
              />
            </div>
          </div>

          <div style={tableBoxStyle}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#4F46E5", color: "#fff" }}>
                <tr>
                  <th style={{ padding: "15px" }}>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((currentCustomer) => (
                  <tr key={currentCustomer.id} style={{ textAlign: "center", borderBottom: "1px solid #E2E8F0" }}>
                    <td style={{ padding: "15px" }}>{currentCustomer.id}</td>
                    <td>{currentCustomer.name}</td>
                    <td>{currentCustomer.email}</td>
                    <td>{currentCustomer.phone}</td>
                    <td>{currentCustomer.city}</td>
                    <td>
                      <span style={currentCustomer.status === "Active" ? activeStatusStyle : inactiveStatusStyle}>
                        {currentCustomer.status}
                      </span>
                    </td>
                    <td>
                      <button style={editButtonStyle}><FaEdit /></button>
                      <button style={deleteButtonStyle}><FaTrash /></button>
                    </td>
                  </tr>
                ))}
                {filteredCustomers.length === 0 && (
                  <tr>
                    <td colSpan="7" style={{ padding: "25px", textAlign: "center", color: "#64748B" }}>
                      No customers found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px", marginTop: "30px" }}>
            <div style={totalCardStyle}><h3>Total Customers</h3><h1>{customers.length}</h1></div>
            <div style={activeCardStyle}><h3>Active Customers</h3><h1>{customers.filter((item) => item.status === "Active").length}</h1></div>
            <div style={inactiveCardStyle}><h3>Inactive Customers</h3><h1>{customers.filter((item) => item.status === "Inactive").length}</h1></div>
          </div>
        </div>
      </div>

      {showModal && (
        <div style={overlayStyle}>
          <div style={modalStyle}>
            <h2>Add Customer</h2>
            <input placeholder="Customer Name" value={customer.name} onChange={(event) => setField("name", event.target.value)} style={inputStyle} />
            <input type="email" placeholder="Email" value={customer.email} onChange={(event) => setField("email", event.target.value)} style={inputStyle} />
            <input placeholder="Phone" value={customer.phone} onChange={(event) => setField("phone", event.target.value)} style={inputStyle} />
            <input placeholder="City" value={customer.city} onChange={(event) => setField("city", event.target.value)} style={inputStyle} />
            <select value={customer.status} onChange={(event) => setField("status", event.target.value)} style={inputStyle}>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}>
              <button onClick={addCustomer} style={saveButtonStyle}>Save</button>
              <button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const addButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "12px 22px", borderRadius: "8px", cursor: "pointer", display: "flex", alignItems: "center", gap: "10px" };
const searchBoxStyle = { background: "#fff", padding: "20px", borderRadius: "12px", marginBottom: "25px", boxShadow: "0 5px 15px rgba(0,0,0,.08)" };
const searchInputStyle = { width: "100%", padding: "12px 15px 12px 45px", border: "1px solid #CBD5E1", borderRadius: "8px", outline: "none" };
const tableBoxStyle = { background: "#fff", borderRadius: "15px", overflow: "hidden", boxShadow: "0 5px 15px rgba(0,0,0,.08)" };
const activeStatusStyle = { background: "#22C55E", color: "#fff", padding: "5px 12px", borderRadius: "20px", fontSize: "12px" };
const inactiveStatusStyle = { background: "#EF4444", color: "#fff", padding: "5px 12px", borderRadius: "20px", fontSize: "12px" };
const editButtonStyle = { background: "#F59E0B", border: "none", color: "#fff", padding: "8px 10px", borderRadius: "6px", marginRight: "8px", cursor: "pointer" };
const deleteButtonStyle = { background: "#EF4444", border: "none", color: "#fff", padding: "8px 10px", borderRadius: "6px", cursor: "pointer" };
const totalCardStyle = { background: "#EEF2FF", padding: "20px", borderRadius: "12px" };
const activeCardStyle = { background: "#DCFCE7", padding: "20px", borderRadius: "12px" };
const inactiveCardStyle = { background: "#FEE2E2", padding: "20px", borderRadius: "12px" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", marginBottom: "15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Customers;
