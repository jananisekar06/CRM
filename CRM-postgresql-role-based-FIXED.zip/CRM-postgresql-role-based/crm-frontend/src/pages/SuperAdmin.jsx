import { useEffect, useState } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaBuilding,
  FaUserShield,
  FaUsers,
  FaChartBar,
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
  FaSave,
  FaTimes,
} from "react-icons/fa";

function SuperAdmin() {
const API_URL = "http://localhost:5000/api/super-admin";
  // ==============================
  // STATES
  // ==============================

  const [companies, setCompanies] = useState([]);

  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");

  const [showForm, setShowForm] = useState(false);

  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    company: "",
    admin: "",
    users: 0,
    plan: "Basic",
    status: "Active",
  });

  // ==============================
  // GET COMPANIES
  // ==============================

  const fetchCompanies = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await axios.get(
        `${API_URL}/companies`
      );

      console.log("COMPANY API RESPONSE:", response.data);

      if (
        response.data &&
        response.data.success
      ) {
        setCompanies(
          response.data.companies || []
        );
      } else {
        setCompanies([]);

        setError(
          response.data?.message ||
            "No company data found"
        );
      }
    } catch (err) {
      console.error(
        "FETCH COMPANY ERROR:",
        err
      );

      setError(
        "Unable to load company data. Please check backend server."
      );

      setCompanies([]);
    } finally {
      setLoading(false);
    }
  };

  // ==============================
  // LOAD DATA
  // ==============================

  useEffect(() => {
    fetchCompanies();
  }, []);

  // ==============================
  // FORM CHANGE
  // ==============================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ==============================
  // OPEN CREATE FORM
  // ==============================

  const openCreateForm = () => {
    setEditingId(null);

    setFormData({
      company: "",
      admin: "",
      users: 0,
      plan: "Basic",
      status: "Active",
    });

    setShowForm(true);
  };

  // ==============================
  // OPEN EDIT FORM
  // ==============================

  const openEditForm = (item) => {
    setEditingId(item.id);

    setFormData({
      company: item.company,
      admin: item.admin,
      users: item.users,
      plan: item.plan,
      status: item.status,
    });

    setShowForm(true);
  };

  // ==============================
  // RESET FORM
  // ==============================

  const resetForm = () => {
    setEditingId(null);

    setFormData({
      company: "",
      admin: "",
      users: 0,
      plan: "Basic",
      status: "Active",
    });

    setShowForm(false);
  };

  // ==============================
  // SAVE COMPANY
  // ==============================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.company.trim() ||
      !formData.admin.trim()
    ) {
      alert(
        "Please enter Company Name and Admin Name"
      );

      return;
    }

    try {
      if (editingId) {
        // UPDATE
        const response = await axios.put(
          `${API_URL}/companies/${editingId}`,
          formData
        );

        console.log(
          "UPDATE RESPONSE:",
          response.data
        );

        if (response.data.success) {
          alert(
            "Company updated successfully!"
          );

          await fetchCompanies();

          resetForm();
        }
      } else {
        // CREATE
        const response = await axios.post(
          `${API_URL}/companies`,
          formData
        );

        console.log(
          "CREATE RESPONSE:",
          response.data
        );

        if (response.data.success) {
          alert(
            "Company created successfully!"
          );

          await fetchCompanies();

          resetForm();
        }
      }
    } catch (err) {
      console.error(
        "SAVE COMPANY ERROR:",
        err
      );

      alert(
        err.response?.data?.message ||
          "Unable to save company"
      );
    }
  };

  // ==============================
  // DELETE COMPANY
  // ==============================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this company?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await axios.delete(
        `${API_URL}/companies/${id}`
      );

      console.log(
        "DELETE RESPONSE:",
        response.data
      );

      if (response.data.success) {
        alert(
          "Company deleted successfully!"
        );

        await fetchCompanies();
      }
    } catch (err) {
      console.error(
        "DELETE COMPANY ERROR:",
        err
      );

      alert(
        err.response?.data?.message ||
          "Unable to delete company"
      );
    }
  };

  // ==============================
  // SEARCH
  // ==============================

  const filteredCompanies =
    companies.filter((item) => {
      const searchText =
        search.toLowerCase();

      return (
        item.company
          ?.toLowerCase()
          .includes(searchText) ||
        item.admin
          ?.toLowerCase()
          .includes(searchText) ||
        item.plan
          ?.toLowerCase()
          .includes(searchText)
      );
    });

  // ==============================
  // STATISTICS
  // ==============================

  const totalCompanies =
    companies.length;

  const totalAdmins =
    companies.length;

  const totalUsers =
    companies.reduce(
      (total, item) =>
        total + Number(item.users || 0),
      0
    );

  const activeCompanies =
    companies.filter(
      (item) =>
        item.status === "Active"
    ).length;

  // ==============================
  // UI
  // ==============================

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent:
                "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "20px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Super Admin Panel
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginTop: "8px",
                }}
              >
                Manage companies,
                administrators,
                subscriptions and
                system settings.
              </p>
            </div>

            <button
              onClick={openCreateForm}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding:
                  "12px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
                fontWeight: "600",
              }}
            >
              <FaPlus />

              Create Company
            </button>
          </div>

          {/* ================= ERROR ================= */}

          {error && (
            <div
              style={{
                background: "#FEE2E2",
                color: "#B91C1C",
                padding: "15px",
                borderRadius: "8px",
                marginBottom: "20px",
                border:
                  "1px solid #FCA5A5",
              }}
            >
              {error}
            </div>
          )}

          {/* ================= CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, 1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div
              style={card("#EEF2FF")}
            >
              <FaBuilding
                size={30}
                color="#4F46E5"
              />

              <h3>
                Total Companies
              </h3>

              <h2>
                {totalCompanies}
              </h2>
            </div>

            <div
              style={card("#DCFCE7")}
            >
              <FaUserShield
                size={30}
                color="#16A34A"
              />

              <h3>
                Active Companies
              </h3>

              <h2>
                {activeCompanies}
              </h2>
            </div>

            <div
              style={card("#DBEAFE")}
            >
              <FaUsers
                size={30}
                color="#2563EB"
              />

              <h3>
                Total Users
              </h3>

              <h2>
                {totalUsers}
              </h2>
            </div>

            <div
              style={card("#FEF3C7")}
            >
              <FaChartBar
                size={30}
                color="#D97706"
              />

              <h3>
                Administrators
              </h3>

              <h2>
                {totalAdmins}
              </h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              width: "350px",
              maxWidth: "100%",
              position: "relative",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position:
                  "absolute",
                top: "14px",
                left: "15px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search Company, Admin or Plan..."
              value={search}
              onChange={(e) =>
                setSearch(
                  e.target.value
                )
              }
              style={{
                width: "100%",
                padding:
                  "12px 15px 12px 45px",
                border:
                  "1px solid #CBD5E1",
                borderRadius: "8px",
                outline: "none",
                boxSizing:
                  "border-box",
              }}
            />
          </div>

          {/* ================= FORM ================= */}

          {showForm && (
            <div
              style={{
                background: "#fff",
                padding: "25px",
                borderRadius: "15px",
                marginBottom: "30px",
                boxShadow:
                  "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent:
                    "space-between",
                  alignItems: "center",
                  marginBottom:
                    "20px",
                }}
              >
                <h2
                  style={{
                    color: "#334155",
                    margin: 0,
                  }}
                >
                  {editingId
                    ? "Update Company"
                    : "Create Company"}
                </h2>

                <button
                  onClick={resetForm}
                  style={{
                    background:
                      "#FEE2E2",
                    color: "#DC2626",
                    border: "none",
                    width: "35px",
                    height: "35px",
                    borderRadius:
                      "50%",
                    cursor: "pointer",
                  }}
                >
                  <FaTimes />
                </button>
              </div>

              <form
                onSubmit={handleSubmit}
              >
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(2, 1fr)",
                    gap: "20px",
                  }}
                >
                  <div>
                    <label>
                      Company Name
                    </label>

                    <input
                      name="company"
                      value={
                        formData.company
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="ABC Company"
                      style={
                        inputStyle
                      }
                    />
                  </div>

                  <div>
                    <label>
                      Admin Name
                    </label>

                    <input
                      name="admin"
                      value={
                        formData.admin
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="John Smith"
                      style={
                        inputStyle
                      }
                    />
                  </div>

                  <div>
                    <label>
                      Number of Users
                    </label>

                    <input
                      name="users"
                      type="number"
                      min="0"
                      value={
                        formData.users
                      }
                      onChange={
                        handleChange
                      }
                      style={
                        inputStyle
                      }
                    />
                  </div>

                  <div>
                    <label>
                      Subscription Plan
                    </label>

                    <select
                      name="plan"
                      value={
                        formData.plan
                      }
                      onChange={
                        handleChange
                      }
                      style={
                        inputStyle
                      }
                    >
                      <option>
                        Basic
                      </option>

                      <option>
                        Standard
                      </option>

                      <option>
                        Premium
                      </option>

                      <option>
                        Enterprise
                      </option>
                    </select>
                  </div>

                  <div>
                    <label>
                      Status
                    </label>

                    <select
                      name="status"
                      value={
                        formData.status
                      }
                      onChange={
                        handleChange
                      }
                      style={
                        inputStyle
                      }
                    >
                      <option>
                        Active
                      </option>

                      <option>
                        Inactive
                      </option>
                    </select>
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "flex-end",
                    gap: "15px",
                    marginTop:
                      "25px",
                  }}
                >
                  <button
                    type="button"
                    onClick={
                      resetForm
                    }
                    style={{
                      background:
                        "#E5E7EB",
                      color:
                        "#334155",
                      border: "none",
                      padding:
                        "12px 25px",
                      borderRadius:
                        "8px",
                      cursor:
                        "pointer",
                    }}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    style={{
                      background:
                        "#4F46E5",
                      color: "#fff",
                      border: "none",
                      padding:
                        "12px 25px",
                      borderRadius:
                        "8px",
                      display:
                        "flex",
                      alignItems:
                        "center",
                      gap: "10px",
                      cursor:
                        "pointer",
                    }}
                  >
                    <FaSave />

                    {editingId
                      ? "Update Company"
                      : "Save Company"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse:
                  "collapse",
                minWidth: "850px",
              }}
            >
              <thead
                style={{
                  background:
                    "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th
                    style={{
                      padding: "15px",
                    }}
                  >
                    Company ID
                  </th>

                  <th>
                    Company
                  </th>

                  <th>
                    Admin
                  </th>

                  <th>
                    Users
                  </th>

                  <th>
                    Plan
                  </th>

                  <th>
                    Status
                  </th>

                  <th>
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        textAlign:
                          "center",
                        padding:
                          "35px",
                        color:
                          "#64748B",
                      }}
                    >
                      Loading company
                      data...
                    </td>
                  </tr>
                ) : filteredCompanies.length ===
                  0 ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        textAlign:
                          "center",
                        padding:
                          "35px",
                        color:
                          "#64748B",
                      }}
                    >
                      No company data
                      found.
                    </td>
                  </tr>
                ) : (
                  filteredCompanies.map(
                    (item) => (
                      <tr
                        key={
                          item.id
                        }
                        style={{
                          textAlign:
                            "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td
                          style={{
                            padding:
                              "15px",
                            fontWeight:
                              "600",
                          }}
                        >
                          {item.id}
                        </td>

                        <td>
                          {item.company}
                        </td>

                        <td>
                          {item.admin}
                        </td>

                        <td>
                          {item.users}
                        </td>

                        <td>
                          <span
                            style={{
                              fontWeight:
                                "600",
                              color:
                                "#4F46E5",
                            }}
                          >
                            {item.plan}
                          </span>
                        </td>

                        <td>
                          <span
                            style={{
                              background:
                                item.status ===
                                "Active"
                                  ? "#22C55E"
                                  : "#EF4444",
                              color:
                                "#fff",
                              padding:
                                "5px 12px",
                              borderRadius:
                                "20px",
                              fontSize:
                                "12px",
                            }}
                          >
                            {
                              item.status
                            }
                          </span>
                        </td>

                        <td>
                          <button
                            onClick={() =>
                              openEditForm(
                                item
                              )
                            }
                            style={{
                              background:
                                "#F59E0B",
                              color:
                                "#fff",
                              border:
                                "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "8px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaEdit />
                          </button>

                          <button
                            onClick={() =>
                              handleDelete(
                                item.id
                              )
                            }
                            style={{
                              background:
                                "#EF4444",
                              color:
                                "#fff",
                              border:
                                "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    )
                  )
                )}
              </tbody>
            </table>
          </div>

          {/* ================= INFO ================= */}

          <div
            style={{
              marginTop: "30px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginTop: 0,
              }}
            >
              System Overview
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(3, 1fr)",
                gap: "20px",
                marginTop: "20px",
              }}
            >
              <div
                style={infoBox(
                  "#DCFCE7"
                )}
              >
                <h3>
                  Active Companies
                </h3>

                <h2>
                  {activeCompanies}
                </h2>
              </div>

              <div
                style={infoBox(
                  "#DBEAFE"
                )}
              >
                <h3>
                  Total Users
                </h3>

                <h2>
                  {totalUsers}
                </h2>
              </div>

              <div
                style={infoBox(
                  "#FEF3C7"
                )}
              >
                <h3>
                  Total Companies
                </h3>

                <h2>
                  {totalCompanies}
                </h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==============================
// STYLES
// ==============================

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const infoBox = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default SuperAdmin;