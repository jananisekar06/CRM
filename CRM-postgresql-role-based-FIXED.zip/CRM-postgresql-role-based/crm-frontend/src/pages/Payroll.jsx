import { useEffect, useState } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaMoneyBillWave,
  FaPlus,
  FaFileInvoiceDollar,
  FaUsers,
  FaDownload,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/payroll";

const emptyForm = {
  employee: "",
  department: "",
  basic: "",
  allowance: "",
  deduction: "",
};

function Payroll() {
  const [search, setSearch] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [payrolls, setPayrolls] = useState([]);

  // =========================
  // FETCH PAYROLL
  // =========================

  useEffect(() => {
    fetchPayroll();
  }, []);

  const fetchPayroll = async () => {
    try {
      const response = await axios.get(API_URL);

      setPayrolls(
        Array.isArray(response.data)
          ? response.data
          : response.data.payrolls || []
      );
    } catch (error) {
      console.error("Error fetching payroll:", error);
    }
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // CALCULATE NET SALARY
  // =========================

  const basic = Number(form.basic) || 0;
  const allowance = Number(form.allowance) || 0;
  const deduction = Number(form.deduction) || 0;

  const netSalary = basic + allowance - deduction;

  // =========================
  // SAVE PAYROLL
  // =========================

  const handleSubmit = async () => {
    if (
      !form.employee ||
      !form.department ||
      !form.basic ||
      !form.allowance ||
      !form.deduction
    ) {
      alert("Please fill all payroll details.");
      return;
    }

    try {
      const response = await axios.post(API_URL, {
        employee: form.employee,
        department: form.department,
        month: "August 2026",
        basic,
        allowance,
        deduction,
        net: netSalary,
        status: "Pending",
      });

      alert(
        response.data.message ||
          "Payroll saved successfully"
      );

      setForm(emptyForm);

      fetchPayroll();
    } catch (error) {
      console.error("Error adding payroll:", error);

      alert(
        error.response?.data?.message ||
          "Failed to add payroll"
      );
    }
  };

  // =========================
  // DOWNLOAD PDF
  // =========================

  const handleDownloadPDF = () => {
    if (
      !form.employee ||
      !form.department ||
      !form.basic ||
      !form.allowance ||
      !form.deduction
    ) {
      alert(
        "Please fill all payroll details before downloading PDF."
      );
      return;
    }

    try {
      const doc = new jsPDF();

      const employee = form.employee;
      const department = form.department;

      // =========================
      // HEADER
      // =========================

      doc.setFont("helvetica", "bold");
      doc.setFontSize(24);

      doc.text("CRM SYSTEM", 20, 25);

      doc.setFontSize(19);

      doc.text("PAYSLIP", 150, 25);

      doc.setLineWidth(0.5);
      doc.line(20, 32, 190, 32);

      // =========================
      // EMPLOYEE DETAILS
      // =========================

      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");

      doc.text("Employee Details", 20, 48);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);

      doc.text(
        `Employee Name: ${employee}`,
        20,
        60
      );

      doc.text(
        `Department: ${department}`,
        20,
        70
      );

      doc.text(
        "Pay Month: August 2026",
        20,
        80
      );

      doc.text(
        "Status: Pending",
        20,
        90
      );

      // =========================
      // SALARY TABLE HEADER
      // =========================

      doc.setFillColor(79, 70, 229);

      doc.setTextColor(255, 255, 255);

      doc.rect(20, 105, 170, 12, "F");

      doc.setFont("helvetica", "bold");

      doc.text(
        "Salary Component",
        25,
        113
      );

      doc.text(
        "Amount",
        155,
        113
      );

      // =========================
      // BASIC SALARY
      // =========================

      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");

      doc.rect(20, 117, 170, 15);

      doc.text(
        "Basic Salary",
        25,
        127
      );

      doc.text(
        `Rs. ${basic.toLocaleString("en-IN")}`,
        155,
        127
      );

      // =========================
      // ALLOWANCE
      // =========================

      doc.rect(20, 132, 170, 15);

      doc.text(
        "Allowance",
        25,
        142
      );

      doc.text(
        `Rs. ${allowance.toLocaleString("en-IN")}`,
        155,
        142
      );

      // =========================
      // DEDUCTION
      // =========================

      doc.rect(20, 147, 170, 15);

      doc.text(
        "Deduction",
        25,
        157
      );

      doc.text(
        `Rs. ${deduction.toLocaleString("en-IN")}`,
        155,
        157
      );

      // =========================
      // NET SALARY
      // =========================

      doc.setFont("helvetica", "bold");

      doc.rect(20, 162, 170, 18);

      doc.text(
        "NET SALARY",
        25,
        174
      );

      doc.text(
        `Rs. ${netSalary.toLocaleString("en-IN")}`,
        155,
        174
      );

      // =========================
      // CALCULATION
      // =========================

      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);

      doc.text(
        "Salary Calculation",
        20,
        198
      );

      doc.text(
        `Basic + Allowance - Deduction`,
        20,
        208
      );

      doc.text(
        `Rs. ${basic.toLocaleString(
          "en-IN"
        )} + Rs. ${allowance.toLocaleString(
          "en-IN"
        )} - Rs. ${deduction.toLocaleString(
          "en-IN"
        )} = Rs. ${netSalary.toLocaleString(
          "en-IN"
        )}`,
        20,
        218
      );

      // =========================
      // FOOTER
      // =========================

      doc.line(20, 255, 190, 255);

      doc.setFontSize(10);

      doc.text(
        "This is a computer generated payslip.",
        20,
        267
      );

      doc.text(
        "CRM Payroll Management System",
        20,
        276
      );

      // =========================
      // DOWNLOAD
      // =========================

      const safeEmployeeName =
        employee.replace(/[^a-zA-Z0-9]/g, "_");

      doc.save(
        `${safeEmployeeName}_Payslip_August_2026.pdf`
      );

      alert(
        "Payslip PDF downloaded successfully!"
      );
    } catch (error) {
      console.error(
        "PDF generation error:",
        error
      );

      alert(
        "Failed to generate PDF."
      );
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredPayroll = payrolls.filter(
    (item) =>
      String(item.employee || "")
        .toLowerCase()
        .includes(search.toLowerCase())
  );

  // =========================
  // SUMMARY
  // =========================

  const totalEmployees = payrolls.length;

  const paidCount = payrolls.filter(
    (item) => item.status === "Paid"
  ).length;

  const pendingCount = payrolls.filter(
    (item) => item.status === "Pending"
  ).length;

  const totalSalaryPaid = payrolls
    .filter((item) => item.status === "Paid")
    .reduce(
      (sum, item) =>
        sum + Number(item.net || 0),
      0
    );

  // =========================
  // UI
  // =========================

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Payroll Management
              </h1>

              <p
                style={{
                  color: "#64748B",
                }}
              >
                Calculate salaries and generate payslips.
              </p>
            </div>

            <button
              onClick={() => {
                document
                  .getElementById("payroll-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  });
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 20px",
                borderRadius: "8px",
                display: "flex",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <FaPlus />
              Generate Payroll
            </button>
          </div>

          {/* ================= CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaUsers
                size={30}
                color="#4F46E5"
              />

              <h3>Employees</h3>

              <h2>{totalEmployees}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaMoneyBillWave
                size={30}
                color="#16A34A"
              />

              <h3>Salary Paid</h3>

              <h2>
                ₹
                {totalSalaryPaid.toLocaleString(
                  "en-IN"
                )}
              </h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaFileInvoiceDollar
                size={30}
                color="#2563EB"
              />

              <h3>Payslips</h3>

              <h2>{paidCount}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaDownload
                size={30}
                color="#D97706"
              />

              <h3>Pending</h3>

              <h2>{pendingCount}</h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <input
            type="text"
            placeholder="Search Employee..."
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
            style={{
              width: "350px",
              padding: "12px",
              borderRadius: "8px",
              border:
                "1px solid #CBD5E1",
              marginBottom: "25px",
              outline: "none",
            }}
          />

          {/* ================= PAYROLL TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse:
                  "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={thStyle}>
                    ID
                  </th>

                  <th>Employee</th>

                  <th>Department</th>

                  <th>Month</th>

                  <th>Net Salary</th>

                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {filteredPayroll.map(
                  (item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign:
                          "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {item.id}
                      </td>

                      <td>
                        {item.employee}
                      </td>

                      <td>
                        {item.department}
                      </td>

                      <td>
                        {item.month}
                      </td>

                      <td>
                        ₹
                        {Number(
                          item.net || 0
                        ).toLocaleString(
                          "en-IN"
                        )}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item.status ===
                              "Paid"
                                ? "#22C55E"
                                : "#F59E0B",
                            color:
                              "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize:
                              "12px",
                          }}
                        >
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  )
                )}

                {filteredPayroll.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="6"
                      style={{
                        textAlign:
                          "center",
                        padding: "20px",
                        color:
                          "#64748B",
                      }}
                    >
                      No Payroll Found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= PAYROLL FORM ================= */}

          <div
            id="payroll-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              Generate Payroll
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(2,1fr)",
                gap: "20px",
              }}
            >
              {/* EMPLOYEE */}

              <div>
                <label>
                  Employee Name
                </label>

                <input
                  type="text"
                  name="employee"
                  placeholder="Employee Name"
                  value={form.employee}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              {/* DEPARTMENT */}

              <div>
                <label>
                  Department
                </label>

                <input
                  type="text"
                  name="department"
                  placeholder="Department"
                  value={form.department}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              {/* BASIC */}

              <div>
                <label>
                  Basic Salary
                </label>

                <input
                  type="number"
                  name="basic"
                  placeholder="30000"
                  value={form.basic}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              {/* ALLOWANCE */}

              <div>
                <label>
                  Allowance
                </label>

                <input
                  type="number"
                  name="allowance"
                  placeholder="5000"
                  value={form.allowance}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              {/* DEDUCTION */}

              <div>
                <label>
                  Deduction
                </label>

                <input
                  type="number"
                  name="deduction"
                  placeholder="2000"
                  value={form.deduction}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              {/* NET SALARY */}

              <div>
                <label>
                  Net Salary
                </label>

                <input
                  type="text"
                  value={`₹${netSalary.toLocaleString(
                    "en-IN"
                  )}`}
                  readOnly
                  style={{
                    ...inputStyle,
                    background:
                      "#F1F5F9",
                    fontWeight: "bold",
                    color: "#16A34A",
                  }}
                />
              </div>
            </div>

            {/* BUTTONS */}

            <div
              style={{
                marginTop: "25px",
                display: "flex",
                justifyContent:
                  "flex-end",
                gap: "15px",
              }}
            >
              <button
                onClick={handleSubmit}
                style={{
                  background:
                    "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding:
                    "12px 25px",
                  borderRadius:
                    "8px",
                  cursor:
                    "pointer",
                }}
              >
                Save Payroll
              </button>

              <button
                onClick={
                  handleDownloadPDF
                }
                style={{
                  background:
                    "#16A34A",
                  color: "#fff",
                  border: "none",
                  padding:
                    "12px 25px",
                  borderRadius:
                    "8px",
                  cursor:
                    "pointer",
                  display: "flex",
                  alignItems:
                    "center",
                  gap: "8px",
                }}
              >
                <FaDownload />
                Download PDF
              </button>
            </div>
          </div>

          {/* ================= PAYSLIP PREVIEW ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
              }}
            >
              Payslip Preview
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse:
                  "collapse",
              }}
            >
              <tbody>
                <tr>
                  <td style={previewLabel}>
                    Employee
                  </td>

                  <td>
                    {form.employee ||
                      "-"}
                  </td>
                </tr>

                <tr>
                  <td style={previewLabel}>
                    Department
                  </td>

                  <td>
                    {form.department ||
                      "-"}
                  </td>
                </tr>

                <tr>
                  <td style={previewLabel}>
                    Basic Salary
                  </td>

                  <td>
                    ₹
                    {basic.toLocaleString(
                      "en-IN"
                    )}
                  </td>
                </tr>

                <tr>
                  <td style={previewLabel}>
                    Allowance
                  </td>

                  <td>
                    ₹
                    {allowance.toLocaleString(
                      "en-IN"
                    )}
                  </td>
                </tr>

                <tr>
                  <td style={previewLabel}>
                    Deduction
                  </td>

                  <td>
                    ₹
                    {deduction.toLocaleString(
                      "en-IN"
                    )}
                  </td>
                </tr>

                <tr>
                  <td
                    style={{
                      ...previewLabel,
                      color: "#16A34A",
                    }}
                  >
                    Net Salary
                  </td>

                  <td
                    style={{
                      color: "#16A34A",
                      fontWeight:
                        "bold",
                      fontSize:
                        "16px",
                    }}
                  >
                    ₹
                    {netSalary.toLocaleString(
                      "en-IN"
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================
// STYLES
// =========================

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const thStyle = {
  padding: "15px",
};

const previewLabel = {
  padding: "12px",
  fontWeight: "bold",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default Payroll;