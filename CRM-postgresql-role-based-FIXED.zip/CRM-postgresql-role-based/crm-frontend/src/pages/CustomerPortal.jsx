
import { useEffect, useState } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  FaSearch,
  FaEye,
  FaDownload,
  FaTicketAlt,
  FaCreditCard,
  FaUserEdit,
  FaUserCircle,
  FaTimes,
} from "react-icons/fa";

function CustomerPortal() {
  const API_URL = "http://localhost:5000/api/customer-portal";

  // ==============================
  // STATES
  // ==============================

  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showDetails, setShowDetails] = useState(false);

  // ==============================
  // GET CUSTOMER PORTAL DATA
  // ==============================

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await axios.get(`${API_URL}/customers`);

      console.log("CUSTOMER PORTAL RESPONSE:", response.data);

      if (response.data?.success) {
        setCustomers(response.data.customers || []);
      } else {
        setCustomers([]);
        setError(
          response.data?.message || "No customer data found"
        );
      }
    } catch (err) {
      console.error("CUSTOMER PORTAL ERROR:", err);

      setCustomers([]);

      setError(
        "Unable to load customer portal data. Please check backend server."
      );
    } finally {
      setLoading(false);
    }
  };

  // ==============================
  // LOAD DATA
  // ==============================

  useEffect(() => {
    fetchCustomers();
  }, []);

  // ==============================
  // SEARCH
  // ==============================

  const filteredCustomers = customers.filter((customer) => {
    const searchText = search.toLowerCase();

    return (
      customer.id?.toLowerCase().includes(searchText) ||
      customer.name?.toLowerCase().includes(searchText) ||
      customer.invoice?.toLowerCase().includes(searchText) ||
      customer.payment?.toLowerCase().includes(searchText) ||
      customer.ticket?.toLowerCase().includes(searchText)
    );
  });

  // ==============================
  // VIEW CUSTOMER
  // ==============================

  const handleView = (customer) => {
    setSelectedCustomer(customer);
    setShowDetails(true);
  };

  // ==============================
  // DOWNLOAD INVOICE
  // ==============================

  const handleDownload = (customer) => {
    alert(
      `Invoice ${customer.invoice} download requested for ${customer.name}.`
    );
  };

  // ==============================
  // CREATE TICKET
  // ==============================

  const handleTicket = (customer) => {
    alert(
      `Create support ticket for ${customer.name}.`
    );
  };

  // ==============================
  // PAYMENT
  // ==============================

  const handlePayment = (customer) => {
    if (customer.payment === "Paid") {
      alert("This invoice is already paid.");
      return;
    }

    alert(
      `Payment requested for invoice ${customer.invoice}.`
    );
  };

  // ==============================
  // EDIT PROFILE
  // ==============================

  const handleProfile = (customer) => {
    alert(
      `Edit profile requested for ${customer.name}.`
    );
  };

  // ==============================
  // SUMMARY
  // ==============================

  const totalCustomers = customers.length;

  const paidCustomers = customers.filter(
    (customer) => customer.payment === "Paid"
  ).length;

  const pendingCustomers = customers.filter(
    (customer) => customer.payment === "Pending"
  ).length;

  const openTickets = customers.filter(
    (customer) => customer.ticket === "Open"
  ).length;

  // ==============================
  // UI
  // ==============================

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              marginBottom: "25px",
            }}
          >
            <h1
              style={{
                margin: 0,
                color: "#334155",
              }}
            >
              Customer Portal
            </h1>

            <p
              style={{
                color: "#64748B",
                marginTop: "8px",
              }}
            >
              Customer Self-Service Dashboard
            </p>
          </div>

          {/* ================= ERROR ================= */}

          {error && (
            <div
              style={{
                background: "#FEE2E2",
                color: "#B91C1C",
                padding: "15px",
                borderRadius: "8px",
                marginBottom: "20px",
                border: "1px solid #FCA5A5",
              }}
            >
              {error}
            </div>
          )}

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "400px",
                maxWidth: "100%",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Customer, Invoice or Ticket..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                minWidth: "900px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Customer ID
                  </th>

                  <th>Name</th>

                  <th>Invoice</th>

                  <th>Payment</th>

                  <th>Ticket</th>

                  <th>Actions</th>
                </tr>
              </thead>

              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="6"
                      style={{
                        textAlign: "center",
                        padding: "35px",
                        color: "#64748B",
                      }}
                    >
                      Loading customer data...
                    </td>
                  </tr>
                ) : filteredCustomers.length === 0 ? (
                  <tr>
                    <td
                      colSpan="6"
                      style={{
                        textAlign: "center",
                        padding: "35px",
                        color: "#64748B",
                      }}
                    >
                      No customer data found.
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map((customer) => (
                    <tr
                      key={customer.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                          fontWeight: "600",
                        }}
                      >
                        {customer.id}
                      </td>

                      <td>{customer.name}</td>

                      <td>{customer.invoice}</td>

                      <td>
                        <span
                          style={{
                            background:
                              customer.payment === "Paid"
                                ? "#22C55E"
                                : "#F59E0B",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                          }}
                        >
                          {customer.payment}
                        </span>
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              customer.ticket === "Open"
                                ? "#F59E0B"
                                : "#3B82F6",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                          }}
                        >
                          {customer.ticket}
                        </span>
                      </td>

                      <td>
                        {/* VIEW */}

                        <button
                          title="View Customer"
                          onClick={() =>
                            handleView(customer)
                          }
                          style={buttonBlue}
                        >
                          <FaEye />
                        </button>

                        {/* DOWNLOAD */}

                        <button
                          title="Download Invoice"
                          onClick={() =>
                            handleDownload(customer)
                          }
                          style={buttonGreen}
                        >
                          <FaDownload />
                        </button>

                        {/* TICKET */}

                        <button
                          title="Create Ticket"
                          onClick={() =>
                            handleTicket(customer)
                          }
                          style={buttonOrange}
                        >
                          <FaTicketAlt />
                        </button>

                        {/* PAYMENT */}

                        <button
                          title="Payment"
                          onClick={() =>
                            handlePayment(customer)
                          }
                          style={buttonPurple}
                        >
                          <FaCreditCard />
                        </button>

                        {/* PROFILE */}

                        <button
                          title="Edit Profile"
                          onClick={() =>
                            handleProfile(customer)
                          }
                          style={buttonGray}
                        >
                          <FaUserEdit />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* ================= SUMMARY ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, 1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaUserCircle
                size={30}
                color="#4F46E5"
              />

              <h3>Customers</h3>

              <h2>{totalCustomers}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <h3>Paid</h3>

              <h2>{paidCustomers}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Pending</h3>

              <h2>{pendingCustomers}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Open Tickets</h3>

              <h2>{openTickets}</h2>
            </div>
          </div>
        </div>
      </div>

      {/* ================= CUSTOMER DETAILS MODAL ================= */}

      {showDetails && selectedCustomer && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,.55)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999,
            padding: "20px",
          }}
        >
          <div
            style={{
              background: "#fff",
              width: "500px",
              maxWidth: "100%",
              borderRadius: "15px",
              padding: "25px",
              boxShadow:
                "0 10px 30px rgba(0,0,0,.2)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Customer Details
              </h2>

              <button
                onClick={() => {
                  setShowDetails(false);
                  setSelectedCustomer(null);
                }}
                style={{
                  background: "#FEE2E2",
                  color: "#DC2626",
                  border: "none",
                  width: "35px",
                  height: "35px",
                  borderRadius: "50%",
                  cursor: "pointer",
                }}
              >
                <FaTimes />
              </button>
            </div>

            <div
              style={{
                display: "grid",
                gap: "15px",
              }}
            >
              <DetailRow
                label="Customer ID"
                value={selectedCustomer.id}
              />

              <DetailRow
                label="Customer Name"
                value={selectedCustomer.name}
              />

              <DetailRow
                label="Invoice"
                value={selectedCustomer.invoice}
              />

              <DetailRow
                label="Payment"
                value={selectedCustomer.payment}
              />

              <DetailRow
                label="Ticket"
                value={selectedCustomer.ticket}
              />
            </div>

            <button
              onClick={() => {
                setShowDetails(false);
                setSelectedCustomer(null);
              }}
              style={{
                width: "100%",
                marginTop: "25px",
                padding: "12px",
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "600",
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ==============================
// DETAIL ROW
// ==============================

function DetailRow({ label, value }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        padding: "12px",
        background: "#F8FAFC",
        borderRadius: "8px",
      }}
    >
      <strong style={{ color: "#475569" }}>
        {label}
      </strong>

      <span style={{ color: "#334155" }}>
        {value}
      </span>
    </div>
  );
}

// ==============================
// CARD STYLE
// ==============================

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

// ==============================
// BUTTON STYLES
// ==============================

const buttonBlue = {
  background: "#3B82F6",
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  marginRight: "6px",
  cursor: "pointer",
};

const buttonGreen = {
  ...buttonBlue,
  background: "#22C55E",
};

const buttonOrange = {
  ...buttonBlue,
  background: "#F59E0B",
};

const buttonPurple = {
  ...buttonBlue,
  background: "#8B5CF6",
};

const buttonGray = {
  ...buttonBlue,
  background: "#64748B",
};

export default CustomerPortal;
