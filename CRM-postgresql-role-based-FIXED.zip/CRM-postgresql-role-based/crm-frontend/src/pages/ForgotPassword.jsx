import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
function ForgotPassword() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
const handleSubmit = async (e) => {
  e.preventDefault();

  if (!email) {
    alert("Please enter your email.");
    return;
  }

  try {
    const response = await axios.post(
      "http://localhost:5000/api/auth/forgot-password",
      {
        email: email,
      }
    );

    alert(response.data.message);
    navigate("/reset-password", {
  state: { email: email },
});
  } catch (error) {
    console.error("Forgot Password Error:", error);

    if (error.response) {
      alert(error.response.data.message);
    } else {
      alert("Failed to send reset link");
    }
  }
};
  
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        background: "#EEF2FF",
      }}
    >
      <form
        onSubmit={handleSubmit}
        style={{
          width: "450px",
          background: "#fff",
          padding: "40px",
          borderRadius: "15px",
          boxShadow: "0 5px 15px rgba(0,0,0,.1)",
        }}
      >
        <h1
          style={{
            textAlign: "center",
            color: "#4F46E5",
            marginBottom: "10px",
          }}
        >
          Forgot Password
        </h1>

        <p
          style={{
            textAlign: "center",
            color: "#64748B",
            marginBottom: "30px",
          }}
        >
          Enter your registered email address to receive a password reset link.
        </p>

        <label>Email Address</label>

        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{
            width: "100%",
            padding: "12px",
            marginTop: "8px",
            marginBottom: "25px",
            borderRadius: "8px",
            border: "1px solid #CBD5E1",
            outline: "none",
          }}
        />

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "12px",
            background: "#4F46E5",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
            fontSize: "16px",
          }}
        >
          Send Reset Link
        </button>

        <p
          style={{
            marginTop: "20px",
            textAlign: "center",
          }}
        >
          <Link to="/login">Back to Login</Link>
        </p>
      </form>
    </div>
  );
}

export default ForgotPassword;