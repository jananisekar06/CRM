
import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaSearch,
  FaPlus,
  FaStar,
  FaGift,
  FaUserFriends,
  FaBook,
  FaEdit,
  FaTrash,
  FaTimes,
} from "react-icons/fa";

function CustomerExperience() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);

  const [feedbacks, setFeedbacks] = useState([
    {
      id: "FB001",
      customer: "John Smith",
      service: "CRM Setup",
      rating: 5,
      feedback: "Excellent Service",
      status: "Reviewed",
    },
    {
      id: "FB002",
      customer: "Priya",
      service: "Support",
      rating: 4,
      feedback: "Very Good",
      status: "Pending",
    },
    {
      id: "FB003",
      customer: "Rahul",
      service: "Training",
      rating: 5,
      feedback: "Outstanding",
      status: "Reviewed",
    },
    {
      id: "FB004",
      customer: "David",
      service: "Consultation",
      rating: 3,
      feedback: "Average",
      status: "Pending",
    },
  ]);

  const [form, setForm] = useState({
    customer: "",
    service: "",
    rating: 5,
    feedback: "",
    status: "Pending",
  });

  const filteredFeedback = feedbacks.filter((item) =>
    item.customer.toLowerCase().includes(search.toLowerCase())
  );

  // -----------------------------
  // Open Add Modal
  // -----------------------------
  const handleAdd = () => {
    setEditId(null);

    setForm({
      customer: "",
      service: "",
      rating: 5,
      feedback: "",
      status: "Pending",
    });

    setShowModal(true);
  };

  // -----------------------------
  // Open Edit Modal
  // -----------------------------
  const handleEdit = (item) => {
    setEditId(item.id);

    setForm({
      customer: item.customer,
      service: item.service,
      rating: item.rating,
      feedback: item.feedback,
      status: item.status,
    });

    setShowModal(true);
  };

  // -----------------------------
  // Delete
  // -----------------------------
  const handleDelete = (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this feedback?"
    );

    if (confirmDelete) {
      setFeedbacks((prev) =>
        prev.filter((item) => item.id !== id)
      );
    }
  };

  // -----------------------------
  // Form Change
  // -----------------------------
  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]:
        name === "rating" ? Number(value) : value,
    }));
  };

  // -----------------------------
  // Save Feedback
  // -----------------------------
  const handleSave = (e) => {
    e.preventDefault();

    if (
      !form.customer.trim() ||
      !form.service.trim() ||
      !form.feedback.trim()
    ) {
      alert("Please fill all required fields.");
      return;
    }

    if (editId) {
      setFeedbacks((prev) =>
        prev.map((item) =>
          item.id === editId
            ? {
                ...item,
                ...form,
              }
            : item
        )
      );
    } else {
      const newFeedback = {
        id: `FB${String(feedbacks.length + 1).padStart(
          3,
          "0"
        )}`,
        ...form,
      };

      setFeedbacks((prev) => [
        ...prev,
        newFeedback,
      ]);
    }

    setShowModal(false);
    setEditId(null);
  };

  // -----------------------------
  // Calculate Average Rating
  // -----------------------------
  const averageRating =
    feedbacks.length > 0
      ? (
          feedbacks.reduce(
            (sum, item) => sum + Number(item.rating),
            0
          ) / feedbacks.length
        ).toFixed(1)
      : "0.0";

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
            position: "relative",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "20px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Customer Experience
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginBottom: 0,
                }}
              >
                Improve customer satisfaction and retention
              </p>
            </div>

            <button
              onClick={handleAdd}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                whiteSpace: "nowrap",
              }}
            >
              <FaPlus />
              Add Feedback
            </button>
          </div>

          {/* ================= DASHBOARD CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, minmax(180px, 1fr))",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div
              style={{
                background: "#FEF3C7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaStar
                size={30}
                color="#F59E0B"
              />

              <h3>Average Rating</h3>

              <h2>{averageRating} ★</h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaGift
                size={30}
                color="#22C55E"
              />

              <h3>Loyalty Members</h3>

              <h2>182</h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaUserFriends
                size={30}
                color="#2563EB"
              />

              <h3>Referrals</h3>

              <h2>94</h2>
            </div>

            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <FaBook
                size={30}
                color="#4F46E5"
              />

              <h3>Knowledge Base</h3>

              <h2>68</h2>
            </div>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                maxWidth: "100%",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Customer..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  boxSizing: "border-box",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                }}
              />
            </div>
          </div>

          {/* ================= FEEDBACK TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                maxHeight: "400px",
                overflowY: "auto",
                overflowX: "auto",
              }}
            >
              <table
                style={{
                  width: "100%",
                  minWidth: "900px",
                  borderCollapse: "collapse",
                }}
              >
                <thead
                  style={{
                    background: "#4F46E5",
                    color: "#fff",
                    position: "sticky",
                    top: 0,
                    zIndex: 2,
                  }}
                >
                  <tr>
                    <th
                      style={{
                        padding: "15px",
                      }}
                    >
                      Feedback ID
                    </th>

                    <th>Customer</th>
                    <th>Service</th>
                    <th>Rating</th>
                    <th>Feedback</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredFeedback.map(
                    (item) => (
                      <tr
                        key={item.id}
                        style={{
                          textAlign: "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td
                          style={{
                            padding: "15px",
                          }}
                        >
                          {item.id}
                        </td>

                        <td>{item.customer}</td>

                        <td>{item.service}</td>

                        <td>
                          <span
                            style={{
                              color: "#F59E0B",
                              fontWeight:
                                "bold",
                            }}
                          >
                            {item.rating} ★
                          </span>
                        </td>

                        <td>
                          {item.feedback}
                        </td>

                        <td>
                          <span
                            style={{
                              background:
                                item.status ===
                                "Reviewed"
                                  ? "#22C55E"
                                  : "#F59E0B",
                              color: "#fff",
                              padding:
                                "5px 12px",
                              borderRadius:
                                "20px",
                              fontSize: "12px",
                            }}
                          >
                            {item.status}
                          </span>
                        </td>

                        <td
                          style={{
                            padding: "10px",
                          }}
                        >
                          <button
                            onClick={() =>
                              handleEdit(item)
                            }
                            style={{
                              background:
                                "#F59E0B",
                              color: "#fff",
                              border: "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "8px",
                              cursor:
                                "pointer",
                            }}
                            title="Edit"
                          >
                            <FaEdit />
                          </button>

                          <button
                            onClick={() =>
                              handleDelete(
                                item.id
                              )
                            }
                            style={{
                              background:
                                "#EF4444",
                              color: "#fff",
                              border: "none",
                              padding:
                                "8px 10px",
                              borderRadius:
                                "6px",
                              cursor:
                                "pointer",
                            }}
                            title="Delete"
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    )
                  )}

                  {filteredFeedback.length ===
                    0 && (
                    <tr>
                      <td
                        colSpan="7"
                        style={{
                          padding: "25px",
                          textAlign:
                            "center",
                          color: "#64748B",
                        }}
                      >
                        No feedback records
                        found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* ================= LOYALTY ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              borderRadius: "15px",
              padding: "20px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
              overflowX: "auto",
            }}
          >
            <h2
              style={{
                marginTop: 0,
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              Customer Loyalty Points
            </h2>

            <table
              style={{
                width: "100%",
                minWidth: "700px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Customer
                  </th>
                  <th>Purchase</th>
                  <th>Points Earned</th>
                  <th>Reward</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    John Smith
                  </td>
                  <td>₹15,000</td>
                  <td>150</td>
                  <td>10% Discount Coupon</td>
                  <td>
                    <Status
                      text="Available"
                      color="#22C55E"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    Priya
                  </td>
                  <td>₹8,500</td>
                  <td>85</td>
                  <td>Gift Voucher</td>
                  <td>
                    <Status
                      text="Redeemed"
                      color="#F59E0B"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    Rahul
                  </td>
                  <td>₹22,000</td>
                  <td>220</td>
                  <td>Premium Membership</td>
                  <td>
                    <Status
                      text="Earned"
                      color="#3B82F6"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ================= REFERRAL ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              borderRadius: "15px",
              padding: "20px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
              overflowX: "auto",
            }}
          >
            <h2
              style={{
                marginTop: 0,
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              Referral Program
            </h2>

            <table
              style={{
                width: "100%",
                minWidth: "700px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Referral ID
                  </th>
                  <th>Referrer</th>
                  <th>New Customer</th>
                  <th>Reward</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    REF001
                  </td>
                  <td>John Smith</td>
                  <td>David</td>
                  <td>₹500 Voucher</td>
                  <td>
                    <Status
                      text="Verified"
                      color="#22C55E"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    REF002
                  </td>
                  <td>Priya</td>
                  <td>Sneha</td>
                  <td>100 Points</td>
                  <td>
                    <Status
                      text="Pending"
                      color="#F59E0B"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    REF003
                  </td>
                  <td>Rahul</td>
                  <td>Arun</td>
                  <td>₹1000 Coupon</td>
                  <td>
                    <Status
                      text="Rewarded"
                      color="#3B82F6"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ================= CSAT ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              borderRadius: "15px",
              padding: "20px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
              overflowX: "auto",
            }}
          >
            <h2
              style={{
                marginTop: 0,
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              CSAT Survey
            </h2>

            <table
              style={{
                width: "100%",
                minWidth: "650px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Survey ID
                  </th>
                  <th>Customer</th>
                  <th>Ticket</th>
                  <th>CSAT Score</th>
                  <th>Response</th>
                </tr>
              </thead>

              <tbody>
                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    CS001
                  </td>
                  <td>John Smith</td>
                  <td>TK001</td>
                  <td>95%</td>
                  <td>
                    <Status
                      text="Excellent"
                      color="#22C55E"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    CS002
                  </td>
                  <td>Priya</td>
                  <td>TK002</td>
                  <td>88%</td>
                  <td>
                    <Status
                      text="Good"
                      color="#3B82F6"
                    />
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "15px" }}>
                    CS003
                  </td>
                  <td>Rahul</td>
                  <td>TK003</td>
                  <td>72%</td>
                  <td>
                    <Status
                      text="Average"
                      color="#F59E0B"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ================= KNOWLEDGE BASE ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              borderRadius: "15px",
              padding: "20px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginTop: 0,
              }}
            >
              Knowledge Base / FAQ
            </h2>

            <ul
              style={{
                lineHeight: "2",
                color: "#475569",
                paddingLeft: "20px",
              }}
            >
              <li>
                ❓ How to reset my password?
              </li>
              <li>📘 CRM User Guide</li>
              <li>
                🎥 Video Tutorial – Customer
                Management
              </li>
              <li>
                🛠 Troubleshooting Login Issues
              </li>
              <li>
                📄 Invoice Download Guide
              </li>
            </ul>
          </div>

          {/* ================= SUMMARY ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(5, minmax(160px, 1fr))",
              gap: "20px",
              marginTop: "35px",
            }}
          >
            <SummaryCard
              bg="#FEF3C7"
              title="Average Rating"
              value={`${averageRating} ★`}
            />

            <SummaryCard
              bg="#DCFCE7"
              title="CSAT"
              value="91%"
            />

            <SummaryCard
              bg="#DBEAFE"
              title="Loyalty Members"
              value="182"
            />

            <SummaryCard
              bg="#EEF2FF"
              title="Referrals"
              value="94"
            />

            <SummaryCard
              bg="#FCE7F3"
              title="Knowledge Articles"
              value="68"
            />
          </div>
        </div>
      </div>

      {/* ================= MODAL ================= */}

      {showModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background:
              "rgba(15, 23, 42, 0.55)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              background: "#fff",
              width: "450px",
              maxWidth: "100%",
              maxHeight: "90vh",
              overflowY: "auto",
              borderRadius: "15px",
              padding: "25px",
              boxSizing: "border-box",
              boxShadow:
                "0 20px 40px rgba(0,0,0,.25)",
            }}
          >
            {/* Modal Header */}

            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                {editId
                  ? "Edit Feedback"
                  : "Add Feedback"}
              </h2>

              <button
                onClick={() =>
                  setShowModal(false)
                }
                style={{
                  border: "none",
                  background: "#F1F5F9",
                  color: "#475569",
                  width: "35px",
                  height: "35px",
                  borderRadius: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FaTimes />
              </button>
            </div>

            {/* Form */}

            <form onSubmit={handleSave}>
              {/* Customer */}

              <label style={labelStyle}>
                Customer *
              </label>

              <input
                type="text"
                name="customer"
                value={form.customer}
                onChange={handleChange}
                placeholder="Enter customer name"
                style={inputStyle}
              />

              {/* Service */}

              <label style={labelStyle}>
                Service *
              </label>

              <input
                type="text"
                name="service"
                value={form.service}
                onChange={handleChange}
                placeholder="Enter service"
                style={inputStyle}
              />

              {/* Rating */}

              <label style={labelStyle}>
                Rating
              </label>

              <select
                name="rating"
                value={form.rating}
                onChange={handleChange}
                style={inputStyle}
              >
                <option value={5}>
                  5 - Excellent
                </option>
                <option value={4}>
                  4 - Very Good
                </option>
                <option value={3}>
                  3 - Average
                </option>
                <option value={2}>
                  2 - Poor
                </option>
                <option value={1}>
                  1 - Very Poor
                </option>
              </select>

              {/* Feedback */}

              <label style={labelStyle}>
                Feedback *
              </label>

              <textarea
                name="feedback"
                value={form.feedback}
                onChange={handleChange}
                placeholder="Enter customer feedback"
                rows="4"
                style={{
                  ...inputStyle,
                  resize: "vertical",
                }}
              />

              {/* Status */}

              <label style={labelStyle}>
                Status
              </label>

              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                style={inputStyle}
              >
                <option value="Pending">
                  Pending
                </option>

                <option value="Reviewed">
                  Reviewed
                </option>
              </select>

              {/* Buttons */}

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "10px",
                  marginTop: "20px",
                  paddingTop: "10px",
                  borderTop:
                    "1px solid #E2E8F0",
                }}
              >
                <button
                  type="button"
                  onClick={() =>
                    setShowModal(false)
                  }
                  style={{
                    background: "#E2E8F0",
                    color: "#334155",
                    border: "none",
                    padding:
                      "11px 20px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  style={{
                    background: "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding:
                      "11px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontWeight: "600",
                  }}
                >
                  {editId
                    ? "Update"
                    : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= STATUS ================= */

const Status = ({ text, color }) => (
  <span
    style={{
      background: color,
      color: "#fff",
      padding: "5px 12px",
      borderRadius: "20px",
      fontSize: "12px",
    }}
  >
    {text}
  </span>
);

/* ================= SUMMARY CARD ================= */

const SummaryCard = ({
  bg,
  title,
  value,
}) => (
  <div
    style={{
      background: bg,
      padding: "20px",
      borderRadius: "12px",
    }}
  >
    <h3>{title}</h3>
    <h2>{value}</h2>
  </div>
);

/* ================= STYLES ================= */

const labelStyle = {
  display: "block",
  color: "#334155",
  fontWeight: "600",
  marginBottom: "7px",
  marginTop: "15px",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "11px 12px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  fontSize: "14px",
  color: "#334155",
  background: "#fff",
};

export default CustomerExperience;
