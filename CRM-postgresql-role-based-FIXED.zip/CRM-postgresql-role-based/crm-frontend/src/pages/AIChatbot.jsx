
import { useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaRobot,
  FaPaperPlane,
  FaHeadset,
  FaTrash,
} from "react-icons/fa";

function AIChatbot() {
  const API_URL = "http://localhost:5000/api/ai-chatbot";

  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  // ===============================
  // SEND MESSAGE
  // ===============================

  const handleSend = async () => {
    const text = message.trim();

    if (!text) {
      alert("Please enter your question.");
      return;
    }

    // Show user message immediately
    const userMessage = {
      id: Date.now(),
      sender: "user",
      text: text,
    };

    setMessages((prev) => [...prev, userMessage]);
    setMessage("");
    setLoading(true);

    try {
      const response = await axios.post(
        `${API_URL}/chat`,
        {
          message: text,
        }
      );

      const botReply =
        response.data.reply ||
        "Sorry, I couldn't understand your question.";

      const botMessage = {
        id: Date.now() + 1,
        sender: "bot",
        text: botReply,
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Chatbot Error:", error);

      const errorMessage = {
        id: Date.now() + 1,
        sender: "bot",
        text:
          "❌ Unable to connect to AI Chatbot server. Please try again.",
      };

      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  // ===============================
  // ENTER KEY
  // ===============================

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // ===============================
  // CLEAR CHAT
  // ===============================

  const handleClearChat = () => {
    setMessages([]);
  };

  // ===============================
  // SUGGESTED QUESTION
  // ===============================

  const handleSuggestion = (question) => {
    setMessage(question);
  };

  // ===============================
  // CONNECT SUPPORT
  // ===============================

  const handleSupport = async () => {
    try {
      setLoading(true);

      const response = await axios.post(
        `${API_URL}/support`
      );

      const supportMessage = {
        id: Date.now(),
        sender: "bot",
        text:
          response.data.message ||
          "👨‍💻 You have been connected to our Support Team.",
      };

      setMessages((prev) => [
        ...prev,
        supportMessage,
      ]);
    } catch (error) {
      console.error("Support Error:", error);

      const errorMessage = {
        id: Date.now(),
        sender: "bot",
        text:
          "❌ Unable to connect to Support Team.",
      };

      setMessages((prev) => [
        ...prev,
        errorMessage,
      ]);
    } finally {
      setLoading(false);
    }
  };

  const suggestions = [
    "What are your business hours?",
    "Where is my order?",
    "How do I reset my password?",
    "What services do you provide?",
    "How can I contact support?",
    "Can I schedule a meeting?",
  ];

  return (
    <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      {/* ================= SIDEBAR ================= */}

      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        {/* ================= NAVBAR ================= */}

        <Navbar />

        <div
          style={{
            padding: "30px",
            paddingBottom: "60px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              marginBottom: "25px",
            }}
          >
            <h1
              style={{
                margin: 0,
                color: "#334155",
              }}
            >
              AI Chatbot
            </h1>

            <p
              style={{
                color: "#64748B",
                marginTop: "8px",
              }}
            >
              Customer Support Virtual Assistant
            </p>
          </div>

          {/* ================= CHAT CONTAINER ================= */}

          <div
            style={{
              background: "#FFFFFF",
              borderRadius: "15px",
              padding: "30px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            {/* ================= BOT HEADER ================= */}

            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "15px",
                marginBottom: "25px",
                flexWrap: "wrap",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "15px",
                }}
              >
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    background: "#EEF2FF",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <FaRobot
                    size={35}
                    color="#4F46E5"
                  />
                </div>

                <div>
                  <h2
                    style={{
                      margin: 0,
                      color: "#334155",
                    }}
                  >
                    Customer AI Chatbot
                  </h2>

                  <p
                    style={{
                      margin: "5px 0 0",
                      color: "#16A34A",
                      fontSize: "14px",
                      fontWeight: "600",
                    }}
                  >
                    ● Available 24/7
                  </p>
                </div>
              </div>

              {/* Clear Chat */}

              {messages.length > 0 && (
                <button
                  onClick={handleClearChat}
                  style={{
                    background: "#FEE2E2",
                    color: "#DC2626",
                    border: "none",
                    padding: "10px 15px",
                    borderRadius: "8px",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    fontWeight: "600",
                  }}
                >
                  <FaTrash />
                  Clear Chat
                </button>
              )}
            </div>

            {/* ================= CHAT HISTORY ================= */}

            <div
              style={{
                background: "#F8FAFC",
                borderRadius: "12px",
                padding: "20px",
                minHeight: "180px",
                maxHeight: "450px",
                overflowY: "auto",
                marginBottom: "20px",
              }}
            >
              {messages.length === 0 ? (
                <div
                  style={{
                    minHeight: "150px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    textAlign: "center",
                    color: "#64748B",
                  }}
                >
                  <FaRobot
                    size={40}
                    color="#4F46E5"
                  />

                  <h3
                    style={{
                      color: "#334155",
                      marginBottom: "5px",
                    }}
                  >
                    Hello! 👋
                  </h3>

                  <p>
                    How can I help you today?
                  </p>
                </div>
              ) : (
                messages.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: "flex",
                      justifyContent:
                        item.sender === "user"
                          ? "flex-end"
                          : "flex-start",
                      marginBottom: "15px",
                    }}
                  >
                    <div
                      style={{
                        maxWidth: "75%",
                        background:
                          item.sender === "user"
                            ? "#4F46E5"
                            : "#EEF2FF",
                        color:
                          item.sender === "user"
                            ? "#FFFFFF"
                            : "#334155",
                        padding: "12px 16px",
                        borderRadius:
                          item.sender === "user"
                            ? "15px 15px 3px 15px"
                            : "15px 15px 15px 3px",
                        lineHeight: "24px",
                        wordBreak: "break-word",
                      }}
                    >
                      {item.text}
                    </div>
                  </div>
                ))
              )}

              {/* Loading */}

              {loading && (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      background: "#EEF2FF",
                      color: "#4F46E5",
                      padding: "12px 16px",
                      borderRadius: "15px",
                    }}
                  >
                    🤖 Thinking...
                  </div>
                </div>
              )}
            </div>

            {/* ================= MESSAGE INPUT ================= */}

            <textarea
              rows="4"
              placeholder="Ask your question..."
              value={message}
              onChange={(e) =>
                setMessage(e.target.value)
              }
              onKeyDown={handleKeyDown}
              disabled={loading}
              style={{
                width: "100%",
                padding: "15px",
                borderRadius: "10px",
                border:
                  "1px solid #CBD5E1",
                resize: "none",
                fontSize: "15px",
                outline: "none",
                boxSizing: "border-box",
                background: loading
                  ? "#F1F5F9"
                  : "#FFFFFF",
              }}
            />

            {/* ================= ACTION BUTTONS ================= */}

            <div
              style={{
                display: "flex",
                gap: "12px",
                marginTop: "20px",
                flexWrap: "wrap",
              }}
            >
              <button
                onClick={handleSend}
                disabled={loading}
                style={{
                  background: loading
                    ? "#94A3B8"
                    : "#4F46E5",
                  color: "#FFFFFF",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontWeight: "600",
                }}
              >
                <FaPaperPlane />

                {loading
                  ? "Sending..."
                  : "Send"}
              </button>

              <button
                onClick={handleSupport}
                disabled={loading}
                style={{
                  background: loading
                    ? "#86EFAC"
                    : "#16A34A",
                  color: "#FFFFFF",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontWeight: "600",
                }}
              >
                <FaHeadset />
                Connect to Support
              </button>
            </div>
          </div>

          {/* ================= SUGGESTED QUESTIONS ================= */}

          <div
            style={{
              marginTop: "30px",
              background: "#FFFFFF",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h3
              style={{
                color: "#334155",
                marginTop: 0,
                marginBottom: "20px",
              }}
            >
              Suggested Questions
            </h3>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(250px, 1fr))",
                gap: "12px",
              }}
            >
              {suggestions.map(
                (question, index) => (
                  <button
                    key={index}
                    onClick={() =>
                      handleSuggestion(question)
                    }
                    style={{
                      background: "#F8FAFC",
                      border:
                        "1px solid #E2E8F0",
                      padding: "14px",
                      borderRadius: "8px",
                      textAlign: "left",
                      cursor: "pointer",
                      color: "#334155",
                      fontSize: "14px",
                      transition:
                        "0.2s",
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.background =
                        "#EEF2FF";
                      e.currentTarget.style.borderColor =
                        "#4F46E5";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.background =
                        "#F8FAFC";
                      e.currentTarget.style.borderColor =
                        "#E2E8F0";
                    }}
                  >
                    {question}
                  </button>
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AIChatbot;
