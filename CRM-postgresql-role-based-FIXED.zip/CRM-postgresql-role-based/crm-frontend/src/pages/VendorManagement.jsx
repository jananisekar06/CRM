
import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaTruck,
} from "react-icons/fa";

function VendorManagement() {
  const [search, setSearch] = useState("");
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [vendorData, setVendorData] = useState({
    name: "",
    purchase: "",
    payment: "Paid",
    orders: 0,
    status: "Active",
  });

  // =========================
  // FETCH VENDORS
  // =========================

  useEffect(() => {
    fetchVendors();
  }, []);

  const fetchVendors = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/vendors"
      );

      setVendors(
        Array.isArray(response.data) ? response.data : []
      );
    } catch (error) {
      console.error("Vendor Fetch Error:", error);
      setVendors([]);
    }
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setVendorData((prev) => ({
      ...prev,
      [name]: name === "orders" ? Number(value) : value,
    }));
  };

  // =========================
  // SAVE / UPDATE
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!vendorData.name || !vendorData.purchase) {
      alert("Please fill Vendor Name and Purchase");
      return;
    }

    try {
      setLoading(true);

      if (editingId) {
        const response = await axios.put(
          `http://localhost:5000/api/vendors/${editingId}`,
          vendorData
        );

        setVendors((prev) =>
          prev.map((vendor) =>
            vendor.id === editingId
              ? response.data.vendor
              : vendor
          )
        );

        alert(response.data.message);
      } else {
        const response = await axios.post(
          "http://localhost:5000/api/vendors",
          vendorData
        );

        setVendors((prev) => [
          ...prev,
          response.data.vendor,
        ]);

        alert(response.data.message);
      }

      handleReset();
    } catch (error) {
      console.error("Vendor Save Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to save vendor"
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // EDIT
  // =========================

  const handleEdit = (vendor) => {
    setEditingId(vendor.id);

    setVendorData({
      name: vendor.name || "",
      purchase: vendor.purchase || "",
      payment: vendor.payment || "Paid",
      orders: vendor.orders || 0,
      status: vendor.status || "Active",
    });

    document
      .getElementById("vendor-form")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this vendor?"
    );

    if (!confirmDelete) return;

    try {
      const response = await axios.delete(
        `http://localhost:5000/api/vendors/${id}`
      );

      setVendors((prev) =>
        prev.filter((vendor) => vendor.id !== id)
      );

      alert(response.data.message);
    } catch (error) {
      console.error("Vendor Delete Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete vendor"
      );
    }
  };

  // =========================
  // RESET
  // =========================

  const handleReset = () => {
    setEditingId(null);

    setVendorData({
      name: "",
      purchase: "",
      payment: "Paid",
      orders: 0,
      status: "Active",
    });
  };

  // =========================
  // SEARCH
  // =========================

  const filteredVendors = vendors.filter((vendor) =>
    String(vendor?.name || "")
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // =========================
  // UI
  // =========================

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Vendor Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage vendor details and transactions
              </p>
            </div>

            <button
              onClick={() =>
                document
                  .getElementById("vendor-form")
                  ?.scrollIntoView({
                    behavior: "smooth",
                  })
              }
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Add Vendor
            </button>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Vendor..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding: "12px 15px 12px 45px",
                  border: "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>
                    Vendor ID
                  </th>
                  <th>Vendor</th>
                  <th>Purchase</th>
                  <th>Payment</th>
                  <th>Orders</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredVendors.map((vendor) => (
                  <tr
                    key={vendor.id}
                    style={{
                      textAlign: "center",
                      borderBottom:
                        "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>
                      {vendor.id}
                    </td>

                    <td>{vendor.name}</td>

                    <td>{vendor.purchase}</td>

                    <td>
                      <span
                        style={{
                          background:
                            vendor.payment === "Paid"
                              ? "#22C55E"
                              : "#EF4444",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                          fontSize: "12px",
                        }}
                      >
                        {vendor.payment}
                      </span>
                    </td>

                    <td>{vendor.orders}</td>

                    <td>
                      <span
                        style={{
                          background:
                            vendor.status === "Active"
                              ? "#3B82F6"
                              : "#64748B",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                          fontSize: "12px",
                        }}
                      >
                        {vendor.status}
                      </span>
                    </td>

                    <td>
                      <button
                        onClick={() =>
                          handleEdit(vendor)
                        }
                        style={{
                          background: "#F59E0B",
                          color: "#fff",
                          border: "none",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          marginRight: "8px",
                          cursor: "pointer",
                        }}
                      >
                        <FaEdit />
                      </button>

                      <button
                        onClick={() =>
                          handleDelete(vendor.id)
                        }
                        style={{
                          background: "#EF4444",
                          color: "#fff",
                          border: "none",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          cursor: "pointer",
                        }}
                      >
                        <FaTrash />
                      </button>
                    </td>
                  </tr>
                ))}

                {filteredVendors.length === 0 && (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        padding: "25px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No vendors found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= SUMMARY ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div style={cardStyle("#EEF2FF")}>
              <FaTruck
                size={30}
                color="#4F46E5"
              />
              <h3>Total Vendors</h3>
              <h2>{vendors.length}</h2>
            </div>

            <div style={cardStyle("#DCFCE7")}>
              <h3>Paid</h3>
              <h2>
                {
                  vendors.filter(
                    (v) => v.payment === "Paid"
                  ).length
                }
              </h2>
            </div>

            <div style={cardStyle("#FEE2E2")}>
              <h3>Pending</h3>
              <h2>
                {
                  vendors.filter(
                    (v) => v.payment === "Pending"
                  ).length
                }
              </h2>
            </div>

            <div style={cardStyle("#DBEAFE")}>
              <h3>Total Orders</h3>
              <h2>
                {vendors.reduce(
                  (sum, v) =>
                    sum + Number(v.orders || 0),
                  0
                )}
              </h2>
            </div>
          </div>

          {/* ================= FORM ================= */}

          <div
            id="vendor-form"
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Update Vendor"
                : "Add New Vendor"}
            </h2>

            <form onSubmit={handleSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2,1fr)",
                  gap: "20px",
                }}
              >
                <div>
                  <label>Vendor Name</label>

                  <input
                    type="text"
                    name="name"
                    value={vendorData.name}
                    onChange={handleChange}
                    placeholder="Enter Vendor Name"
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label>Purchase Amount</label>

                  <input
                    type="text"
                    name="purchase"
                    value={vendorData.purchase}
                    onChange={handleChange}
                    placeholder="₹50,000"
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label>Payment</label>

                  <select
                    name="payment"
                    value={vendorData.payment}
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Paid">
                      Paid
                    </option>

                    <option value="Pending">
                      Pending
                    </option>
                  </select>
                </div>

                <div>
                  <label>Orders</label>

                  <input
                    type="number"
                    name="orders"
                    value={vendorData.orders}
                    onChange={handleChange}
                    min="0"
                    style={inputStyle}
                  />
                </div>

                <div>
                  <label>Status</label>

                  <select
                    name="status"
                    value={vendorData.status}
                    onChange={handleChange}
                    style={inputStyle}
                  >
                    <option value="Active">
                      Active
                    </option>

                    <option value="Inactive">
                      Inactive
                    </option>
                  </select>
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "15px",
                  marginTop: "25px",
                }}
              >
                <button
                  type="button"
                  onClick={handleReset}
                  style={{
                    background: "#E5E7EB",
                    color: "#334155",
                    border: "none",
                    padding: "12px 25px",
                    borderRadius: "8px",
                    cursor: "pointer",
                  }}
                >
                  Reset
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: loading
                      ? "#9CA3AF"
                      : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding: "12px 25px",
                    borderRadius: "8px",
                    cursor: loading
                      ? "not-allowed"
                      : "pointer",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingId
                    ? "Update Vendor"
                    : "Save Vendor"}
                </button>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  );
}

const cardStyle = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default VendorManagement;
