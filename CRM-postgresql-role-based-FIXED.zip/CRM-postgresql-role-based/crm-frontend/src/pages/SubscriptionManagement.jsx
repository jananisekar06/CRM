
import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaCrown,
  FaSearch,
  FaPlus,
  FaCheckCircle,
  FaClock,
  FaBuilding,
  FaEdit,
  FaTrash,
} from "react-icons/fa";

function SubscriptionManagement() {
  const [search, setSearch] = useState("");

  const [subscriptions, setSubscriptions] = useState([]);

  const [form, setForm] = useState({
    company: "",
    plan: "Basic",
    startDate: "",
    expiry: "",
    amount: "",
    paymentStatus: "Paid",
    renewalReminder: "7 Days Before",
    status: "Active",
  });

  const [editingId, setEditingId] = useState(null);

  // ===============================
  // GET SUBSCRIPTIONS
  // ===============================

  const fetchSubscriptions = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/subscriptions"
      );

      setSubscriptions(response.data);
    } catch (error) {
      console.error("Error fetching subscriptions:", error);
      alert("Failed to load subscriptions");
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  // ===============================
  // INPUT CHANGE
  // ===============================

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // ===============================
  // RESET FORM
  // ===============================

  const resetForm = () => {
    setForm({
      company: "",
      plan: "Basic",
      startDate: "",
      expiry: "",
      amount: "",
      paymentStatus: "Paid",
      renewalReminder: "7 Days Before",
      status: "Active",
    });

    setEditingId(null);
  };

  // ===============================
  // ADD / UPDATE
  // ===============================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.company || !form.amount || !form.expiry) {
      alert("Please fill Company, Amount and Expiry Date");
      return;
    }

    try {
      if (editingId) {
        await axios.put(
          `http://localhost:5000/api/subscriptions/${editingId}`,
          form
        );

        alert("Subscription updated successfully");
      } else {
        await axios.post(
          "http://localhost:5000/api/subscriptions",
          form
        );

        alert("Subscription added successfully");
      }

      resetForm();
      fetchSubscriptions();
    } catch (error) {
      console.error("Error saving subscription:", error);
      alert("Failed to save subscription");
    }
  };

  // ===============================
  // EDIT
  // ===============================

  const handleEdit = (subscription) => {
    setEditingId(subscription.id);

    setForm({
      company: subscription.company || "",
      plan: subscription.plan || "Basic",
      startDate: subscription.startDate || "",
      expiry: subscription.expiry || "",
      amount: subscription.amount || "",
      paymentStatus: subscription.paymentStatus || "Paid",
      renewalReminder:
        subscription.renewalReminder || "7 Days Before",
      status: subscription.status || "Active",
    });

    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth",
    });
  };

  // ===============================
  // DELETE
  // ===============================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this subscription?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(
        `http://localhost:5000/api/subscriptions/${id}`
      );

      alert("Subscription deleted successfully");

      fetchSubscriptions();
    } catch (error) {
      console.error("Error deleting subscription:", error);
      alert("Failed to delete subscription");
    }
  };

  // ===============================
  // SEARCH
  // ===============================

  const filteredSubscriptions = subscriptions.filter(
    (item) =>
      item.company
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      item.plan
        ?.toLowerCase()
        .includes(search.toLowerCase())
  );

  // ===============================
  // SUMMARY
  // ===============================

  const totalSubscribers = subscriptions.length;

  const activePlans = subscriptions.filter(
    (item) => item.status === "Active"
  ).length;

  const renewalDue = subscriptions.filter(
    (item) => item.status === "Renewal Due"
  ).length;

  const enterprisePlans = subscriptions.filter(
    (item) => item.plan === "Enterprise"
  ).length;

  const basicPlans = subscriptions.filter(
    (item) => item.plan === "Basic"
  ).length;

  const proPlans = subscriptions.filter(
    (item) => item.plan === "Pro"
  ).length;

  const enterpriseCount = subscriptions.filter(
    (item) => item.plan === "Enterprise"
  ).length;

  const monthlyRevenue = subscriptions.reduce(
    (sum, item) => sum + Number(item.amount || 0),
    0
  );

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>
          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Subscription Management
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage customer subscription plans and renewals.
              </p>
            </div>

            <button
              onClick={() => {
                resetForm();

                window.scrollTo({
                  top: document.body.scrollHeight,
                  behavior: "smooth",
                });
              }}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <FaPlus />
              New Subscription
            </button>
          </div>

          {/* DASHBOARD CARDS */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaBuilding size={30} color="#4F46E5" />

              <h3>Total Subscribers</h3>

              <h2>{totalSubscribers}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaCheckCircle size={30} color="#16A34A" />

              <h3>Active Plans</h3>

              <h2>{activePlans}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaClock size={30} color="#D97706" />

              <h3>Renewal Due</h3>

              <h2>{renewalDue}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaCrown size={30} color="#2563EB" />

              <h3>Enterprise</h3>

              <h2>{enterprisePlans}</h2>
            </div>
          </div>

          {/* SEARCH */}

          <div
            style={{
              width: "350px",
              position: "relative",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position: "absolute",
                left: "15px",
                top: "14px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search Company..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: "100%",
                padding: "12px 15px 12px 45px",
                border: "1px solid #CBD5E1",
                borderRadius: "8px",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
          </div>

          {/* SUBSCRIPTION TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>ID</th>
                  <th>Company</th>
                  <th>Plan</th>
                  <th>Expiry Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredSubscriptions.length === 0 ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No subscriptions found
                    </td>
                  </tr>
                ) : (
                  filteredSubscriptions.map((item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td style={{ padding: "15px" }}>
                        {item.id}
                      </td>

                      <td>{item.company}</td>

                      <td>{item.plan}</td>

                      <td>{item.expiry}</td>

                      <td>
                        ₹
                        {Number(
                          item.amount || 0
                        ).toLocaleString("en-IN")}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              item.status === "Active"
                                ? "#22C55E"
                                : item.status ===
                                  "Renewal Due"
                                ? "#F59E0B"
                                : "#EF4444",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                            fontSize: "12px",
                          }}
                        >
                          {item.status}
                        </span>
                      </td>

                      <td>
                        <button
                          onClick={() =>
                            handleEdit(item)
                          }
                          style={{
                            background: "#F59E0B",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            marginRight: "8px",
                            cursor: "pointer",
                          }}
                        >
                          <FaEdit />
                        </button>

                        <button
                          onClick={() =>
                            handleDelete(item.id)
                          }
                          style={{
                            background: "#EF4444",
                            color: "#fff",
                            border: "none",
                            padding: "8px 10px",
                            borderRadius: "6px",
                            cursor: "pointer",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* ADD / UPDATE FORM */}

          <form
            onSubmit={handleSubmit}
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginBottom: "20px",
              }}
            >
              {editingId
                ? "Update Subscription"
                : "Add Subscription"}
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(2,1fr)",
                gap: "20px",
              }}
            >
              <div>
                <label>Company Name</label>

                <input
                  type="text"
                  name="company"
                  value={form.company}
                  onChange={handleChange}
                  placeholder="ABC Company"
                  style={inputStyle}
                />
              </div>

              <div>
                <label>Subscription Plan</label>

                <select
                  name="plan"
                  value={form.plan}
                  onChange={handleChange}
                  style={inputStyle}
                >
                  <option>Basic</option>
                  <option>Pro</option>
                  <option>Enterprise</option>
                </select>
              </div>

              <div>
                <label>Start Date</label>

                <input
                  type="date"
                  name="startDate"
                  value={form.startDate}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              <div>
                <label>Expiry Date</label>

                <input
                  type="date"
                  name="expiry"
                  value={form.expiry}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>

              <div>
                <label>Billing Amount</label>

                <input
                  type="number"
                  name="amount"
                  value={form.amount}
                  onChange={handleChange}
                  placeholder="10000"
                  style={inputStyle}
                />
              </div>

              <div>
                <label>Payment Status</label>

                <select
                  name="paymentStatus"
                  value={form.paymentStatus}
                  onChange={handleChange}
                  style={inputStyle}
                >
                  <option>Paid</option>
                  <option>Pending</option>
                  <option>Failed</option>
                </select>
              </div>

              <div>
                <label>Renewal Reminder</label>

                <select
                  name="renewalReminder"
                  value={form.renewalReminder}
                  onChange={handleChange}
                  style={inputStyle}
                >
                  <option>7 Days Before</option>
                  <option>15 Days Before</option>
                  <option>30 Days Before</option>
                </select>
              </div>

              <div>
                <label>Status</label>

                <select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                  style={inputStyle}
                >
                  <option>Active</option>
                  <option>Renewal Due</option>
                  <option>Expired</option>
                </select>
              </div>
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: "15px",
                marginTop: "25px",
              }}
            >
              <button
                type="button"
                onClick={resetForm}
                style={{
                  background: "#E5E7EB",
                  color: "#334155",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: "pointer",
                }}
              >
                Reset
              </button>

              <button
                type="submit"
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: "pointer",
                }}
              >
                {editingId
                  ? "Update Subscription"
                  : "Save Subscription"}
              </button>
            </div>
          </form>

          {/* REVENUE STATISTICS */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Monthly Revenue</h3>

              <h2>
                ₹
                {monthlyRevenue.toLocaleString(
                  "en-IN"
                )}
              </h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Basic Plans</h3>

              <h2>{basicPlans}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Pro Plans</h3>

              <h2>{proPlans}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Enterprise</h3>

              <h2>{enterpriseCount}</h2>
            </div>
          </div>

          {/* RENEWAL HISTORY */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Recent Renewals
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "12px" }}>
                    Company
                  </th>
                  <th>Plan</th>
                  <th>Renewal Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {subscriptions
                  .slice(0, 5)
                  .map((item) => (
                    <tr
                      key={item.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td style={{ padding: "12px" }}>
                        {item.company}
                      </td>

                      <td>{item.plan}</td>

                      <td>{item.expiry}</td>

                      <td>
                        <span
                          style={{
                            background:
                              item.status ===
                              "Active"
                                ? "#22C55E"
                                : item.status ===
                                  "Renewal Due"
                                ? "#F59E0B"
                                : "#EF4444",
                            color: "#fff",
                            padding: "5px 12px",
                            borderRadius: "20px",
                          }}
                        >
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default SubscriptionManagement;
