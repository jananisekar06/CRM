import { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaEye,
  FaEnvelope,
  FaTimes,
} from "react-icons/fa";

function Email() {
  const API_URL = "http://localhost:5000/api/emails";

  const [search, setSearch] = useState("");
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [emailData, setEmailData] = useState({
    type: "Welcome",
    recipient: "",
    subject: "",
    message: "",
    date: new Date().toISOString().split("T")[0],
    status: "Pending",
  });

  // =========================
  // FETCH EMAILS
  // =========================

  useEffect(() => {
    fetchEmails();
  }, []);

  const fetchEmails = async () => {
    try {
      const response = await axios.get(API_URL);

      console.log("Email Data:", response.data);

      setEmails(
        Array.isArray(response.data)
          ? response.data
          : response.data.emails || []
      );
    } catch (error) {
      console.error("Email Fetch Error:", error);
      setEmails([]);
    }
  };

  // =========================
  // OPEN SEND EMAIL FORM
  // =========================

  const handleOpenForm = () => {
    setEditingId(null);

    setEmailData({
      type: "Welcome",
      recipient: "",
      subject: "",
      message: "",
      date: new Date().toISOString().split("T")[0],
      status: "Pending",
    });

    setShowForm(true);
  };

  // =========================
  // INPUT CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setEmailData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // CLOSE FORM
  // =========================

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingId(null);

    setEmailData({
      type: "Welcome",
      recipient: "",
      subject: "",
      message: "",
      date: new Date().toISOString().split("T")[0],
      status: "Pending",
    });
  };

  // =========================
  // ADD / UPDATE EMAIL
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !emailData.type ||
      !emailData.recipient ||
      !emailData.subject ||
      !emailData.message ||
      !emailData.date
    ) {
      alert("Please fill all required fields.");
      return;
    }

    try {
      setLoading(true);

      // =====================
      // UPDATE
      // =====================

      if (editingId) {
        const response = await axios.put(
          `${API_URL}/${editingId}`,
          emailData
        );

        const updatedEmail =
          response.data.email || response.data;

        setEmails((prev) =>
          prev.map((item) =>
            item.id === editingId
              ? updatedEmail
              : item
          )
        );

        alert(
          response.data.message ||
            "Email updated successfully."
        );
      }

      // =====================
      // CREATE / SEND
      // =====================

      else {
        const response = await axios.post(
          API_URL,
          {
            ...emailData,
            status: "Sent",
          }
        );

        const newEmail =
          response.data.email || response.data;

        setEmails((prev) => [
          ...prev,
          newEmail,
        ]);

        alert(
          response.data.message ||
            "Email sent successfully."
        );
      }

      handleCloseForm();
    } catch (error) {
      console.error(
        "Email Save Error:",
        error
      );

      alert(
        error.response?.data?.message ||
          "Failed to send email."
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // EDIT EMAIL
  // =========================

  const handleEdit = (email) => {
    setEditingId(email.id);

    setEmailData({
      type: email.type || "Welcome",
      recipient: email.recipient || "",
      subject: email.subject || "",
      message: email.message || "",
      date:
        email.date ||
        new Date().toISOString().split("T")[0],
      status: email.status || "Pending",
    });

    setShowForm(true);
  };

  // =========================
  // DELETE EMAIL
  // =========================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this email?"
    );

    if (!confirmDelete) return;

    try {
      const response = await axios.delete(
        `${API_URL}/${id}`
      );

      setEmails((prev) =>
        prev.filter((item) => item.id !== id)
      );

      alert(
        response.data.message ||
          "Email deleted successfully."
      );
    } catch (error) {
      console.error(
        "Email Delete Error:",
        error
      );

      alert(
        error.response?.data?.message ||
          "Failed to delete email."
      );
    }
  };

  // =========================
  // VIEW EMAIL
  // =========================

  const handleView = (email) => {
    alert(
      `Email Details\n\n` +
        `ID: ${email.id}\n` +
        `Type: ${email.type}\n` +
        `Recipient: ${email.recipient}\n` +
        `Subject: ${email.subject}\n` +
        `Message: ${email.message || "No message"}\n` +
        `Date: ${email.date}\n` +
        `Status: ${email.status}`
    );
  };

  // =========================
  // SEARCH
  // =========================

  const filteredEmails = emails.filter(
    (email) => {
      const searchText =
        search.toLowerCase();

      return (
        String(email?.recipient || "")
          .toLowerCase()
          .includes(searchText) ||
        String(email?.subject || "")
          .toLowerCase()
          .includes(searchText) ||
        String(email?.type || "")
          .toLowerCase()
          .includes(searchText)
      );
    }
  );

  // =========================
  // UI
  // =========================

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div
          style={{
            padding: "30px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Email Management
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginTop: "8px",
                }}
              >
                Manage and send emails
              </p>
            </div>

            {/* SEND EMAIL BUTTON */}

            <button
              type="button"
              onClick={handleOpenForm}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "13px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
                fontWeight: "600",
                fontSize: "14px",
              }}
            >
              <FaPlus />
              Send Email
            </button>
          </div>

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <div
              style={{
                width: "350px",
                position: "relative",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "15px",
                  top: "14px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Recipient..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={thStyle}>
                    ID
                  </th>

                  <th style={thStyle}>
                    Email Type
                  </th>

                  <th style={thStyle}>
                    Recipient
                  </th>

                  <th style={thStyle}>
                    Subject
                  </th>

                  <th style={thStyle}>
                    Date
                  </th>

                  <th style={thStyle}>
                    Status
                  </th>

                  <th style={thStyle}>
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredEmails.map(
                  (email, index) => (
                    <tr
                      key={
                        email?.id ||
                        index
                      }
                      style={{
                        textAlign:
                          "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {email?.id ||
                          `EM${String(
                            index + 1
                          ).padStart(
                            3,
                            "0"
                          )}`}
                      </td>

                      <td>
                        {email?.type ||
                          "-"}
                      </td>

                      <td>
                        {email?.recipient ||
                          "-"}
                      </td>

                      <td>
                        {email?.subject ||
                          "-"}
                      </td>

                      <td>
                        {email?.date ||
                          "-"}
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              email?.status ===
                              "Sent"
                                ? "#22C55E"
                                : "#F59E0B",
                            color:
                              "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize:
                              "12px",
                          }}
                        >
                          {email?.status ||
                            "-"}
                        </span>
                      </td>

                      <td>
                        {/* VIEW */}

                        <button
                          type="button"
                          onClick={() =>
                            handleView(
                              email
                            )
                          }
                          style={{
                            ...actionButton,
                            background:
                              "#3B82F6",
                          }}
                        >
                          <FaEye />
                        </button>

                        {/* EDIT */}

                        <button
                          type="button"
                          onClick={() =>
                            handleEdit(
                              email
                            )
                          }
                          style={{
                            ...actionButton,
                            background:
                              "#F59E0B",
                          }}
                        >
                          <FaEdit />
                        </button>

                        {/* DELETE */}

                        <button
                          type="button"
                          onClick={() =>
                            handleDelete(
                              email.id
                            )
                          }
                          style={{
                            ...actionButton,
                            background:
                              "#EF4444",
                          }}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  )
                )}

                {filteredEmails.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="7"
                      style={{
                        padding: "25px",
                        textAlign:
                          "center",
                        color:
                          "#64748B",
                      }}
                    >
                      No email records
                      found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ================= SEND EMAIL MODAL ================= */}

          {showForm && (
            <div
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background:
                  "rgba(15, 23, 42, 0.55)",
                display: "flex",
                justifyContent:
                  "center",
                alignItems: "center",
                zIndex: 9999,
                padding: "20px",
              }}
            >
              <div
                style={{
                  width: "650px",
                  maxWidth: "100%",
                  background: "#fff",
                  borderRadius: "15px",
                  padding: "30px",
                  boxShadow:
                    "0 20px 50px rgba(0,0,0,.2)",
                  maxHeight: "90vh",
                  overflowY: "auto",
                }}
              >
                {/* MODAL HEADER */}

                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "space-between",
                    alignItems:
                      "center",
                    marginBottom:
                      "25px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems:
                        "center",
                      gap: "12px",
                    }}
                  >
                    <FaEnvelope
                      size={25}
                      color="#4F46E5"
                    />

                    <h2
                      style={{
                        margin: 0,
                        color:
                          "#334155",
                      }}
                    >
                      {editingId
                        ? "Edit Email"
                        : "Send New Email"}
                    </h2>
                  </div>

                  <button
                    type="button"
                    onClick={
                      handleCloseForm
                    }
                    style={{
                      border: "none",
                      background:
                        "#F1F5F9",
                      width: "35px",
                      height: "35px",
                      borderRadius:
                        "50%",
                      cursor:
                        "pointer",
                      display: "flex",
                      alignItems:
                        "center",
                      justifyContent:
                        "center",
                    }}
                  >
                    <FaTimes />
                  </button>
                </div>

                {/* FORM */}

                <form
                  onSubmit={
                    handleSubmit
                  }
                >
                  {/* EMAIL TYPE */}

                  <div
                    style={{
                      marginBottom:
                        "18px",
                    }}
                  >
                    <label
                      style={
                        labelStyle
                      }
                    >
                      Email Type
                    </label>

                    <select
                      name="type"
                      value={
                        emailData.type
                      }
                      onChange={
                        handleChange
                      }
                      style={
                        inputStyle
                      }
                    >
                      <option value="Welcome">
                        Welcome
                      </option>

                      <option value="Proposal">
                        Proposal
                      </option>

                      <option value="Meeting Reminder">
                        Meeting Reminder
                      </option>

                      <option value="Invoice">
                        Invoice
                      </option>

                      <option value="Payment Reminder">
                        Payment Reminder
                      </option>

                      <option value="Other">
                        Other
                      </option>
                    </select>
                  </div>

                  {/* RECIPIENT */}

                  <div
                    style={{
                      marginBottom:
                        "18px",
                    }}
                  >
                    <label
                      style={
                        labelStyle
                      }
                    >
                      Recipient Email
                    </label>

                    <input
                      type="email"
                      name="recipient"
                      value={
                        emailData.recipient
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="example@gmail.com"
                      style={
                        inputStyle
                      }
                      required
                    />
                  </div>

                  {/* SUBJECT */}

                  <div
                    style={{
                      marginBottom:
                        "18px",
                    }}
                  >
                    <label
                      style={
                        labelStyle
                      }
                    >
                      Subject
                    </label>

                    <input
                      type="text"
                      name="subject"
                      value={
                        emailData.subject
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="Enter email subject"
                      style={
                        inputStyle
                      }
                      required
                    />
                  </div>

                  {/* MESSAGE */}

                  <div
                    style={{
                      marginBottom:
                        "18px",
                    }}
                  >
                    <label
                      style={
                        labelStyle
                      }
                    >
                      Message
                    </label>

                    <textarea
                      name="message"
                      value={
                        emailData.message
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="Write your email message..."
                      rows="6"
                      style={{
                        ...inputStyle,
                        resize:
                          "vertical",
                        fontFamily:
                          "inherit",
                      }}
                      required
                    />
                  </div>

                  {/* DATE */}

                  <div
                    style={{
                      marginBottom:
                        "18px",
                    }}
                  >
                    <label
                      style={
                        labelStyle
                      }
                    >
                      Date
                    </label>

                    <input
                      type="date"
                      name="date"
                      value={
                        emailData.date
                      }
                      onChange={
                        handleChange
                      }
                      style={
                        inputStyle
                      }
                      required
                    />
                  </div>

                  {/* BUTTONS */}

                  <div
                    style={{
                      display: "flex",
                      justifyContent:
                        "flex-end",
                      gap: "12px",
                      marginTop:
                        "25px",
                    }}
                  >
                    <button
                      type="button"
                      onClick={
                        handleCloseForm
                      }
                      style={{
                        background:
                          "#E2E8F0",
                        color:
                          "#334155",
                        border:
                          "none",
                        padding:
                          "12px 22px",
                        borderRadius:
                          "8px",
                        cursor:
                          "pointer",
                      }}
                    >
                      Cancel
                    </button>

                    <button
                      type="submit"
                      disabled={
                        loading
                      }
                      style={{
                        background:
                          loading
                            ? "#94A3B8"
                            : "#4F46E5",
                        color:
                          "#fff",
                        border:
                          "none",
                        padding:
                          "12px 25px",
                        borderRadius:
                          "8px",
                        cursor:
                          loading
                            ? "not-allowed"
                            : "pointer",
                        display:
                          "flex",
                        alignItems:
                          "center",
                        gap: "8px",
                        fontWeight:
                          "600",
                      }}
                    >
                      <FaEnvelope />

                      {loading
                        ? "Sending..."
                        : editingId
                        ? "Update Email"
                        : "Send Email"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* ================= SUMMARY ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4,1fr)",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background:
                  "#EEF2FF",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <FaEnvelope
                size={30}
                color="#4F46E5"
              />

              <h3>Total Emails</h3>
              <h2>{emails.length}</h2>
            </div>

            <div
              style={{
                background:
                  "#DCFCE7",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <h3>Sent</h3>

              <h2>
                {
                  emails.filter(
                    (e) =>
                      e.status ===
                      "Sent"
                  ).length
                }
              </h2>
            </div>

            <div
              style={{
                background:
                  "#FEF3C7",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <h3>Pending</h3>

              <h2>
                {
                  emails.filter(
                    (e) =>
                      e.status ===
                      "Pending"
                  ).length
                }
              </h2>
            </div>

            <div
              style={{
                background:
                  "#DBEAFE",
                padding: "20px",
                borderRadius:
                  "12px",
              }}
            >
              <h3>Templates</h3>
              <h2>5</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// =========================
// STYLES
// =========================

const labelStyle = {
  display: "block",
  color: "#334155",
  fontWeight: "600",
  marginBottom: "6px",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
  fontSize: "14px",
};

const thStyle = {
  padding: "15px",
};

const actionButton = {
  color: "#fff",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  marginRight: "8px",
  cursor: "pointer",
};

export default Email;