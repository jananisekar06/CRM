import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
function ResetPassword() {
  const navigate = useNavigate();
const location = useLocation();
const email = location.state?.email || "";
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

 const handleReset = async (e) => {
  e.preventDefault();

  if (password !== confirmPassword) {
    alert("Passwords do not match.");
    return;
  }

  try {
    const response = await axios.post(
      "http://localhost:5000/api/auth/reset-password",
      {
       email: email,
        newPassword: password,
        confirmPassword: confirmPassword,
      }
    );

    alert(response.data.message);

    navigate("/login");
  } catch (error) {
    console.error("Reset Password Error:", error);

    if (error.response) {
      alert(error.response.data.message);
    } else {
      alert("Failed to reset password");
    }
  }
};

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        background: "#EEF2FF",
      }}
    >
      <form
        onSubmit={handleReset}
        style={{
          width: "450px",
          background: "#fff",
          padding: "40px",
          borderRadius: "15px",
          boxShadow: "0 5px 15px rgba(0,0,0,.1)",
        }}
      >
        <h1
          style={{
            textAlign: "center",
            color: "#4F46E5",
            marginBottom: "10px",
          }}
        >
          Reset Password
        </h1>

        <p
          style={{
            textAlign: "center",
            color: "#64748B",
            marginBottom: "30px",
          }}
        >
          Enter your new password.
        </p>

        <label>New Password</label>

        <input
          type="password"
          placeholder="Enter new password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{
            width: "100%",
            padding: "12px",
            marginTop: "8px",
            marginBottom: "20px",
            border: "1px solid #CBD5E1",
            borderRadius: "8px",
          }}
        />

        <label>Confirm Password</label>

        <input
          type="password"
          placeholder="Confirm password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          style={{
            width: "100%",
            padding: "12px",
            marginTop: "8px",
            marginBottom: "25px",
            border: "1px solid #CBD5E1",
            borderRadius: "8px",
          }}
        />

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "12px",
            background: "#4F46E5",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
            fontSize: "16px",
          }}
        >
          Update Password
        </button>
      </form>
    </div>
  );
}

export default ResetPassword;