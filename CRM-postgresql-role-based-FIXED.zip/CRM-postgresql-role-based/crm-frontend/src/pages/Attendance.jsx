import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { FaPlus, FaSearch } from "react-icons/fa";

const emptyAttendance = {
  name: "",
  department: "",
  date: new Date().toISOString().split("T")[0],
  status: "Present",
};

function Attendance() {
  const [attendanceData, setAttendanceData] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [attendance, setAttendance] = useState(emptyAttendance);

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/attendance");
        setAttendanceData(response.data);
      } catch (error) {
        alert("Backend is not running. Start the backend and refresh this page.");
      }
    };

    fetchAttendance();
  }, []);

  const markAttendance = async () => {
    if (!attendance.name || !attendance.department || !attendance.date) {
      alert("Please fill all attendance details");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/attendance",
        attendance
      );
      setAttendanceData((currentData) => [...currentData, response.data.attendance]);
      alert(response.data.message);
      setAttendance(emptyAttendance);
      setShowModal(false);
    } catch (error) {
      alert("Failed to mark attendance");
    }
  };

  const filteredAttendance = attendanceData.filter((item) =>
    `${item.name} ${item.department}`.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusStyle = (status) => {
    if (status === "Present") return { background: "#22C55E", color: "#fff" };
    if (status === "Absent") return { background: "#EF4444", color: "#fff" };
    return { background: "#F59E0B", color: "#fff" };
  };

  const setField = (field, value) => setAttendance({ ...attendance, [field]: value });

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />
      <div style={{ flex: 1, minWidth: 0 }}>
        <Navbar />
        <main style={{ padding: "30px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "30px", gap: "20px" }}>
            <div>
              <h1 style={{ margin: 0, color: "#1E293B", fontSize: "36px" }}>Attendance Management</h1>
              <p style={{ margin: "10px 0 0", color: "#64748B", fontSize: "16px" }}>Daily Employee Attendance</p>
            </div>
            <button onClick={() => setShowModal(true)} style={markButtonStyle}><FaPlus /> Mark Attendance</button>
          </div>

          <div style={searchBoxStyle}>
            <div style={searchInputBoxStyle}>
              <FaSearch color="#64748B" />
              <input type="text" placeholder="Search Employee..." value={search} onChange={(event) => setSearch(event.target.value)} style={searchInputStyle} />
            </div>
          </div>

          <div style={tableBoxStyle}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#4F46E5", color: "#fff" }}>
                  <th style={headerStyle}>ID</th><th style={headerStyle}>Name</th><th style={headerStyle}>Department</th><th style={headerStyle}>Date</th><th style={headerStyle}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredAttendance.map((item) => (
                  <tr key={item.id}>
                    <td style={cellStyle}>{item.id}</td>
                    <td style={cellStyle}>{item.name}</td>
                    <td style={cellStyle}>{item.department}</td>
                    <td style={cellStyle}>{item.date}</td>
                    <td style={cellStyle}><span style={{ ...getStatusStyle(item.status), display: "inline-block", padding: "7px 14px", borderRadius: "20px", fontSize: "12px", fontWeight: "600" }}>{item.status}</span></td>
                  </tr>
                ))}
                {filteredAttendance.length === 0 && <tr><td colSpan="5" style={{ padding: "25px", textAlign: "center", color: "#64748B" }}>No attendance records found.</td></tr>}
              </tbody>
            </table>
          </div>
        </main>
      </div>

      {showModal && (
        <div style={overlayStyle}>
          <div style={modalStyle}>
            <h2>Mark Attendance</h2>
            <input placeholder="Employee Name" value={attendance.name} onChange={(event) => setField("name", event.target.value)} style={inputStyle} />
            <input placeholder="Department" value={attendance.department} onChange={(event) => setField("department", event.target.value)} style={inputStyle} />
            <input type="date" value={attendance.date} onChange={(event) => setField("date", event.target.value)} style={inputStyle} />
            <select value={attendance.status} onChange={(event) => setField("status", event.target.value)} style={inputStyle}>
              <option value="Present">Present</option><option value="Absent">Absent</option><option value="Leave">Leave</option>
            </select>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: "20px" }}>
              <button onClick={markAttendance} style={saveButtonStyle}>Save</button>
              <button onClick={() => setShowModal(false)} style={closeButtonStyle}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const markButtonStyle = { display: "flex", alignItems: "center", gap: "10px", background: "#4F46E5", color: "#fff", border: "none", borderRadius: "9px", padding: "14px 20px", cursor: "pointer", fontWeight: "600" };
const searchBoxStyle = { background: "#fff", padding: "20px", borderRadius: "15px", marginBottom: "25px", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const searchInputBoxStyle = { display: "flex", alignItems: "center", gap: "12px", border: "1px solid #CBD5E1", borderRadius: "9px", padding: "12px 15px", maxWidth: "410px" };
const searchInputStyle = { border: "none", outline: "none", width: "100%", fontSize: "14px", color: "#334155" };
const tableBoxStyle = { background: "#fff", borderRadius: "15px", overflow: "hidden", boxShadow: "0 5px 15px rgba(0,0,0,0.06)" };
const headerStyle = { padding: "17px 20px", textAlign: "left", fontSize: "15px", fontWeight: "700" };
const cellStyle = { padding: "17px 20px", borderBottom: "1px solid #E2E8F0", color: "#64748B", fontSize: "15px" };
const overlayStyle = { position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" };
const modalStyle = { background: "#fff", padding: "30px", width: "450px", borderRadius: "10px" };
const inputStyle = { width: "100%", padding: "10px", marginBottom: "15px", border: "1px solid #CBD5E1", borderRadius: "6px", boxSizing: "border-box" };
const saveButtonStyle = { background: "#4F46E5", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };
const closeButtonStyle = { background: "#EF4444", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" };

export default Attendance;
