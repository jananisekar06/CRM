import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaEye,
  FaTimes,
} from "react-icons/fa";

const API_URL = "http://localhost:5000/api/tickets";

function TicketManagement() {
  const [tickets, setTickets] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [viewTicket, setViewTicket] = useState(null);
  const [editingTicket, setEditingTicket] = useState(null);

  const [formData, setFormData] = useState({
    customer: "",
    employee: "",
    issue: "",
    priority: "Medium",
    status: "Open",
    date: new Date().toISOString().split("T")[0],
  });

  // =========================
  // FETCH TICKETS
  // =========================

  const fetchTickets = async () => {
    try {
      setLoading(true);

      const response = await axios.get(API_URL);

      console.log("GET TICKETS:", response.data);

      const data = Array.isArray(response.data)
        ? response.data
        : response.data.tickets ||
          response.data.data ||
          [];

      setTickets(data);
    } catch (error) {
      console.error(
        "Ticket Fetch Error:",
        error.response?.data || error.message
      );

      alert(
        error.response?.data?.message ||
          "Failed to load tickets. Check backend server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  // =========================
  // RESET FORM
  // =========================

  const resetForm = () => {
    setFormData({
      customer: "",
      employee: "",
      issue: "",
      priority: "Medium",
      status: "Open",
      date: new Date().toISOString().split("T")[0],
    });

    setEditingTicket(null);
  };

  // =========================
  // OPEN ADD
  // =========================

  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };

  // =========================
  // OPEN EDIT
  // =========================

  const openEditModal = (ticket) => {
    setEditingTicket(ticket);

    setFormData({
      customer: ticket.customer || "",
      employee:
        ticket.employee ||
        ticket.assignedTo ||
        "",
      issue: ticket.issue || "",
      priority: ticket.priority || "Medium",
      status: ticket.status || "Open",
      date: ticket.date
        ? String(ticket.date).substring(0, 10)
        : new Date().toISOString().split("T")[0],
    });

    setShowModal(true);
  };

  // =========================
  // CLOSE MODAL
  // =========================

  const closeModal = () => {
    setShowModal(false);
    resetForm();
  };

  // =========================
  // FORM CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // =========================
  // SAVE TICKET
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.customer.trim() ||
      !formData.employee.trim() ||
      !formData.issue.trim() ||
      !formData.date
    ) {
      alert(
        "Please fill Customer Name, Employee Name, Issue and Date."
      );
      return;
    }

    try {
      setLoading(true);

      const payload = {
        customer: formData.customer.trim(),
        employee: formData.employee.trim(),
        assignedTo: formData.employee.trim(),
        issue: formData.issue.trim(),
        priority: formData.priority,
        status: formData.status,
        date: formData.date,
      };

      console.log("SENDING TICKET:", payload);

      // =========================
      // UPDATE
      // =========================

      if (editingTicket) {
        const response = await axios.put(
          `${API_URL}/${editingTicket.id}`,
          payload
        );

        console.log(
          "UPDATE RESPONSE:",
          response.data
        );

        const updatedTicket =
          response.data.ticket ||
          response.data.data ||
          response.data;

        setTickets((prev) =>
          prev.map((item) =>
            item.id === editingTicket.id
              ? updatedTicket
              : item
          )
        );

        alert(
          response.data.message ||
            "Ticket updated successfully"
        );

        closeModal();
        return;
      }

      // =========================
      // CREATE
      // =========================

      const response = await axios.post(
        API_URL,
        payload
      );

      console.log(
        "CREATE RESPONSE:",
        response.data
      );

      const newTicket =
        response.data.ticket ||
        response.data.data ||
        response.data;

      setTickets((prev) => [
        ...prev,
        newTicket,
      ]);

      alert(
        response.data.message ||
          "Ticket created successfully"
      );

      closeModal();
    } catch (error) {
      console.error(
        "Ticket Save Error:",
        error.response?.data || error
      );

      const message =
        error.response?.data?.message ||
        error.response?.data?.error ||
        error.message;

      alert(
        `Ticket Save Failed!\n\n${message}`
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // DELETE
  // =========================

  const handleDelete = async (ticket) => {
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${ticket.id}?`
    );

    if (!confirmDelete) return;

    try {
      setLoading(true);

      const response = await axios.delete(
        `${API_URL}/${ticket.id}`
      );

      setTickets((prev) =>
        prev.filter(
          (item) => item.id !== ticket.id
        )
      );

      alert(
        response.data.message ||
          "Ticket deleted successfully"
      );
    } catch (error) {
      console.error(
        "Delete Error:",
        error.response?.data || error
      );

      alert(
        error.response?.data?.message ||
          "Failed to delete ticket"
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // SEARCH
  // =========================

  const filteredTickets = tickets.filter(
    (ticket) => {
      const value =
        search.toLowerCase().trim();

      return (
        String(ticket.id || "")
          .toLowerCase()
          .includes(value) ||
        String(ticket.customer || "")
          .toLowerCase()
          .includes(value) ||
        String(
          ticket.employee ||
            ticket.assignedTo ||
            ""
        )
          .toLowerCase()
          .includes(value) ||
        String(ticket.issue || "")
          .toLowerCase()
          .includes(value) ||
        String(ticket.priority || "")
          .toLowerCase()
          .includes(value) ||
        String(ticket.status || "")
          .toLowerCase()
          .includes(value)
      );
    }
  );

  // =========================
  // COUNT
  // =========================

  const totalTickets = tickets.length;

  const openTickets = tickets.filter(
    (ticket) => ticket.status === "Open"
  ).length;

  const progressTickets = tickets.filter(
    (ticket) =>
      ticket.status === "In Progress"
  ).length;

  const closedTickets = tickets.filter(
    (ticket) => ticket.status === "Closed"
  ).length;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F8FAFC",
      }}
    >
      <Sidebar />

      <div
        style={{
          marginLeft: "260px",
          minHeight: "100vh",
        }}
      >
        <Navbar />

        <main
          style={{
            padding: "25px",
            maxWidth: "1450px",
            margin: "0 auto",
          }}
        >
          {/* HEADER */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "20px",
              gap: "15px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                  fontSize: "28px",
                }}
              >
                Ticket Management
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginTop: "6px",
                  marginBottom: 0,
                }}
              >
                Manage customer support tickets
              </p>
            </div>

            <button
              onClick={openAddModal}
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "11px 18px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                fontWeight: "600",
              }}
            >
              <FaPlus />
              Create Ticket
            </button>
          </div>

          {/* COUNT BOXES */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, 1fr)",
              gap: "15px",
              marginBottom: "20px",
            }}
          >
            {[
              ["Total Tickets", totalTickets],
              ["Open", openTickets],
              ["In Progress", progressTickets],
              ["Closed", closedTickets],
            ].map(([title, count]) => (
              <div
                key={title}
                style={{
                  background: "#fff",
                  padding: "18px",
                  borderRadius: "10px",
                  boxShadow:
                    "0 3px 10px rgba(0,0,0,.06)",
                }}
              >
                <div
                  style={{
                    color: "#64748B",
                    fontSize: "13px",
                    marginBottom: "8px",
                  }}
                >
                  {title}
                </div>

                <div
                  style={{
                    color: "#334155",
                    fontSize: "25px",
                    fontWeight: "700",
                  }}
                >
                  {count}
                </div>
              </div>
            ))}
          </div>

          {/* SEARCH */}

          <div
            style={{
              background: "#fff",
              padding: "15px",
              borderRadius: "10px",
              marginBottom: "20px",
              boxShadow:
                "0 3px 10px rgba(0,0,0,.06)",
            }}
          >
            <div
              style={{
                position: "relative",
                maxWidth: "400px",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  left: "13px",
                  top: "13px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search tickets..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  boxSizing: "border-box",
                  padding:
                    "11px 12px 11px 40px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "7px",
                  outline: "none",
                }}
              />
            </div>
          </div>

          {/* TABLE */}

          <div
            style={{
              background: "#fff",
              borderRadius: "12px",
              overflow: "hidden",
              boxShadow:
                "0 3px 10px rgba(0,0,0,.06)",
            }}
          >
            <div
              style={{
                padding: "17px 20px",
                borderBottom:
                  "1px solid #E2E8F0",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: "18px",
                  color: "#334155",
                }}
              >
                Ticket Records
              </h2>
            </div>

            <div
              style={{
                width: "100%",
                overflowX: "auto",
              }}
            >
              <table
                style={{
                  width: "100%",
                  minWidth: "950px",
                  borderCollapse: "collapse",
                }}
              >
                <thead
                  style={{
                    background: "#4F46E5",
                    color: "#fff",
                  }}
                >
                  <tr>
                    {[
                      "Ticket ID",
                      "Customer",
                      "Employee",
                      "Issue",
                      "Priority",
                      "Date",
                      "Status",
                      "Action",
                    ].map((heading) => (
                      <th
                        key={heading}
                        style={{
                          padding: "12px 10px",
                          fontSize: "12px",
                          textAlign: "center",
                        }}
                      >
                        {heading}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {filteredTickets.map(
                    (ticket) => (
                      <tr
                        key={ticket.id}
                        style={{
                          borderBottom:
                            "1px solid #E2E8F0",
                          textAlign: "center",
                        }}
                      >
                        <td
                          style={{
                            padding: "13px 8px",
                            fontWeight: "600",
                          }}
                        >
                          {ticket.id}
                        </td>

                        <td>
                          {ticket.customer || "-"}
                        </td>

                        <td>
                          {ticket.employee ||
                            ticket.assignedTo ||
                            "-"}
                        </td>

                        <td
                          style={{
                            maxWidth: "220px",
                            padding: "10px",
                          }}
                        >
                          {ticket.issue || "-"}
                        </td>

                        <td>
                          <span
                            style={{
                              background:
                                ticket.priority ===
                                "High"
                                  ? "#FEE2E2"
                                  : ticket.priority ===
                                    "Medium"
                                  ? "#FEF3C7"
                                  : "#DCFCE7",
                              color:
                                ticket.priority ===
                                "High"
                                  ? "#DC2626"
                                  : ticket.priority ===
                                    "Medium"
                                  ? "#B45309"
                                  : "#15803D",
                              padding:
                                "5px 10px",
                              borderRadius:
                                "20px",
                              fontSize: "11px",
                              fontWeight: "600",
                            }}
                          >
                            {ticket.priority}
                          </span>
                        </td>

                        <td>
                          {ticket.date
                            ? String(
                                ticket.date
                              ).substring(0, 10)
                            : "-"}
                        </td>

                        <td>
                          <span
                            style={{
                              background:
                                ticket.status ===
                                "Closed"
                                  ? "#DCFCE7"
                                  : ticket.status ===
                                    "In Progress"
                                  ? "#DBEAFE"
                                  : "#FEE2E2",
                              color:
                                ticket.status ===
                                "Closed"
                                  ? "#15803D"
                                  : ticket.status ===
                                    "In Progress"
                                  ? "#2563EB"
                                  : "#DC2626",
                              padding:
                                "5px 10px",
                              borderRadius:
                                "20px",
                              fontSize: "11px",
                              fontWeight: "600",
                            }}
                          >
                            {ticket.status}
                          </span>
                        </td>

                        <td
                          style={{
                            padding: "10px",
                          }}
                        >
                          {/* VIEW */}

                          <button
                            onClick={() =>
                              setViewTicket(ticket)
                            }
                            style={{
                              background:
                                "#DBEAFE",
                              color:
                                "#2563EB",
                              border: "none",
                              padding:
                                "7px 9px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "5px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaEye />
                          </button>

                          {/* EDIT */}

                          <button
                            onClick={() =>
                              openEditModal(ticket)
                            }
                            style={{
                              background:
                                "#FEF3C7",
                              color:
                                "#D97706",
                              border: "none",
                              padding:
                                "7px 9px",
                              borderRadius:
                                "6px",
                              marginRight:
                                "5px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaEdit />
                          </button>

                          {/* DELETE */}

                          <button
                            onClick={() =>
                              handleDelete(
                                ticket
                              )
                            }
                            style={{
                              background:
                                "#FEE2E2",
                              color:
                                "#DC2626",
                              border: "none",
                              padding:
                                "7px 9px",
                              borderRadius:
                                "6px",
                              cursor:
                                "pointer",
                            }}
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    )
                  )}

                  {filteredTickets.length ===
                    0 && (
                    <tr>
                      <td
                        colSpan="8"
                        style={{
                          padding: "35px",
                          color: "#64748B",
                        }}
                      >
                        {loading
                          ? "Loading..."
                          : "No tickets found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* =========================
          CREATE / EDIT MODAL
      ========================= */}

      {showModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background:
              "rgba(15,23,42,.55)",
            zIndex: 99999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: "520px",
              maxHeight: "90vh",
              overflowY: "auto",
              background: "#fff",
              borderRadius: "12px",
              boxShadow:
                "0 20px 50px rgba(0,0,0,.25)",
            }}
          >
            {/* MODAL HEADER */}

            <div
              style={{
                background: "#4F46E5",
                color: "#fff",
                padding: "17px 20px",
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems: "center",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: "19px",
                }}
              >
                {editingTicket
                  ? "Edit Ticket"
                  : "Create Ticket"}
              </h2>

              <button
                onClick={closeModal}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#fff",
                  fontSize: "18px",
                  cursor: "pointer",
                }}
              >
                <FaTimes />
              </button>
            </div>

            {/* FORM */}

            <form
              onSubmit={handleSubmit}
              style={{
                padding: "22px",
              }}
            >
              {/* CUSTOMER */}

              <div style={{ marginBottom: "15px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "6px",
                    fontWeight: "600",
                    fontSize: "13px",
                    color: "#334155",
                  }}
                >
                  Customer Name *
                </label>

                <input
                  name="customer"
                  value={formData.customer}
                  onChange={handleChange}
                  placeholder="Enter customer name"
                  required
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "11px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "7px",
                  }}
                />
              </div>

              {/* EMPLOYEE */}

              <div style={{ marginBottom: "15px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "6px",
                    fontWeight: "600",
                    fontSize: "13px",
                    color: "#334155",
                  }}
                >
                  Employee Name *
                </label>

                <input
                  name="employee"
                  value={formData.employee}
                  onChange={handleChange}
                  placeholder="Enter employee name"
                  required
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "11px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "7px",
                  }}
                />
              </div>

              {/* ISSUE */}

              <div style={{ marginBottom: "15px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "6px",
                    fontWeight: "600",
                    fontSize: "13px",
                    color: "#334155",
                  }}
                >
                  Issue / Problem *
                </label>

                <textarea
                  name="issue"
                  value={formData.issue}
                  onChange={handleChange}
                  placeholder="Enter customer issue"
                  required
                  rows="4"
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "11px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "7px",
                    resize: "vertical",
                  }}
                />
              </div>

              {/* PRIORITY + STATUS */}

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "1fr 1fr",
                  gap: "12px",
                  marginBottom: "15px",
                }}
              >
                <div>
                  <label
                    style={{
                      display: "block",
                      marginBottom: "6px",
                      fontWeight: "600",
                      fontSize: "13px",
                    }}
                  >
                    Priority
                  </label>

                  <select
                    name="priority"
                    value={formData.priority}
                    onChange={handleChange}
                    style={{
                      width: "100%",
                      padding: "11px",
                      border:
                        "1px solid #CBD5E1",
                      borderRadius: "7px",
                    }}
                  >
                    <option value="Low">
                      Low
                    </option>

                    <option value="Medium">
                      Medium
                    </option>

                    <option value="High">
                      High
                    </option>
                  </select>
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      marginBottom: "6px",
                      fontWeight: "600",
                      fontSize: "13px",
                    }}
                  >
                    Status
                  </label>

                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    style={{
                      width: "100%",
                      padding: "11px",
                      border:
                        "1px solid #CBD5E1",
                      borderRadius: "7px",
                    }}
                  >
                    <option value="Open">
                      Open
                    </option>

                    <option value="In Progress">
                      In Progress
                    </option>

                    <option value="Closed">
                      Closed
                    </option>
                  </select>
                </div>
              </div>

              {/* DATE */}

              <div style={{ marginBottom: "20px" }}>
                <label
                  style={{
                    display: "block",
                    marginBottom: "6px",
                    fontWeight: "600",
                    fontSize: "13px",
                  }}
                >
                  Date *
                </label>

                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleChange}
                  required
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    padding: "11px",
                    border:
                      "1px solid #CBD5E1",
                    borderRadius: "7px",
                  }}
                />
              </div>

              {/* BUTTONS */}

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "10px",
                }}
              >
                <button
                  type="button"
                  onClick={closeModal}
                  style={{
                    background: "#E2E8F0",
                    color: "#334155",
                    border: "none",
                    padding: "10px 18px",
                    borderRadius: "7px",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: loading
                      ? "#94A3B8"
                      : "#4F46E5",
                    color: "#fff",
                    border: "none",
                    padding: "10px 20px",
                    borderRadius: "7px",
                    cursor: loading
                      ? "not-allowed"
                      : "pointer",
                    fontWeight: "600",
                  }}
                >
                  {loading
                    ? "Saving..."
                    : editingTicket
                    ? "Update Ticket"
                    : "Save Ticket"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================
          VIEW MODAL
      ========================= */}

      {viewTicket && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background:
              "rgba(15,23,42,.55)",
            zIndex: 99999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            padding: "20px",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: "480px",
              background: "#fff",
              borderRadius: "12px",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                background: "#4F46E5",
                color: "#fff",
                padding: "17px 20px",
                display: "flex",
                justifyContent:
                  "space-between",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  fontSize: "19px",
                }}
              >
                Ticket Details
              </h2>

              <button
                onClick={() =>
                  setViewTicket(null)
                }
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#fff",
                  cursor: "pointer",
                  fontSize: "18px",
                }}
              >
                <FaTimes />
              </button>
            </div>

            <div style={{ padding: "22px" }}>
              {[
                ["Ticket ID", viewTicket.id],
                [
                  "Customer",
                  viewTicket.customer,
                ],
                [
                  "Employee",
                  viewTicket.employee ||
                    viewTicket.assignedTo,
                ],
                ["Issue", viewTicket.issue],
                [
                  "Priority",
                  viewTicket.priority,
                ],
                ["Status", viewTicket.status],
                ["Date", viewTicket.date],
              ].map(([label, value]) => (
                <div
                  key={label}
                  style={{
                    display: "flex",
                    justifyContent:
                      "space-between",
                    gap: "20px",
                    padding: "11px 0",
                    borderBottom:
                      "1px solid #E2E8F0",
                  }}
                >
                  <strong
                    style={{
                      color: "#64748B",
                    }}
                  >
                    {label}
                  </strong>

                  <span
                    style={{
                      color: "#1E293B",
                      fontWeight: "600",
                      textAlign: "right",
                    }}
                  >
                    {value || "-"}
                  </span>
                </div>
              ))}

              <button
                onClick={() =>
                  setViewTicket(null)
                }
                style={{
                  width: "100%",
                  marginTop: "18px",
                  padding: "11px",
                  background: "#4F46E5",
                  color: "#fff",
                  border: "none",
                  borderRadius: "7px",
                  cursor: "pointer",
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TicketManagement;