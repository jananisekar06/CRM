
import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaLanguage,
  FaSave,
  FaCheckCircle,
} from "react-icons/fa";

function MultiLanguage() {
  const API_URL = "http://localhost:5000/api/languages";

  const [language, setLanguage] = useState("English");
  const [savedLanguage, setSavedLanguage] =
    useState("English");

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  // ===============================
  // GET LANGUAGE DATA
  // ===============================

  const fetchLanguageData = async () => {
    try {
      setLoading(true);

      const response = await axios.get(API_URL);

      const data = response.data;

      if (data.users) {
        setUsers(data.users);
      }

      if (data.currentLanguage) {
        setLanguage(data.currentLanguage);
        setSavedLanguage(data.currentLanguage);
      }
    } catch (error) {
      console.error(
        "Language fetch error:",
        error
      );

      // Fallback data
      setUsers([
        {
          id: 1,
          name: "John",
          language: "English",
          status: "Active",
        },
        {
          id: 2,
          name: "Priya",
          language: "Tamil",
          status: "Active",
        },
        {
          id: 3,
          name: "Rahul",
          language: "Hindi",
          status: "Active",
        },
        {
          id: 4,
          name: "David",
          language: "English",
          status: "Active",
        },
        {
          id: 5,
          name: "Sneha",
          language: "Tamil",
          status: "Active",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLanguageData();
  }, []);

  // ===============================
  // SAVE LANGUAGE
  // ===============================

  const handleSaveLanguage = async () => {
    try {
      setSaving(true);
      setMessage("");

      await axios.put(API_URL, {
        language,
      });

      setSavedLanguage(language);

      setMessage(
        `Language changed to ${language} successfully!`
      );
    } catch (error) {
      console.error(
        "Save language error:",
        error
      );

      // Even if backend is not available,
      // keep selection in frontend
      setSavedLanguage(language);

      setMessage(
        `Language changed to ${language}.`
      );
    } finally {
      setSaving(false);
    }
  };

  // ===============================
  // LANGUAGE COUNTS
  // ===============================

  const englishUsers = users.filter(
    (user) => user.language === "English"
  ).length;

  const tamilUsers = users.filter(
    (user) => user.language === "Tamil"
  ).length;

  const hindiUsers = users.filter(
    (user) => user.language === "Hindi"
  ).length;

  const uniqueLanguages = new Set(
    users.map((user) => user.language)
  ).size;

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
            paddingBottom: "60px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
              gap: "20px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Multi-language
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginBottom: 0,
                }}
              >
                Change CRM language preference
              </p>
            </div>

            <button
              onClick={handleSaveLanguage}
              disabled={saving}
              style={{
                background: saving
                  ? "#94A3B8"
                  : "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                cursor: saving
                  ? "not-allowed"
                  : "pointer",
                fontWeight: "600",
              }}
            >
              <FaSave />

              {saving
                ? "Saving..."
                : "Save Language"}
            </button>
          </div>

          {/* ================= LANGUAGE SELECTION ================= */}

          <div
            style={{
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              marginBottom: "30px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h3
              style={{
                marginTop: 0,
                marginBottom: "20px",
                color: "#334155",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaLanguage color="#4F46E5" />
              Select Language
            </h3>

            <select
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                setMessage("");
              }}
              style={{
                width: "300px",
                maxWidth: "100%",
                padding: "12px",
                borderRadius: "8px",
                border:
                  "1px solid #CBD5E1",
                fontSize: "16px",
                outline: "none",
                background: "#fff",
              }}
            >
              <option value="English">
                English
              </option>

              <option value="Tamil">
                Tamil
              </option>

              <option value="Hindi">
                Hindi
              </option>
            </select>

            <div
              style={{
                marginTop: "25px",
                padding: "15px",
                background: "#EEF2FF",
                borderRadius: "10px",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#4F46E5",
                  fontSize: "20px",
                }}
              >
                Current Language :{" "}
                {savedLanguage}
              </h2>
            </div>

            {message && (
              <div
                style={{
                  marginTop: "15px",
                  padding: "12px 15px",
                  background: "#DCFCE7",
                  color: "#166534",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <FaCheckCircle />
                {message}
              </div>
            )}
          </div>

          {/* ================= USER LANGUAGE TABLE ================= */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                minWidth: "650px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th
                    style={{
                      padding: "15px",
                    }}
                  >
                    ID
                  </th>

                  <th>User</th>

                  <th>Language</th>

                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="4"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      Loading users...
                    </td>
                  </tr>
                ) : users.length === 0 ? (
                  <tr>
                    <td
                      colSpan="4"
                      style={{
                        padding: "30px",
                        textAlign: "center",
                        color: "#64748B",
                      }}
                    >
                      No users found.
                    </td>
                  </tr>
                ) : (
                  users.map((user) => (
                    <tr
                      key={user.id}
                      style={{
                        textAlign: "center",
                        borderBottom:
                          "1px solid #E2E8F0",
                      }}
                    >
                      <td
                        style={{
                          padding: "15px",
                        }}
                      >
                        {user.id}
                      </td>

                      <td>{user.name}</td>

                      <td>
                        <span
                          style={{
                            background:
                              "#EEF2FF",
                            color: "#4F46E5",
                            padding:
                              "6px 12px",
                            borderRadius:
                              "20px",
                            fontSize: "13px",
                            fontWeight: "600",
                          }}
                        >
                          {user.language}
                        </span>
                      </td>

                      <td>
                        <span
                          style={{
                            background:
                              user.status ===
                              "Active"
                                ? "#22C55E"
                                : "#EF4444",
                            color: "#fff",
                            padding:
                              "5px 12px",
                            borderRadius:
                              "20px",
                            fontSize: "12px",
                          }}
                        >
                          {user.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* ================= SUMMARY CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, minmax(180px, 1fr))",
              gap: "20px",
              marginTop: "30px",
            }}
          >
            <div
              style={{
                background: "#EEF2FF",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Languages</h3>

              <h2
                style={{
                  color: "#4F46E5",
                }}
              >
                {uniqueLanguages}
              </h2>
            </div>

            <div
              style={{
                background: "#DCFCE7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>English Users</h3>

              <h2
                style={{
                  color: "#16A34A",
                }}
              >
                {englishUsers}
              </h2>
            </div>

            <div
              style={{
                background: "#FEF3C7",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Tamil Users</h3>

              <h2
                style={{
                  color: "#D97706",
                }}
              >
                {tamilUsers}
              </h2>
            </div>

            <div
              style={{
                background: "#DBEAFE",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <h3>Hindi Users</h3>

              <h2
                style={{
                  color: "#2563EB",
                }}
              >
                {hindiUsers}
              </h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MultiLanguage;