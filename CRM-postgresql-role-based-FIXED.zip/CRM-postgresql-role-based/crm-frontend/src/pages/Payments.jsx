import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaMoneyCheckAlt,
  FaSearch,
  FaPlus,
  FaCheckCircle,
  FaClock,
  FaExclamationCircle,
} from "react-icons/fa";

function Payments() {
  const [search, setSearch] = useState("");
const [payments, setPayments] = useState([]);
const [form, setForm] = useState({
  invoice: "",
  customer: "",
  amount: "",
  paymentDate: "",
  paymentMethod: "Cash",
  transactionId: "",
  status: "Paid",
  remarks: "",
});
const handleChange = (e) => {
  setForm({
    ...form,
    [e.target.name]: e.target.value,
  });
};
const handleSubmit = async () => {
  try {
    const response = await axios.post(
      "http://localhost:5000/api/payments",
      {
        invoice: form.invoice,
        customer: form.customer,
        amount: Number(form.amount),
        dueDate: form.paymentDate,
        paymentMethod: form.paymentMethod,
        transactionId: form.transactionId,
        status: form.status,
        remarks: form.remarks,
      }
    );

    alert(response.data.message);

    setForm({
      invoice: "",
      customer: "",
      amount: "",
      paymentDate: "",
      paymentMethod: "Cash",
      transactionId: "",
      status: "Paid",
      remarks: "",
    });

    fetchPayments();
  } catch (error) {
    console.error("Error adding payment:", error);
    alert("Failed to add payment");
  }
};
useEffect(() => {
  fetchPayments();
}, []);

const fetchPayments = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/payments"
    );

    setPayments(response.data);
  } catch (error) {
    console.error("Error fetching payments:", error);
  }
};
 
  const filteredPayments = payments.filter(
    (payment) =>
      payment.customer.toLowerCase().includes(search.toLowerCase()) ||
      payment.invoice.toLowerCase().includes(search.toLowerCase())
  );

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div style={{ padding: "30px" }}>

          {/* Header */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1 style={{ color: "#334155" }}>
                Payments
              </h1>

              <p style={{ color: "#64748B" }}>
                Track invoice payments and payment history.
              </p>
            </div>

            <button
              style={{
                background: "#4F46E5",
                color: "#fff",
                border: "none",
                padding: "12px 22px",
                borderRadius: "8px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <FaPlus />
              Add Payment
            </button>
          </div>

          {/* Dashboard Cards */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <FaCheckCircle size={30} color="#16A34A" />
              <h3>Paid</h3>
              <h2>₹8.5L</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaClock size={30} color="#D97706" />
              <h3>Pending</h3>
              <h2>₹2.1L</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <FaExclamationCircle size={30} color="#DC2626" />
              <h3>Overdue</h3>
              <h2>₹75K</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaMoneyCheckAlt size={30} color="#2563EB" />
              <h3>Total Revenue</h3>
              <h2>₹11.35L</h2>
            </div>
          </div>

          {/* Search */}

          <div
            style={{
              position: "relative",
              width: "350px",
              marginBottom: "25px",
            }}
          >
            <FaSearch
              style={{
                position: "absolute",
                top: "14px",
                left: "15px",
                color: "#64748B",
              }}
            />

            <input
              type="text"
              placeholder="Search Invoice..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: "100%",
                padding: "12px 15px 12px 45px",
                border: "1px solid #CBD5E1",
                borderRadius: "8px",
              }}
            />
          </div>

          {/* Payments Table */}

          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "15px" }}>Payment ID</th>
                  <th>Invoice</th>
                  <th>Customer</th>
                  <th>Amount</th>
                  <th>Due Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {filteredPayments.map((payment) => (
                  <tr
                    key={payment.id}
                    style={{
                      textAlign: "center",
                      borderBottom: "1px solid #E2E8F0",
                    }}
                  >
                    <td style={{ padding: "15px" }}>{payment.id}</td>
                    <td>{payment.invoice}</td>
                    <td>{payment.customer}</td>
                    <td>{payment.amount}</td>
                    <td>{payment.dueDate}</td>

                    <td>
                      <span
                        style={{
                          background:
                            payment.status === "Paid"
                              ? "#22C55E"
                              : payment.status === "Pending"
                              ? "#F59E0B"
                              : "#EF4444",
                          color: "#fff",
                          padding: "5px 12px",
                          borderRadius: "20px",
                        }}
                      >
                        {payment.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
                    {/* Add Payment Form */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155", marginBottom: "20px" }}>
              Add Payment
            </h2>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2,1fr)",
                gap: "20px",
              }}
            >
              <div>
                <label>Invoice Number</label>
                <input
  type="text"
  name="invoice"
  placeholder="INV001"
  value={form.invoice}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>

              <div>
                <label>Customer Name</label>
               <input
  type="text"
  name="customer"
  placeholder="ABC Company"
  value={form.customer}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>

              <div>
                <label>Payment Amount</label>
                <input
  type="number"
  name="amount"
  placeholder="25000"
  value={form.amount}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>

              <div>
                <label>Payment Date</label>
              <input
  type="date"
  name="paymentDate"
  value={form.paymentDate}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>

              <div>
                <label>Payment Method</label>
               <select
  name="paymentMethod"
  value={form.paymentMethod}
  onChange={handleChange}
  style={inputStyle}
>
  <option>Cash</option>
  <option>UPI</option>
  <option>Credit Card</option>
  <option>Debit Card</option>
  <option>Net Banking</option>
  <option>Bank Transfer</option>
</select>
              </div>

              <div>
                <label>Transaction ID</label>
               <input
  type="text"
  name="transactionId"
  placeholder="TXN123456789"
  value={form.transactionId}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>

              <div>
                <label>Status</label>
                <select
  name="status"
  value={form.status}
  onChange={handleChange}
  style={inputStyle}
>
  <option>Paid</option>
  <option>Pending</option>
  <option>Overdue</option>
</select>
              </div>

              <div>
                <label>Remarks</label>
               <input
  type="text"
  name="remarks"
  placeholder="Optional remarks"
  value={form.remarks}
  onChange={handleChange}
  style={inputStyle}
/>
              </div>
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: "15px",
                marginTop: "25px",
              }}
            >
              <button
  onClick={() =>
    setForm({
      invoice: "",
      customer: "",
      amount: "",
      paymentDate: "",
      paymentMethod: "Cash",
      transactionId: "",
      status: "Paid",
      remarks: "",
    })
  }
  style={{
    background: "#E5E7EB",
    color: "#334155",
    border: "none",
    padding: "12px 25px",
    borderRadius: "8px",
    cursor: "pointer",
  }}
>
  Reset
</button>

             <button
  onClick={handleSubmit}
  style={{
    background: "#4F46E5",
    color: "#fff",
    border: "none",
    padding: "12px 25px",
    borderRadius: "8px",
    cursor: "pointer",
  }}
>
  Save Payment
</button>
            </div>
          </div>

          {/* Payment Statistics */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns: "repeat(4,1fr)",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Today's Collection</h3>
              <h2>₹85,000</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Monthly Revenue</h3>
              <h2>₹11.35L</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Pending Amount</h3>
              <h2>₹2.10L</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Overdue Amount</h3>
              <h2>₹75K</h2>
            </div>
          </div>

          {/* Payment History */}

          <div
            style={{
              marginTop: "35px",
              background: "#fff",
              padding: "25px",
              borderRadius: "15px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2 style={{ color: "#334155" }}>
              Recent Payment History
            </h2>

            <table
              style={{
                width: "100%",
                marginTop: "20px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#fff",
                }}
              >
                <tr>
                  <th style={{ padding: "12px" }}>Invoice</th>
                  <th>Customer</th>
                  <th>Payment Method</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "12px" }}>INV001</td>
                  <td>ABC Company</td>
                  <td>UPI</td>
                  <td>₹25,000</td>
                  <td>
                    <span
                      style={{
                        background: "#22C55E",
                        color: "#fff",
                        padding: "5px 12px",
                        borderRadius: "20px",
                      }}
                    >
                      Paid
                    </span>
                  </td>
                </tr>

                <tr style={{ textAlign: "center" }}>
                  <td style={{ padding: "12px" }}>INV002</td>
                  <td>XYZ Pvt Ltd</td>
                  <td>Bank Transfer</td>
                  <td>₹15,500</td>
                  <td>
                    <span
                      style={{
                        background: "#F59E0B",
                        color: "#fff",
                        padding: "5px 12px",
                        borderRadius: "20px",
                      }}
                    >
                      Pending
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

export default Payments;