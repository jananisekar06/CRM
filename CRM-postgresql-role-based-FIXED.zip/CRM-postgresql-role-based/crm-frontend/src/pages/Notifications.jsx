import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaBell,
  FaCheckCircle,
  FaExclamationCircle,
  FaInfoCircle,
  FaTimes,
} from "react-icons/fa";

function Notifications() {
  const [notifications, setNotifications] = useState([]);
  useEffect(() => {
  axios
    .get("http://localhost:5000/api/notifications")
    .then((response) => {
      setNotifications(response.data);
    })
    .catch((error) => {
      console.error("Error fetching notifications:", error);
    });
}, []);
  const [form, setForm] = useState({
    title: "",
    message: "",
    time: "",
    type: "info",
  });

  const [showForm, setShowForm] = useState(false);
 const handleChange = (e) => {
  setForm({
    ...form,
    [e.target.name]: e.target.value,
  });
}; 
  const handleSubmit = async (e) => {
  e.preventDefault();

  if (
    !form.title.trim() ||
    !form.message.trim() ||
    !form.time.trim()
  ) {
    alert("Please fill all fields");
    return;
  }

  try {
    const response = await axios.post(
      "http://localhost:5000/api/notifications",
      form
    );

    setNotifications([
      ...notifications,
      response.data.notification,
    ]);

    alert("Notification Added Successfully");

    setForm({
      title: "",
      message: "",
      time: "",
      type: "info",
    });

    setShowForm(false);
  } catch (error) {
    console.error("Error adding notification:", error);
    alert("Failed to add notification");
  }
};
  const getIcon = (type) => {
    if (type === "success") {
      return <FaCheckCircle size={24} color="#22C55E" />;
    }

    if (type === "warning") {
      return (
        <FaExclamationCircle
          size={24}
          color="#F59E0B"
        />
      );
    }

    return <FaInfoCircle size={24} color="#0EA5E9" />;
  };

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <main style={{ padding: "30px" }}>
          {/* Header */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#1E293B",
                }}
              >
                Notifications
              </h1>

              <p
                style={{
                  color: "#64748B",
                  marginBottom: 0,
                }}
              >
                View your latest notifications
              </p>
            </div>
<div
  style={{
    display: "flex",
    alignItems: "center",
    gap: "15px",
  }}
>
  <button
    onClick={() => setShowForm(true)}
    style={{
      background: "#4F46E5",
      color: "#fff",
      border: "none",
      padding: "12px 20px",
      borderRadius: "8px",
      cursor: "pointer",
    }}
  >
    Add Notification
  </button>

  <div
    style={{
      width: "50px",
      height: "50px",
      borderRadius: "50%",
      background: "#EEF2FF",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    <FaBell size={22} color="#4F46E5" />
  </div>
</div>
          </div>
{showForm && (
  <div
    style={{
      background: "#FFFFFF",
      padding: "25px",
      borderRadius: "15px",
      marginBottom: "25px",
      boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
    }}
  >
    <h2 style={{ color: "#1E293B", marginTop: 0 }}>
      Add Notification
    </h2>

    <form onSubmit={handleSubmit}>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "20px",
        }}
      >
        <div>
          <label>Title</label>
          <input
            type="text"
            name="title"
            value={form.title}
            onChange={handleChange}
            placeholder="New Customer Added"
            style={{
              width: "100%",
              padding: "12px",
              marginTop: "8px",
              border: "1px solid #CBD5E1",
              borderRadius: "8px",
              boxSizing: "border-box",
            }}
          />
        </div>

        <div>
          <label>Time</label>
          <input
            type="text"
            name="time"
            value={form.time}
            onChange={handleChange}
            placeholder="10 minutes ago"
            style={{
              width: "100%",
              padding: "12px",
              marginTop: "8px",
              border: "1px solid #CBD5E1",
              borderRadius: "8px",
              boxSizing: "border-box",
            }}
          />
        </div>

        <div style={{ gridColumn: "1 / -1" }}>
          <label>Message</label>
          <textarea
            name="message"
            value={form.message}
            onChange={handleChange}
            placeholder="Enter notification message"
            rows="3"
            style={{
              width: "100%",
              padding: "12px",
              marginTop: "8px",
              border: "1px solid #CBD5E1",
              borderRadius: "8px",
              boxSizing: "border-box",
              resize: "vertical",
            }}
          />
        </div>

        <div>
          <label>Type</label>
          <select
            name="type"
            value={form.type}
            onChange={handleChange}
            style={{
              width: "100%",
              padding: "12px",
              marginTop: "8px",
              border: "1px solid #CBD5E1",
              borderRadius: "8px",
            }}
          >
            <option value="info">Info</option>
            <option value="success">Success</option>
            <option value="warning">Warning</option>
          </select>
        </div>
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          gap: "10px",
          marginTop: "20px",
        }}
      >
        <button
          type="button"
          onClick={() => {
            setShowForm(false);
            setForm({
              title: "",
              message: "",
              time: "",
              type: "info",
            });
          }}
          style={{
            background: "#64748B",
            color: "#fff",
            border: "none",
            padding: "10px 20px",
            borderRadius: "7px",
            cursor: "pointer",
          }}
        >
          Cancel
        </button>

        <button
          type="submit"
          style={{
            background: "#4F46E5",
            color: "#fff",
            border: "none",
            padding: "10px 20px",
            borderRadius: "7px",
            cursor: "pointer",
          }}
        >
          Save Notification
        </button>
      </div>
    </form>
  </div>
)}
          {/* Notification List */}
          <div
            style={{
              background: "#FFFFFF",
              borderRadius: "15px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,0.06)",
            }}
          >
            {notifications.map((notification) => (
              <div
                key={notification.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "18px",
                  padding: "20px",
                  borderBottom: "1px solid #E2E8F0",
                }}
              >
                {/* Icon */}
                <div
                  style={{
                    width: "45px",
                    height: "45px",
                    borderRadius: "50%",
                    background: "#F8FAFC",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  {getIcon(notification.type)}
                </div>

                {/* Content */}
                <div style={{ flex: 1 }}>
                  <h3
                    style={{
                      margin: 0,
                      color: "#1E293B",
                      fontSize: "16px",
                    }}
                  >
                    {notification.title}
                  </h3>

                  <p
                    style={{
                      margin: "6px 0",
                      color: "#64748B",
                    }}
                  >
                    {notification.message}
                  </p>

                  <small
                    style={{
                      color: "#94A3B8",
                    }}
                  >
                    {notification.time}
                  </small>
                </div>

                {/* Close */}
               <button
  onClick={async () => {
    try {
      await axios.delete(
        `http://localhost:5000/api/notifications/${notification.id}`
      );

      setNotifications((prev) =>
        prev.filter(
          (item) => item.id !== notification.id
        )
      );

      alert("Notification dismissed");
    } catch (error) {
      console.error("Delete Error:", error);
      alert("Failed to delete notification");
    }
  }}
  style={{
    border: "none",
    background: "transparent",
    cursor: "pointer",
    color: "#94A3B8",
  }}
>
  <FaTimes />
</button>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Notifications;