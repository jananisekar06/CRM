
import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaBuilding,
  FaUsers,
  FaUserShield,
  FaSearch,
  FaPlus,
  FaDatabase,
  FaEdit,
  FaTrash,
  FaTimes,
} from "react-icons/fa";

function MultiCompany() {
  const API_URL = "http://localhost:5000/api/companies";

  const [companies, setCompanies] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    name: "",
    admin: "",
    email: "",
    employees: "",
    plan: "Basic",
    status: "Active",
  });

  // ===============================
  // GET COMPANIES
  // ===============================

  const fetchCompanies = async () => {
    try {
      setLoading(true);

      const response = await axios.get(API_URL);

      setCompanies(response.data.companies || []);
    } catch (error) {
      console.error("Error fetching companies:", error);
      alert("Unable to load companies. Please check backend server.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  // ===============================
  // FORM CHANGE
  // ===============================

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  // ===============================
  // RESET FORM
  // ===============================

  const resetForm = () => {
    setForm({
      name: "",
      admin: "",
      email: "",
      employees: "",
      plan: "Basic",
      status: "Active",
    });

    setEditingId(null);
    setShowForm(false);
  };

  // ===============================
  // CREATE / UPDATE
  // ===============================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.name || !form.admin || !form.email) {
      alert("Please fill Company Name, Admin and Email.");
      return;
    }

    try {
      if (editingId) {
        await axios.put(`${API_URL}/${editingId}`, form);

        alert("Company updated successfully!");
      } else {
        await axios.post(API_URL, form);

        alert("Company created successfully!");
      }

      resetForm();
      fetchCompanies();
    } catch (error) {
      console.error("Save company error:", error);

      alert(
        error.response?.data?.message ||
          "Unable to save company."
      );
    }
  };

  // ===============================
  // EDIT
  // ===============================

  const handleEdit = (company) => {
    setEditingId(company.id);

    setForm({
      name: company.name || "",
      admin: company.admin || "",
      email: company.email || "",
      employees: company.employees || "",
      plan: company.plan || "Basic",
      status: company.status || "Active",
    });

    setShowForm(true);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  // ===============================
  // DELETE
  // ===============================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this company?"
    );

    if (!confirmDelete) return;

    try {
      await axios.delete(`${API_URL}/${id}`);

      alert("Company deleted successfully!");

      fetchCompanies();
    } catch (error) {
      console.error("Delete company error:", error);

      alert(
        error.response?.data?.message ||
          "Unable to delete company."
      );
    }
  };

  // ===============================
  // SEARCH
  // ===============================

  const filteredCompanies = companies.filter((company) =>
    `${company.name} ${company.admin} ${company.email}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // ===============================
  // STATISTICS
  // ===============================

  const totalCompanies = companies.length;

  const totalEmployees = companies.reduce(
    (total, company) =>
      total + Number(company.employees || 0),
    0
  );

  const activeCompanies = companies.filter(
    (company) => company.status === "Active"
  ).length;

  const premiumCompanies = companies.filter(
    (company) => company.plan === "Premium"
  ).length;

  const adminCount = companies.filter(
    (company) => company.admin
  ).length;

  return (
     <div
  style={{
    marginLeft: "260px",
    minHeight: "100vh",
  }}
>
      <Sidebar />

      <div style={{ flex: 1 }}>
        <Navbar />

        <div
          style={{
            padding: "30px",
            paddingBottom: "60px",
          }}
        >
          {/* ================= HEADER ================= */}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "25px",
            }}
          >
            <div>
              <h1
                style={{
                  margin: 0,
                  color: "#334155",
                }}
              >
                Multi Company
              </h1>

              <p style={{ color: "#64748B" }}>
                Manage multiple companies with complete
                tenant isolation.
              </p>
            </div>

            <button
              onClick={() => {
                resetForm();
                setShowForm(true);

                window.scrollTo({
                  top: 0,
                  behavior: "smooth",
                });
              }}
              style={primaryButton}
            >
              <FaPlus />
              Create Company
            </button>
          </div>

          {/* ================= CARDS ================= */}

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(4, minmax(180px, 1fr))",
              gap: "20px",
              marginBottom: "30px",
            }}
          >
            <div style={card("#EEF2FF")}>
              <FaBuilding
                size={30}
                color="#4F46E5"
              />
              <h3>Total Companies</h3>
              <h2>{totalCompanies}</h2>
            </div>

            <div style={card("#DCFCE7")}>
              <FaUserShield
                size={30}
                color="#16A34A"
              />
              <h3>Company Admins</h3>
              <h2>{adminCount}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <FaUsers
                size={30}
                color="#2563EB"
              />
              <h3>Total Employees</h3>
              <h2>{totalEmployees}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <FaDatabase
                size={30}
                color="#D97706"
              />
              <h3>Active Companies</h3>
              <h2>{activeCompanies}</h2>
            </div>
          </div>

          {/* ================= CREATE / EDIT FORM ================= */}

          {showForm && (
            <div
              style={{
                background: "#FFFFFF",
                padding: "25px",
                borderRadius: "15px",
                marginBottom: "30px",
                boxShadow:
                  "0 5px 15px rgba(0,0,0,.08)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "20px",
                }}
              >
                <h2
                  style={{
                    margin: 0,
                    color: "#334155",
                  }}
                >
                  {editingId
                    ? "Edit Company"
                    : "Create New Company"}
                </h2>

                <button
                  onClick={resetForm}
                  style={{
                    border: "none",
                    background: "#FEE2E2",
                    color: "#DC2626",
                    padding: "9px 12px",
                    borderRadius: "7px",
                    cursor: "pointer",
                  }}
                >
                  <FaTimes />
                </button>
              </div>

              <form onSubmit={handleSubmit}>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(2, minmax(250px, 1fr))",
                    gap: "20px",
                  }}
                >
                  <div>
                    <label style={labelStyle}>
                      Company Name *
                    </label>

                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Enter Company Name"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>
                      Company Admin *
                    </label>

                    <input
                      type="text"
                      name="admin"
                      value={form.admin}
                      onChange={handleChange}
                      placeholder="Admin Name"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>
                      Email *
                    </label>

                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="company@email.com"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>
                      Employees
                    </label>

                    <input
                      type="number"
                      name="employees"
                      value={form.employees}
                      onChange={handleChange}
                      placeholder="0"
                      min="0"
                      style={inputStyle}
                    />
                  </div>

                  <div>
                    <label style={labelStyle}>
                      Subscription Plan
                    </label>

                    <select
                      name="plan"
                      value={form.plan}
                      onChange={handleChange}
                      style={inputStyle}
                    >
                      <option>Basic</option>
                      <option>Standard</option>
                      <option>Premium</option>
                      <option>Enterprise</option>
                    </select>
                  </div>

                  <div>
                    <label style={labelStyle}>
                      Status
                    </label>

                    <select
                      name="status"
                      value={form.status}
                      onChange={handleChange}
                      style={inputStyle}
                    >
                      <option>Active</option>
                      <option>Inactive</option>
                    </select>
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "12px",
                    marginTop: "25px",
                  }}
                >
                  <button
                    type="button"
                    onClick={resetForm}
                    style={cancelButton}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    style={primaryButton}
                  >
                    <FaPlus />
                    {editingId
                      ? "Update Company"
                      : "Create Company"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ================= SEARCH ================= */}

          <div
            style={{
              background: "#FFFFFF",
              padding: "20px",
              borderRadius: "12px",
              marginBottom: "25px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.06)",
            }}
          >
            <div
              style={{
                position: "relative",
                width: "350px",
                maxWidth: "100%",
              }}
            >
              <FaSearch
                style={{
                  position: "absolute",
                  top: "14px",
                  left: "15px",
                  color: "#64748B",
                }}
              />

              <input
                type="text"
                placeholder="Search Company or Admin..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                style={{
                  width: "100%",
                  padding:
                    "12px 15px 12px 45px",
                  border:
                    "1px solid #CBD5E1",
                  borderRadius: "8px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>

          {/* ================= COMPANY TABLE ================= */}

          <div
            style={{
              background: "#FFFFFF",
              borderRadius: "15px",
              overflowX: "auto",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <table
              style={{
                width: "100%",
                minWidth: "900px",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  background: "#4F46E5",
                  color: "#FFFFFF",
                }}
              >
                <tr>
                  <th style={thStyle}>
                    Company ID
                  </th>

                  <th style={thStyle}>
                    Company Name
                  </th>

                  <th style={thStyle}>
                    Admin
                  </th>

                  <th style={thStyle}>
                    Employees
                  </th>

                  <th style={thStyle}>
                    Plan
                  </th>

                  <th style={thStyle}>
                    Status
                  </th>

                  <th style={thStyle}>
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={emptyStyle}
                    >
                      Loading companies...
                    </td>
                  </tr>
                ) : filteredCompanies.length === 0 ? (
                  <tr>
                    <td
                      colSpan="7"
                      style={emptyStyle}
                    >
                      No companies found.
                    </td>
                  </tr>
                ) : (
                  filteredCompanies.map(
                    (company) => (
                      <tr
                        key={company.id}
                        style={{
                          textAlign: "center",
                          borderBottom:
                            "1px solid #E2E8F0",
                        }}
                      >
                        <td style={tdStyle}>
                          {company.id}
                        </td>

                        <td style={tdStyle}>
                          <strong>
                            {company.name}
                          </strong>
                        </td>

                        <td style={tdStyle}>
                          {company.admin}
                        </td>

                        <td style={tdStyle}>
                          {company.employees}
                        </td>

                        <td style={tdStyle}>
                          <span
                            style={{
                              background:
                                company.plan ===
                                "Premium"
                                  ? "#8B5CF6"
                                  : company.plan ===
                                    "Standard"
                                  ? "#3B82F6"
                                  : "#64748B",
                              color: "#FFFFFF",
                              padding:
                                "5px 12px",
                              borderRadius:
                                "20px",
                              fontSize:
                                "12px",
                            }}
                          >
                            {company.plan}
                          </span>
                        </td>

                        <td style={tdStyle}>
                          <span
                            style={{
                              background:
                                company.status ===
                                "Active"
                                  ? "#22C55E"
                                  : "#EF4444",
                              color: "#FFFFFF",
                              padding:
                                "5px 12px",
                              borderRadius:
                                "20px",
                              fontSize:
                                "12px",
                            }}
                          >
                            {company.status}
                          </span>
                        </td>

                        <td style={tdStyle}>
                          <button
                            onClick={() =>
                              handleEdit(
                                company
                              )
                            }
                            style={editButton}
                            title="Edit"
                          >
                            <FaEdit />
                          </button>

                          <button
                            onClick={() =>
                              handleDelete(
                                company.id
                              )
                            }
                            style={
                              deleteButton
                            }
                            title="Delete"
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    )
                  )
                )}
              </tbody>
            </table>
          </div>

          {/* ================= STATISTICS ================= */}

          <div
            style={{
              marginTop: "35px",
              display: "grid",
              gridTemplateColumns:
                "repeat(4, minmax(180px, 1fr))",
              gap: "20px",
            }}
          >
            <div style={card("#DCFCE7")}>
              <h3>Active Companies</h3>
              <h2>{activeCompanies}</h2>
            </div>

            <div style={card("#DBEAFE")}>
              <h3>Total Employees</h3>
              <h2>{totalEmployees}</h2>
            </div>

            <div style={card("#FEF3C7")}>
              <h3>Premium Plans</h3>
              <h2>{premiumCompanies}</h2>
            </div>

            <div style={card("#FEE2E2")}>
              <h3>Inactive</h3>
              <h2>
                {totalCompanies -
                  activeCompanies}
              </h2>
            </div>
          </div>

          {/* ================= ACTIVITY LOG ================= */}

          <div
            style={{
              marginTop: "35px",
              background: "#FFFFFF",
              padding: "25px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h2
              style={{
                color: "#334155",
                marginTop: 0,
              }}
            >
              Company Activity Log
            </h2>

            <p
              style={{
                color: "#64748B",
              }}
            >
              Company create, update and delete
              activities will be displayed here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===============================
// STYLES
// ===============================

const card = (bg) => ({
  background: bg,
  padding: "20px",
  borderRadius: "12px",
});

const primaryButton = {
  background: "#4F46E5",
  color: "#FFFFFF",
  border: "none",
  padding: "12px 22px",
  borderRadius: "8px",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  gap: "10px",
  fontWeight: "600",
};

const cancelButton = {
  background: "#E5E7EB",
  color: "#334155",
  border: "none",
  padding: "12px 22px",
  borderRadius: "8px",
  cursor: "pointer",
};

const editButton = {
  background: "#F59E0B",
  color: "#FFFFFF",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  marginRight: "7px",
  cursor: "pointer",
};

const deleteButton = {
  background: "#EF4444",
  color: "#FFFFFF",
  border: "none",
  padding: "8px 10px",
  borderRadius: "6px",
  cursor: "pointer",
};

const labelStyle = {
  display: "block",
  color: "#334155",
  fontWeight: "600",
  marginBottom: "6px",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  border: "1px solid #CBD5E1",
  borderRadius: "8px",
  outline: "none",
  boxSizing: "border-box",
};

const thStyle = {
  padding: "15px",
};

const tdStyle = {
  padding: "15px",
};

const emptyStyle = {
  padding: "30px",
  textAlign: "center",
  color: "#64748B",
};

export default MultiCompany;
