import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { getDefaultRoute } from "../config/rolePermissions";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  // Demo users. redirect is no longer hardcoded here - it always
  // comes from rolePermissions.js so the login redirect and the
  // page-access rules can never go out of sync.
  const users = [
    {
      id: 1,
      name: "Super Admin",
      email: "superadmin@gmail.com",
      password: "super123",
      role: "Super Admin",
    },
    {
      id: 2,
      name: "Admin",
      email: "admin@gmail.com",
      password: "admin123",
      role: "Admin",
    },
    {
      id: 3,
      name: "Sales Manager",
      email: "salesmanager@gmail.com",
      password: "sales123",
      role: "Sales Manager",
    },
    {
      id: 4,
      name: "Sales Executive",
      email: "salesexecutive@gmail.com",
      password: "sales123",
      role: "Sales Executive",
    },
    {
      id: 5,
      name: "HR",
      email: "hr@gmail.com",
      password: "hr123",
      role: "HR",
    },
    {
      id: 6,
      name: "Support",
      email: "support@gmail.com",
      password: "support123",
      role: "Support",
    },
    {
      id: 7,
      name: "Customer",
      email: "customer@gmail.com",
      password: "customer123",
      role: "Customer",
    },
  ];

  const handleLogin = (e) => {
    e.preventDefault();

    const user = users.find(
      (item) =>
        item.email.toLowerCase() === email.toLowerCase() &&
        item.password === password &&
        item.role === role
    );

    if (user) {
      // Save login information
      localStorage.setItem("token", "sample_jwt_token");

      localStorage.setItem("role", user.role);

      localStorage.setItem("email", user.email);

      // Important for ProtectedRoute
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        })
      );

      alert(`Login Successful!\nWelcome ${user.name}`);

      // Redirect based on role - every role only sees the pages
      // it is allowed to, defined in src/config/rolePermissions.js
      navigate(getDefaultRoute(user.role));
    } else {
      alert("Invalid Email, Password or Role");
    }
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        background: "#EEF2FF",
        padding: "20px",
        boxSizing: "border-box",
      }}
    >
      <form
        onSubmit={handleLogin}
        style={{
          width: "420px",
          maxWidth: "100%",
          background: "#fff",
          padding: "40px",
          borderRadius: "15px",
          boxShadow: "0 5px 20px rgba(0,0,0,.12)",
          boxSizing: "border-box",
        }}
      >
        <h1
          style={{
            textAlign: "center",
            color: "#4F46E5",
            marginBottom: "10px",
          }}
        >
          CRM Login
        </h1>

        <p
          style={{
            textAlign: "center",
            color: "#64748B",
            marginBottom: "25px",
          }}
        >
          Login to your CRM account
        </p>

        {/* Email */}

        <label
          style={{
            display: "block",
            color: "#334155",
            fontWeight: "500",
          }}
        >
          Email Address
        </label>

        <input
          type="email"
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={inputStyle}
        />

        {/* Password */}

        <label
          style={{
            display: "block",
            marginTop: "18px",
            color: "#334155",
            fontWeight: "500",
          }}
        >
          Password
        </label>

        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={inputStyle}
        />

        {/* Role */}

        <label
          style={{
            display: "block",
            marginTop: "18px",
            color: "#334155",
            fontWeight: "500",
          }}
        >
          Select Role
        </label>

        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
          style={inputStyle}
        >
          <option value="">Select your role</option>

          <option value="Super Admin">
            Super Admin
          </option>

          <option value="Admin">
            Admin
          </option>

          <option value="Sales Manager">
            Sales Manager
          </option>

          <option value="Sales Executive">
            Sales Executive
          </option>

          <option value="HR">
            HR
          </option>

          <option value="Support">
            Support
          </option>

          <option value="Customer">
            Customer
          </option>
        </select>

        {/* Login Button */}

        <button
          type="submit"
          style={{
            width: "100%",
            marginTop: "25px",
            padding: "13px",
            background: "#4F46E5",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
            fontSize: "16px",
            fontWeight: "600",
          }}
        >
          Login
        </button>

        {/* Links */}

        <div
          style={{
            marginTop: "20px",
            textAlign: "center",
          }}
        >
          <Link to="/forgot-password">
            Forgot Password?
          </Link>

          <br />
          <br />

          <Link to="/register">
            Create Account
          </Link>
        </div>
      </form>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "8px",
  borderRadius: "8px",
  border: "1px solid #CBD5E1",
  outline: "none",
  boxSizing: "border-box",
  fontSize: "14px",
};

export default Login;