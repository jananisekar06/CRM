import { useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import {
  FaRobot,
  FaPaperPlane,
  FaSpinner,
  FaTrash,
} from "react-icons/fa";

function AIAssistant() {
  const API_URL =
    "http://localhost:5000/api/ai-assistant/ask";

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

const handleAsk = async () => {
  if (!question.trim()) {
    setError("Please enter a question.");
    setAnswer("");
    return;
  }

  try {
    setLoading(true);
    setError("");
    setAnswer("");

    const response = await axios.post(API_URL, {
      question: question.trim(),
    });

    console.log("AI RESPONSE:", response.data);

    if (response.data.success) {
      setAnswer(response.data.answer || "No answer received.");
    } else {
      setError(
        response.data.message || "Unable to get AI response."
      );
    }
  } catch (err) {
    console.error("AI Assistant Error:", err);

    setError(
      err.response?.data?.message ||
        "Unable to connect to AI Assistant backend."
    );
  } finally {
    setLoading(false);
  }
};

  const handleClear = () => {
    setQuestion("");
    setAnswer("");
    setError("");
  };

  const handleSuggestedQuestion = (text) => {
    setQuestion(text);
    setError("");
    setAnswer("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  // AI-style suggested questions
  const suggestedQuestions = [
    "Analyze my customer data and identify important trends.",
    "Write a professional follow-up email for a potential customer.",
    "Which leads should I prioritize for follow-up?",
    "Suggest ways to improve customer satisfaction.",
    "Summarize my sales performance and highlight key insights.",
    "What can I do to improve my business performance?",
  ];

  return (
    <div
      style={{
        marginLeft: "260px",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <Navbar />

        <div
          style={{
            padding: "30px",
            paddingBottom: "60px",
          }}
        >
          {/* Header */}
          <div
            style={{
              marginBottom: "25px",
            }}
          >
            <h1
              style={{
                margin: 0,
                color: "#334155",
              }}
            >
              AI Assistant
            </h1>

            <p
              style={{
                color: "#64748B",
              }}
            >
              Ask anything and get intelligent insights
            </p>
          </div>

          {/* Chat Box */}
          <div
            style={{
              background: "#fff",
              borderRadius: "15px",
              padding: "30px",
              boxShadow: "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            {/* Assistant Header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "15px",
                marginBottom: "25px",
              }}
            >
              <div
                style={{
                  width: "55px",
                  height: "55px",
                  borderRadius: "50%",
                  background: "#EEF2FF",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FaRobot
                  size={30}
                  color="#4F46E5"
                />
              </div>

              <div>
                <h2
                  style={{
                    margin: 0,
                    color: "#334155",
                  }}
                >
                  AI Business Assistant
                </h2>

                <p
                  style={{
                    margin: "5px 0 0",
                    color: "#16A34A",
                    fontSize: "14px",
                  }}
                >
                  ● Online
                </p>
              </div>
            </div>

            {/* Question */}
            <textarea
              rows="4"
              placeholder="Ask your question..."
              value={question}
              onChange={(e) => {
                setQuestion(e.target.value);
                setError("");
              }}
              onKeyDown={handleKeyDown}
              disabled={loading}
              style={{
                width: "100%",
                padding: "15px",
                borderRadius: "10px",
                border: "1px solid #CBD5E1",
                resize: "none",
                fontSize: "15px",
                outline: "none",
                boxSizing: "border-box",
                background: loading
                  ? "#F8FAFC"
                  : "#fff",
              }}
            />

            <p
              style={{
                margin: "8px 0 0",
                color: "#94A3B8",
                fontSize: "12px",
              }}
            >
              Press Enter to ask. Use Shift + Enter for a new line.
            </p>

            {/* Buttons */}
            <div
              style={{
                display: "flex",
                gap: "12px",
                marginTop: "20px",
              }}
            >
              <button
                onClick={handleAsk}
                disabled={loading}
                style={{
                  background: loading
                    ? "#94A3B8"
                    : "#4F46E5",
                  color: "#fff",
                  border: "none",
                  padding: "12px 25px",
                  borderRadius: "8px",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontWeight: "600",
                }}
              >
                {loading ? (
                  <>
                    <FaSpinner
                      style={{
                        animation:
                          "spin 1s linear infinite",
                      }}
                    />
                    Thinking...
                  </>
                ) : (
                  <>
                    <FaPaperPlane />
                    Ask AI
                  </>
                )}
              </button>

              <button
                onClick={handleClear}
                disabled={loading}
                style={{
                  background: "#E2E8F0",
                  color: "#334155",
                  border: "none",
                  padding: "12px 20px",
                  borderRadius: "8px",
                  cursor: loading
                    ? "not-allowed"
                    : "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <FaTrash />
                Clear
              </button>
            </div>

            {/* Error */}
            {error && (
              <div
                style={{
                  marginTop: "20px",
                  background: "#FEE2E2",
                  color: "#991B1B",
                  padding: "15px",
                  borderRadius: "10px",
                  border: "1px solid #FCA5A5",
                }}
              >
                {error}
              </div>
            )}

            {/* AI Response */}
            {answer && (
              <div
                style={{
                  marginTop: "30px",
                  background: "#EEF2FF",
                  padding: "20px",
                  borderRadius: "10px",
                  borderLeft: "4px solid #4F46E5",
                  whiteSpace: "pre-line",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    marginBottom: "10px",
                  }}
                >
                  <FaRobot
                    color="#4F46E5"
                    size={20}
                  />

                  <h3
                    style={{
                      color: "#4F46E5",
                      margin: 0,
                    }}
                  >
                    AI Response
                  </h3>
                </div>

                <p
                  style={{
                    color: "#334155",
                    lineHeight: "28px",
                    margin: 0,
                  }}
                >
                  {answer}
                </p>
              </div>
            )}
          </div>

          {/* Suggested Questions */}
          <div
            style={{
              marginTop: "30px",
              background: "#fff",
              padding: "20px",
              borderRadius: "15px",
              boxShadow:
                "0 5px 15px rgba(0,0,0,.08)",
            }}
          >
            <h3
              style={{
                color: "#334155",
                marginTop: 0,
              }}
            >
              Try asking AI
            </h3>

            <p
              style={{
                color: "#64748B",
                fontSize: "14px",
                marginBottom: "15px",
              }}
            >
              Explore insights, recommendations, and business assistance.
            </p>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(2, 1fr)",
                gap: "12px",
              }}
            >
              {suggestedQuestions.map(
                (item, index) => (
                  <button
                    key={index}
                    onClick={() =>
                      handleSuggestedQuestion(item)
                    }
                    style={{
                      textAlign: "left",
                      background: "#F8FAFC",
                      border:
                        "1px solid #E2E8F0",
                      padding: "14px",
                      borderRadius: "8px",
                      cursor: "pointer",
                      color: "#334155",
                      transition:
                        "all 0.2s ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background =
                        "#EEF2FF";
                      e.currentTarget.style.borderColor =
                        "#C7D2FE";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background =
                        "#F8FAFC";
                      e.currentTarget.style.borderColor =
                        "#E2E8F0";
                    }}
                  >
                    🤖 {item}
                  </button>
                )
              )}
            </div>
          </div>
        </div>
      </div>

      <style>
        {`
          @keyframes spin {
            from {
              transform: rotate(0deg);
            }

            to {
              transform: rotate(360deg);
            }
          }

          @media (max-width: 768px) {
            .ai-assistant-grid {
              grid-template-columns: 1fr;
            }
          }
        `}
      </style>
    </div>
  );
}

export default AIAssistant;