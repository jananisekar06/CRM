// ============================================================
// ROLE BASED PAGE ACCESS
// ------------------------------------------------------------
// One place that decides, for every role, which pages (routes)
// that role is allowed to open.
//
// - "Super Admin" and "Admin" -> FULL_ACCESS (every page)
// - Every other role -> only the pages listed for that role
//
// To allow/deny a page for a role, just add/remove its path
// from that role's array below. Sidebar.jsx and ProtectedRoute.jsx
// both read from this same file, so menu + access always match.
// ============================================================

// Every real page in the app (excluding public/auth pages)
export const ALL_PAGES = [
  "/dashboard",
  "/customers",
  "/leads",
  "/employees",
  "/attendance",
  "/leave",
  "/payroll",
  "/payments",
  "/sales",
  "/reports",
  "/tasks",
  "/finance",
  "/meeting-scheduler",
  "/tickets",
  "/invoice",
  "/analytics",
  "/ai-assistant",
  "/ai-chatbot",
  "/email",
  "/activity-log",
  "/audit-log",
  "/follow-up",
  "/customer-portal",
  "/customer-experience",
  "/inventory",
  "/contact-management",
  "/vendors",
  "/campaigns",
  "/subscription-management",
  "/collaboration",
  "/notifications",
  "/upload",
  "/backup-restore",
  "/settings",
  "/communication",
  "/whatsapp",
  "/multi-language",
  "/multi-company",
  "/profile",
  "/super-admin",
];

// Pages that are always reachable once logged in, whatever the role
// (so nobody gets locked out of their own profile/settings/inbox).
const COMMON_PAGES = [
  "/dashboard",
  "/profile",
  "/settings",
  "/notifications",
  "/communication",
  "/collaboration",
  "/email",
  "/whatsapp",
  "/ai-assistant",
  "/ai-chatbot",
  "/multi-language",
];

// Roles that can see EVERY page (no restriction at all)
const FULL_ACCESS_ROLES = ["Super Admin", "Admin"];

// Page list per restricted role
const ROLE_PAGES = {
  "HR": [
    ...COMMON_PAGES,
    "/employees",
    "/attendance",
    "/leave",
    "/payroll",
    "/activity-log",
    "/meeting-scheduler",
    "/tasks",
    "/reports",
  ],

  "Sales Manager": [
    ...COMMON_PAGES,
    "/customers",
    "/leads",
    "/sales",
    "/reports",
    "/analytics",
    "/tasks",
    "/follow-up",
    "/campaigns",
    "/invoice",
    "/payments",
    "/meeting-scheduler",
    "/contact-management",
  ],

  "Sales Executive": [
    ...COMMON_PAGES,
    "/customers",
    "/leads",
    "/sales",
    "/tasks",
    "/follow-up",
    "/meeting-scheduler",
    "/invoice",
  ],

  "Support": [
    ...COMMON_PAGES,
    "/tickets",
    "/customer-experience",
    "/customer-portal",
    "/contact-management",
    "/follow-up",
  ],

  "Customer": [
    "/customer-portal",
    "/profile",
    "/settings",
    "/notifications",
    "/invoice",
    "/payments",
  ],
};

// Where each role lands right after login
export const DEFAULT_ROUTE = {
  "Super Admin": "/super-admin",
  "Admin": "/dashboard",
  "Sales Manager": "/dashboard",
  "Sales Executive": "/dashboard",
  "HR": "/dashboard",
  "Support": "/dashboard",
  "Customer": "/customer-portal",
};

export function getDefaultRoute(role) {
  return DEFAULT_ROUTE[role] || "/dashboard";
}

// Full list of paths a role is allowed to open
export function getAllowedPages(role) {
  if (FULL_ACCESS_ROLES.includes(role)) {
    return ALL_PAGES;
  }
  return ROLE_PAGES[role] || [];
}

// Is this role allowed to open this exact path?
export function isRouteAllowed(role, path) {
  if (FULL_ACCESS_ROLES.includes(role)) {
    return true;
  }
  return getAllowedPages(role).includes(path);
}
