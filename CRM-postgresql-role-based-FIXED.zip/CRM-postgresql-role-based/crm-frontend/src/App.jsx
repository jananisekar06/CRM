import { Routes, Route } from "react-router-dom";

import ProtectedRoute from "./components/ProtectedRoute";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Customers from "./pages/Customers";
import Leads from "./pages/Leads";
import Employees from "./pages/Employees";
import Attendance from "./pages/Attendance";
import Leave from "./pages/Leave";
import Payroll from "./pages/Payroll";
import Payments from "./pages/Payments";
import Sales from "./pages/Sales";
import Reports from "./pages/Reports";
import Tasks from "./pages/Tasks";
import FinanceManagement from "./pages/FinanceManagement";
import MeetingScheduler from "./pages/MeetingScheduler";
import TicketManagement from "./pages/TicketManagement";
import Invoice from "./pages/Invoice";
import Analytics from "./pages/Analytics";
import AIAssistant from "./pages/AIAssistant";
import AIChatbot from "./pages/AIChatbot";
import Email from "./pages/Email";
import ActivityLog from "./pages/ActivityLog";
import AuditLog from "./pages/AuditLog";
import FollowUp from "./pages/FollowUp";
import CustomerPortal from "./pages/CustomerPortal";
import CustomerExperience from "./pages/CustomerExperience";
import Inventory from "./pages/Inventory";
import ContactManagement from "./pages/ContactManagement";
import VendorManagement from "./pages/VendorManagement";
import CampaignManagement from "./pages/CampaignManagement";
import SubscriptionManagement from "./pages/SubscriptionManagement";
import Collaboration from "./pages/Collaboration";
import Notifications from "./pages/Notifications";
import Upload from "./pages/Upload";
import BackupRestore from "./pages/BackupRestore";
import Settings from "./pages/Settings";
import Communication from "./pages/Communication";
import WhatsApp from "./pages/WhatsApp";
import MultiLanguage from "./pages/MultiLanguage";
import MultiCompany from "./pages/MultiCompany";
import Profile from "./pages/Profile";
import SuperAdmin from "./pages/SuperAdmin";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";

function App() {
  return (
    <Routes>
      {/* Public pages - no login needed */}
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Protected pages - login required, and role must be allowed to see the page */}
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/customers" element={<ProtectedRoute><Customers /></ProtectedRoute>} />
      <Route path="/leads" element={<ProtectedRoute><Leads /></ProtectedRoute>} />
      <Route path="/employees" element={<ProtectedRoute><Employees /></ProtectedRoute>} />
      <Route path="/attendance" element={<ProtectedRoute><Attendance /></ProtectedRoute>} />
      <Route path="/leave" element={<ProtectedRoute><Leave /></ProtectedRoute>} />
      <Route path="/payroll" element={<ProtectedRoute><Payroll /></ProtectedRoute>} />
      <Route path="/payments" element={<ProtectedRoute><Payments /></ProtectedRoute>} />
      <Route path="/sales" element={<ProtectedRoute><Sales /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
      <Route path="/tasks" element={<ProtectedRoute><Tasks /></ProtectedRoute>} />
      <Route path="/finance" element={<ProtectedRoute><FinanceManagement /></ProtectedRoute>} />
      <Route path="/meeting-scheduler" element={<ProtectedRoute><MeetingScheduler /></ProtectedRoute>} />
      <Route path="/tickets" element={<ProtectedRoute><TicketManagement /></ProtectedRoute>} />
      <Route path="/invoice" element={<ProtectedRoute><Invoice /></ProtectedRoute>} />
      <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
      <Route path="/ai-assistant" element={<ProtectedRoute><AIAssistant /></ProtectedRoute>} />
      <Route path="/ai-chatbot" element={<ProtectedRoute><AIChatbot /></ProtectedRoute>} />
      <Route path="/email" element={<ProtectedRoute><Email /></ProtectedRoute>} />
      <Route path="/activity-log" element={<ProtectedRoute><ActivityLog /></ProtectedRoute>} />
      <Route path="/audit-log" element={<ProtectedRoute><AuditLog /></ProtectedRoute>} />
      <Route path="/follow-up" element={<ProtectedRoute><FollowUp /></ProtectedRoute>} />
      <Route path="/customer-portal" element={<ProtectedRoute><CustomerPortal /></ProtectedRoute>} />
      <Route path="/customer-experience" element={<ProtectedRoute><CustomerExperience /></ProtectedRoute>} />
      <Route path="/inventory" element={<ProtectedRoute><Inventory /></ProtectedRoute>} />
      <Route path="/contact-management" element={<ProtectedRoute><ContactManagement /></ProtectedRoute>} />
      <Route path="/vendors" element={<ProtectedRoute><VendorManagement /></ProtectedRoute>} />
      <Route path="/campaigns" element={<ProtectedRoute><CampaignManagement /></ProtectedRoute>} />
      <Route path="/subscription-management" element={<ProtectedRoute><SubscriptionManagement /></ProtectedRoute>} />
      <Route path="/collaboration" element={<ProtectedRoute><Collaboration /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
      <Route path="/upload" element={<ProtectedRoute><Upload /></ProtectedRoute>} />
      <Route path="/backup-restore" element={<ProtectedRoute><BackupRestore /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
      <Route path="/communication" element={<ProtectedRoute><Communication /></ProtectedRoute>} />
      <Route path="/whatsapp" element={<ProtectedRoute><WhatsApp /></ProtectedRoute>} />
      <Route path="/multi-language" element={<ProtectedRoute><MultiLanguage /></ProtectedRoute>} />
      <Route path="/multi-company" element={<ProtectedRoute><MultiCompany /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="/super-admin" element={<ProtectedRoute><SuperAdmin /></ProtectedRoute>} />
    </Routes>
  );
}

export default App;
