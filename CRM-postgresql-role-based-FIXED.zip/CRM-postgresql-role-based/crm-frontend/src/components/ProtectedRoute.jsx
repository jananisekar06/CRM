import { Navigate, useLocation } from "react-router-dom";
import { isRouteAllowed, getDefaultRoute } from "../config/rolePermissions";

function ProtectedRoute({ children }) {
  const location = useLocation();

  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  // Not logged in -> go to login
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // Logged in but this role has no access to this page ->
  // send them to whatever page IS theirs, not a blank/broken page.
  if (!isRouteAllowed(role, location.pathname)) {
    return <Navigate to={getDefaultRoute(role)} replace />;
  }

  return children;
}

export default ProtectedRoute;
