import { NavLink, useNavigate } from "react-router-dom";

import {
  FaHome,
  FaUsers,
  FaUserTie,
  FaCalendarCheck,
  FaClipboardList,
  FaMoneyBillWave,
  FaChartBar,
  FaBell,
  FaUpload,
  FaUserCircle,
  FaCog,
  FaSignOutAlt,
  FaRobot,
  FaComments,
  FaEnvelope,
  FaHistory,
  FaDoorOpen,
  FaBoxes,
  FaTruck,
  FaSmile,
  FaLanguage,
  FaHandshake,
  FaCoins,
  FaBullhorn,
  FaMoneyCheckAlt,
  FaVideo,
  FaPhoneAlt,
  FaDatabase,
  FaUserShield,
  FaBuilding,
  FaCrown,
  FaWhatsapp,
  FaFileInvoiceDollar,
  FaAddressBook,
} from "react-icons/fa";

import { isRouteAllowed } from "../config/rolePermissions";

// Every sidebar link lives here, in one list, so it can be filtered
// by role instead of being hardcoded as always-visible JSX.
const MENU_ITEMS = [
  { to: "/dashboard", icon: FaHome, label: "Dashboard" },
  { to: "/customers", icon: FaUsers, label: "Customers" },
  { to: "/employees", icon: FaUserTie, label: "Employees" },
  { to: "/attendance", icon: FaCalendarCheck, label: "Attendance" },
  { to: "/finance", icon: FaCoins, label: "Finance Management" },
  { to: "/meeting-scheduler", icon: FaVideo, label: "Meeting Scheduler" },
  { to: "/tickets", icon: FaClipboardList, label: "Ticket Management" },
  { to: "/invoice", icon: FaFileInvoiceDollar, label: "Invoice" },
  { to: "/analytics", icon: FaChartBar, label: "Analytics" },
  { to: "/ai-assistant", icon: FaRobot, label: "AI Assistant" },
  { to: "/ai-chatbot", icon: FaComments, label: "AI Chatbot" },
  { to: "/email", icon: FaEnvelope, label: "Email" },
  { to: "/activity-log", icon: FaHistory, label: "Activity Log" },
  { to: "/customer-portal", icon: FaDoorOpen, label: "Customer Portal" },
  { to: "/customer-experience", icon: FaSmile, label: "Customer Experience" },
  { to: "/inventory", icon: FaBoxes, label: "Inventory" },
  { to: "/contact-management", icon: FaAddressBook, label: "Contact Management" },
  { to: "/payroll", icon: FaMoneyCheckAlt, label: "Payroll" },
  { to: "/vendors", icon: FaTruck, label: "Vendor Management" },
  { to: "/campaigns", icon: FaBullhorn, label: "Campaign Management" },
  { to: "/subscription-management", icon: FaCrown, label: "Subscription Management" },
  { to: "/collaboration", icon: FaHandshake, label: "Collaboration" },
  { to: "/follow-up", icon: FaPhoneAlt, label: "Follow-up" },
  { to: "/leave", icon: FaClipboardList, label: "Leave" },
  { to: "/audit-log", icon: FaClipboardList, label: "Audit Log" },
  { to: "/payments", icon: FaMoneyCheckAlt, label: "Payments" },
  { to: "/sales", icon: FaMoneyBillWave, label: "Sales" },
  { to: "/whatsapp", icon: FaWhatsapp, label: "WhatsApp" },
  { to: "/backup-restore", icon: FaDatabase, label: "Backup & Restore" },
  { to: "/reports", icon: FaChartBar, label: "Reports" },
  { to: "/notifications", icon: FaBell, label: "Notifications" },
  { to: "/upload", icon: FaUpload, label: "Upload" },
  { to: "/profile", icon: FaUserCircle, label: "Profile" },
  { to: "/super-admin", icon: FaUserShield, label: "Super Admin" },
  { to: "/multi-company", icon: FaBuilding, label: "Multi Company" },
  { to: "/settings", icon: FaCog, label: "Settings" },
  { to: "/communication", icon: FaComments, label: "Communication" },
  { to: "/multi-language", icon: FaLanguage, label: "Multi-language" },
];

function Sidebar() {
  const navigate = useNavigate();
  const role = localStorage.getItem("role");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("email");
    localStorage.removeItem("user");
    navigate("/login", { replace: true });
  };

  // Only keep the links this logged-in role is actually allowed to open.
  // Super Admin / Admin get everything automatically (see rolePermissions.js).
  const visibleItems = MENU_ITEMS.filter((item) =>
    isRouteAllowed(role, item.to)
  );

  const menuStyle = ({ isActive }) => ({
    display: "flex",
    alignItems: "center",
    gap: "12px",

    padding: "9px 12px",
    margin: "0 0 2px 0",

    textDecoration: "none",

    color: isActive ? "#ffffff" : "#475569",

    background: isActive ? "#6366F1" : "transparent",

    borderRadius: "8px",

    fontWeight: "500",
    fontSize: "15px",

    transition: "0.2s",

    minHeight: "40px",
    boxSizing: "border-box",

    flexShrink: 0,
  });

  return (
    <div
      style={{
        width: "260px",

        /* Full screen sidebar */
        height: "100vh",
        minHeight: "100vh",

        background: "#ffffff",

        borderRight: "1px solid #e5e7eb",

        position: "fixed",
        left: 0,
        top: 0,

        /* IMPORTANT */
        overflowY: "auto",
        overflowX: "hidden",

        boxSizing: "border-box",

        zIndex: 1000,

        padding: "18px 12px",

        /* Smooth scrollbar */
        scrollbarWidth: "thin",
        scrollbarColor: "#CBD5E1 transparent",
      }}
    >
      {/* Logo */}

      <h2
        style={{
          color: "#4F46E5",
          textAlign: "center",

          margin: "5px 0 20px 0",

          fontSize: "24px",

          flexShrink: 0,
        }}
      >
        CRM Software
      </h2>

      {visibleItems.map(({ to, icon: Icon, label }) => (
        <NavLink key={to} to={to} style={menuStyle}>
          <Icon />
          {label}
        </NavLink>
      ))}

      {/* Logout */}

      <div
        onClick={handleLogout}
        style={{ ...menuStyle({ isActive: false }), cursor: "pointer" }}
      >
        <FaSignOutAlt />
        Logout
      </div>
    </div>
  );
}

export default Sidebar;