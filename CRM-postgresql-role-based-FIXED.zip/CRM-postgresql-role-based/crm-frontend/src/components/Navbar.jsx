import {
  FaSearch,
  FaBell,
  FaEnvelope,
  FaUserCircle,
} from "react-icons/fa";

function Navbar() {
  return (
    <div
      style={{
        height: "75px",
        background: "#ffffff",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 30px",
        borderBottom: "1px solid #e5e7eb",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}
    >
      {/* Left */}
      <div>
        <h2
          style={{
            margin: 0,
            color: "#334155",
          }}
        >
          CRM Dashboard
        </h2>

        <p
          style={{
            margin: 0,
            color: "#64748B",
            fontSize: "14px",
          }}
        >
          Welcome Back, Admin 👋
        </p>
      </div>

      {/* Center */}
      <div
        style={{
          width: "350px",
          position: "relative",
        }}
      >
        <FaSearch
          style={{
            position: "absolute",
            left: "15px",
            top: "14px",
            color: "#64748B",
          }}
        />

        <input
          type="text"
          placeholder="Search..."
          style={{
            width: "100%",
            padding: "12px 15px 12px 45px",
            border: "1px solid #CBD5E1",
            borderRadius: "30px",
            outline: "none",
            fontSize: "14px",
          }}
        />
      </div>

      {/* Right */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "20px",
        }}
      >
        <FaBell
          size={20}
          color="#475569"
          style={{ cursor: "pointer" }}
        />

        <FaEnvelope
          size={20}
          color="#475569"
          style={{ cursor: "pointer" }}
        />

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <FaUserCircle
            size={40}
            color="#6366F1"
          />

          <div>
            <h4
              style={{
                margin: 0,
                color: "#334155",
              }}
            >
              Admin
            </h4>

            <small
              style={{
                color: "#64748B",
              }}
            >
              Administrator
            </small>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Navbar;