
const express = require("express");

const router = express.Router();

const {
  getCalls,
  getCallById,
  createCall,
  updateCall,
  deleteCall,
} = require("../controllers/communicationController");

// GET all calls
router.get("/calls", getCalls);

// GET single call
router.get("/calls/:id", getCallById);

// CREATE call
router.post("/calls", createCall);

// UPDATE call
router.put("/calls/:id", updateCall);

// DELETE call
router.delete("/calls/:id", deleteCall);

module.exports = router;
