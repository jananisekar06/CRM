const express = require("express");

const router = express.Router();

const {
  getFeedbacks,
  getFeedbackById,
  createFeedback,
  updateFeedback,
  deleteFeedback,
  getLoyaltyPoints,
  getReferrals,
  getSurveys,
  getKnowledgeBase,
  getSummary,
} = require("../controllers/customerExperienceController");

// ==========================================
// FEEDBACK
// ==========================================

router.get("/feedbacks", getFeedbacks);

router.get(
  "/feedbacks/:id",
  getFeedbackById
);

router.post(
  "/feedbacks",
  createFeedback
);

router.put(
  "/feedbacks/:id",
  updateFeedback
);

router.delete(
  "/feedbacks/:id",
  deleteFeedback
);

// ==========================================
// LOYALTY
// ==========================================

router.get(
  "/loyalty",
  getLoyaltyPoints
);

// ==========================================
// REFERRALS
// ==========================================

router.get(
  "/referrals",
  getReferrals
);

// ==========================================
// CSAT SURVEYS
// ==========================================

router.get(
  "/surveys",
  getSurveys
);

// ==========================================
// KNOWLEDGE BASE
// ==========================================

router.get(
  "/knowledge-base",
  getKnowledgeBase
);

// ==========================================
// SUMMARY
// ==========================================

router.get(
  "/summary",
  getSummary
);

module.exports = router;