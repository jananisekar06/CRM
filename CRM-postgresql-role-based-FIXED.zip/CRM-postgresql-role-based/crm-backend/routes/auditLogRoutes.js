const express = require("express");

const router = express.Router();

const {
  getAuditLogs,
  createAuditLog,
  updateAuditLog,
  deleteAuditLog,
} = require("../controllers/auditLogController");

router.get("/", getAuditLogs);

router.post("/", createAuditLog);

router.put("/:id", updateAuditLog);

router.delete("/:id", deleteAuditLog);

module.exports = router;