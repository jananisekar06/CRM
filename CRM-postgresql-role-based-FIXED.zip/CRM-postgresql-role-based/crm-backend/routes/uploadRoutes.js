
const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const {
  getUploadedFiles,
  uploadFile,
  deleteUploadedFile,
} = require("../controllers/uploadController");

// Create uploads folder automatically
const uploadDir = path.join(__dirname, "..", "uploads");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },

  filename: (req, file, cb) => {
    const uniqueName =
      Date.now() +
      "-" +
      Math.round(Math.random() * 1e9) +
      path.extname(file.originalname);

    cb(null, uniqueName);
  },
});

// Allowed file extensions
const allowedExtensions = [
  ".pdf",
  ".xls",
  ".xlsx",
  ".doc",
  ".docx",
  ".csv",
  ".png",
  ".jpg",
  ".jpeg",
];

const fileFilter = (req, file, cb) => {
  const extension = path.extname(file.originalname).toLowerCase();

  if (allowedExtensions.includes(extension)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Only PDF, Excel, Word, CSV and image files are allowed."
      )
    );
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024,
  },
});

// GET all uploaded files
router.get("/", getUploadedFiles);

// POST upload file
router.post("/", upload.single("file"), uploadFile);

// DELETE file
router.delete("/:id", deleteUploadedFile);

module.exports = router;
