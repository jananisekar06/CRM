
const express = require("express");

const router = express.Router();

const {
  getCompanies,
  getCompanyById,
  createCompany,
  updateCompany,
  deleteCompany,
} = require("../controllers/superAdminController");

// GET all companies
router.get("/companies", getCompanies);

// GET single company
router.get("/companies/:id", getCompanyById);

// CREATE company
router.post("/companies", createCompany);

// UPDATE company
router.put("/companies/:id", updateCompany);

// DELETE company
router.delete("/companies/:id", deleteCompany);

module.exports = router;
