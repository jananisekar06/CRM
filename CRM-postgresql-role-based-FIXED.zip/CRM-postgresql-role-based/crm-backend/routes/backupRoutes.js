const express = require("express");
const router = express.Router();

const {
  getBackups,
  createBackup,
  updateBackup,
  deleteBackup,
  restoreBackup,
  getRestoreHistory,
} = require("../controllers/backupController");

// GET all backups
router.get("/", getBackups);

// CREATE backup
router.post("/", createBackup);

// UPDATE backup
router.put("/:id", updateBackup);

// DELETE backup
router.delete("/:id", deleteBackup);

// RESTORE backup
router.post("/restore", restoreBackup);

// RESTORE history
router.get("/restore-history", getRestoreHistory);

module.exports = router;