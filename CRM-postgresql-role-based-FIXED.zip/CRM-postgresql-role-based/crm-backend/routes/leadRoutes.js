const express = require("express");
const router = express.Router();

const {
  getLeads,
  addLead,
  updateLeadStatus,
} = require("../controllers/leadController");

router.get("/", getLeads);
router.post("/", addLead);
router.put("/:id/status", updateLeadStatus);

module.exports = router;