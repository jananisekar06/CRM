const express = require("express");
const router = express.Router();

const {
  askAI,
} = require("../controllers/aiAssistantController");

router.post("/ask", askAI);

module.exports = router;