const express = require("express");

const router = express.Router();

const {
  getLanguages,
  getLanguageUsers,
  updateLanguage,
} = require("../controllers/multiLanguageController");

router.get("/", getLanguages);

router.get("/users", getLanguageUsers);

router.put("/", updateLanguage);

module.exports = router;