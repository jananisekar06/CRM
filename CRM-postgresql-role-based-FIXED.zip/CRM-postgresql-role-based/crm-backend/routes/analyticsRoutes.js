const express = require("express");

const router = express.Router();

const {
  getAnalytics,
  getAnalyticsById,
} = require("../controllers/analyticsController");

router.get("/", getAnalytics);

router.get("/:id", getAnalyticsById);

module.exports = router;
