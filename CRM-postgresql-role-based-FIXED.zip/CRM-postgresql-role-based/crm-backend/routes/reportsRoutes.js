const express = require("express");
const router = express.Router();

const {
  getReports,
  addReport,
  deleteReport,
  updateReport,
} = require("../controllers/reportsController");
router.get("/", getReports);
router.post("/", addReport);
router.delete("/:id", deleteReport);
router.put("/:id", updateReport);
module.exports = router;