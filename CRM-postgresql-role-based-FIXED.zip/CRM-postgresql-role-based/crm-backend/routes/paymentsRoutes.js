const express = require("express");
const router = express.Router();

const {
  getPayments,
  addPayment,
} = require("../controllers/paymentsController");

router.get("/", getPayments);
router.post("/", addPayment);

module.exports = router;