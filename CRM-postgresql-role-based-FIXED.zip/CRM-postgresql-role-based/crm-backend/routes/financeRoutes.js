const express = require("express");
const router = express.Router();

const {
  getFinances,
  addFinance,
  deleteFinance,
  updateFinance,
} = require("../controllers/financeController");

router.get("/", getFinances);
router.post("/", addFinance);
router.delete("/:id", deleteFinance);
router.put("/:id", updateFinance);

module.exports = router;
