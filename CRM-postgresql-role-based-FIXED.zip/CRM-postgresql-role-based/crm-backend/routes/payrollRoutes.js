const express = require("express");

const router = express.Router();

const {
  getPayroll,
  addPayroll,
} = require("../controllers/payrollController");

router.get("/", getPayroll);

router.post("/", addPayroll);

module.exports = router;