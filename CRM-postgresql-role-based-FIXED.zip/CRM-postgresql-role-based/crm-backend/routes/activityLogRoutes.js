
const express = require("express");

const router = express.Router();

const {
  getActivityLogs,
  createActivityLog,
  getActivityLogById,
  deleteActivityLog,
} = require("../controllers/activityLogController");

// GET ALL
router.get("/", getActivityLogs);

// CREATE
router.post("/", createActivityLog);

// GET SINGLE
router.get("/:id", getActivityLogById);

// DELETE
router.delete("/:id", deleteActivityLog);

module.exports = router;
