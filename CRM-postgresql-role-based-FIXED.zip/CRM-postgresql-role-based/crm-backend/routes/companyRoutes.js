const express = require("express");
const router = express.Router();

const {
  getCompanies,
  getCompanyById,
  createCompany,
  updateCompany,
  deleteCompany,
} = require("../controllers/companyController");

// Get all companies
router.get("/", getCompanies);

// Get one company
router.get("/:id", getCompanyById);

// Create company
router.post("/", createCompany);

// Update company
router.put("/:id", updateCompany);

// Delete company
router.delete("/:id", deleteCompany);

module.exports = router;