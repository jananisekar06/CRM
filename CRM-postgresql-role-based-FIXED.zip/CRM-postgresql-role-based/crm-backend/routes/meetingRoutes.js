const express = require("express");
const router = express.Router();

const {
  getMeetings,
  addMeeting,
  updateMeeting,
  deleteMeeting,
} = require("../controllers/meetingController");

router.get("/", getMeetings);
router.post("/", addMeeting);
router.put("/:id", updateMeeting);
router.delete("/:id", deleteMeeting);

module.exports = router;