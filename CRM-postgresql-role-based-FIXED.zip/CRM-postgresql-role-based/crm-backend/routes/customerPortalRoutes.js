const express = require("express");

const router = express.Router();

const {
  getCustomers,
  getCustomerById,
  updateCustomer,
  deleteCustomer,
} = require("../controllers/customerPortalController");

// GET all customers
router.get("/customers", getCustomers);

// GET single customer
router.get("/customers/:id", getCustomerById);

// UPDATE customer
router.put("/customers/:id", updateCustomer);

// DELETE customer
router.delete("/customers/:id", deleteCustomer);

module.exports = router;