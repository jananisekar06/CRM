const express = require("express");
const router = express.Router();

const {
  getCollaborations,
  getCollaborationById,
  createCollaboration,
  updateCollaboration,
  deleteCollaboration,
} = require("../controllers/collaborationController");

router.get("/", getCollaborations);

router.get("/:id", getCollaborationById);

router.post("/", createCollaboration);

router.put("/:id", updateCollaboration);

router.delete("/:id", deleteCollaboration);

module.exports = router;