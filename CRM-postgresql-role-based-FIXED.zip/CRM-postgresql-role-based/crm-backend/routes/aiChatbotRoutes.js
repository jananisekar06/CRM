const express = require("express");

const router = express.Router();

const {
  chatWithAI,
  connectSupport,
} = require("../controllers/aiChatbotController");

router.post("/chat", chatWithAI);

router.post("/support", connectSupport);

module.exports = router;