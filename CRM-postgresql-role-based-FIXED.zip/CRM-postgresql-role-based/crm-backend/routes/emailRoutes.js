const express = require("express");

const router = express.Router();

const {
  getEmails,
  createEmail,
  updateEmail,
  deleteEmail,
} = require("../controllers/emailController");

router.get("/", getEmails);

router.post("/", createEmail);

router.put("/:id", updateEmail);

router.delete("/:id", deleteEmail);

module.exports = router;