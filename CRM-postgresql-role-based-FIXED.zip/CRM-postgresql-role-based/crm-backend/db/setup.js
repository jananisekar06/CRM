const fs = require("fs");
const path = require("path");
const pool = require("./pool");

async function run() {
  const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  await pool.query(schema);
  console.log("All tables created (or already existed).");
  await pool.end();
}

run().catch((err) => {
  console.error("Setup failed:", err);
  process.exit(1);
});
