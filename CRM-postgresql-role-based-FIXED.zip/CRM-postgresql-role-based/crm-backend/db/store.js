const pool = require("./pool");

// =====================================================
// ALLOWED TABLES
// =====================================================

const ALLOWED_TABLES = [
  "tickets",
  "meetings",
  "employees",
  "customers",
  "attendance",
  "leaves",
  "finances",
  "tasks",
  "invoices",
  "payroll",
  "activity_logs",
  "analytics",
  "audit_logs",
  "backups",
  "backup_restore_history",
  "campaigns",
  "collaborations",
  "calls",
  "companies",
  "contacts",
  "customer_portal",
  "cx_feedbacks",
  "cx_loyalty",
  "cx_referrals",
  "cx_surveys",
  "cx_knowledge_base",
  "emails",
  "follow_ups",
  "subscriptions",
  "super_admin_companies",
  "vendors",
  "whatsapp_messages",
  "language_users",
  "products",
  "payments",
  "reports",
  "leads",
  "notifications",
  "uploaded_files",
  "sales",
];

function checkTable(table) {
  if (!ALLOWED_TABLES.includes(table)) {
    throw new Error(`Invalid table name: ${table}`);
  }

  return table;
}

// =====================================================
// LIST ALL
// =====================================================

async function listAll(table, orderBy = "created_at ASC") {
  checkTable(table);

  const { rows } = await pool.query(
    `SELECT payload
     FROM ${table}
     ORDER BY ${orderBy}`
  );

  return rows.map((row) => row.payload);
}

// =====================================================
// GET BY ID
// =====================================================

async function getById(
  table,
  id,
  caseInsensitive = false
) {
  checkTable(table);

  const condition = caseInsensitive
    ? "LOWER(id) = LOWER($1)"
    : "id = $1";

  const { rows } = await pool.query(
    `SELECT payload
     FROM ${table}
     WHERE ${condition}
     LIMIT 1`,
    [String(id)]
  );

  return rows[0] ? rows[0].payload : null;
}

// =====================================================
// EXISTS
// =====================================================

async function existsById(
  table,
  id,
  caseInsensitive = false
) {
  const item = await getById(
    table,
    id,
    caseInsensitive
  );

  return !!item;
}

// =====================================================
// INSERT
// =====================================================

async function insertItem(table, item) {
  checkTable(table);

  if (!item || !item.id) {
    throw new Error("Item ID is required");
  }

  const { rows } = await pool.query(
    `INSERT INTO ${table}
      (id, payload, created_at, updated_at)
     VALUES
      ($1, $2, NOW(), NOW())
     RETURNING payload`,
    [
      String(item.id),
      JSON.stringify(item),
    ]
  );

  return rows[0]?.payload || item;
}

// =====================================================
// UPDATE
// =====================================================

async function updateItem(
  table,
  id,
  newItem,
  caseInsensitive = false
) {
  checkTable(table);

  const condition = caseInsensitive
    ? "LOWER(id) = LOWER($1)"
    : "id = $1";

  const { rows } = await pool.query(
    `UPDATE ${table}
     SET payload = $2,
         updated_at = NOW()
     WHERE ${condition}
     RETURNING payload`,
    [
      String(id),
      JSON.stringify(newItem),
    ]
  );

  return rows[0] ? rows[0].payload : null;
}

// =====================================================
// DELETE
// =====================================================

async function removeItem(
  table,
  id,
  caseInsensitive = false
) {
  checkTable(table);

  const condition = caseInsensitive
    ? "LOWER(id) = LOWER($1)"
    : "id = $1";

  const { rows } = await pool.query(
    `DELETE FROM ${table}
     WHERE ${condition}
     RETURNING payload`,
    [String(id)]
  );

  return rows[0] ? rows[0].payload : null;
}

// =====================================================
// NEXT NUMERIC ID
// =====================================================

async function nextNumericId(table) {
  checkTable(table);

  const { rows } = await pool.query(
    `SELECT COALESCE(
       MAX(
         CASE
           WHEN id ~ '^[0-9]+$'
           THEN CAST(id AS INTEGER)
           ELSE 0
         END
       ),
       0
     ) + 1 AS next
     FROM ${table}`
  );

  return Number(rows[0].next);
}

// =====================================================
// NEXT PREFIXED ID
// Example:
// TKT001
// TKT002
// TKT003
// =====================================================

async function nextPrefixedId(
  table,
  prefix,
  pad = 3
) {
  checkTable(table);

  const { rows } = await pool.query(
    `SELECT COALESCE(
       MAX(
         CAST(
           SUBSTRING(id FROM '[0-9]+$')
           AS INTEGER
         )
       ),
       0
     ) + 1 AS next
     FROM ${table}
     WHERE id ~ $1`,
    [`^${prefix}[0-9]+$`]
  );

  const nextNumber = Number(rows[0].next);

  return `${prefix}${String(nextNumber).padStart(
    pad,
    "0"
  )}`;
}

// =====================================================
// TEST DATABASE
// =====================================================

async function testConnection() {
  const { rows } = await pool.query(
    "SELECT NOW() AS current_time"
  );

  return rows[0];
}

// =====================================================
// EXPORT
// =====================================================

module.exports = {
  listAll,
  getById,
  existsById,
  insertItem,
  updateItem,
  removeItem,
  nextNumericId,
  nextPrefixedId,
  testConnection,
};
