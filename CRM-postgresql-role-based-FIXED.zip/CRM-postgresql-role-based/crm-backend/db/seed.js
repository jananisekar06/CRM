const pool = require("./pool");
const bcrypt = require("bcrypt");

// One seed set per table, taken from the original in-memory demo data.
const seeds = {
  activity_logs: [
    { id: "LOG001", user: "John Smith", activity: "Login", date: "30-07-2026", time: "09:00 AM", status: "Success" },
    { id: "LOG002", user: "Priya", activity: "Customer Added", date: "30-07-2026", time: "09:30 AM", status: "Completed" },
    { id: "LOG003", user: "Rahul", activity: "Invoice Created", date: "30-07-2026", time: "10:15 AM", status: "Completed" },
    { id: "LOG004", user: "David", activity: "Report Downloaded", date: "30-07-2026", time: "11:20 AM", status: "Success" },
    { id: "LOG005", user: "Sneha", activity: "Logout", date: "30-07-2026", time: "06:00 PM", status: "Success" },
  ],
  analytics: [
    { id: 1, category: "Sales", value: "₹8,50,000", growth: "+18%" },
    { id: 2, category: "Revenue", value: "₹12,40,000", growth: "+25%" },
    { id: 3, category: "Customer Growth", value: "2,350", growth: "+15%" },
    { id: 4, category: "Lead Conversion", value: "72%", growth: "+8%" },
    { id: 5, category: "Top Employee", value: "John Smith", growth: "Sales Champion" },
  ],
  audit_logs: [
    { id: "LOG001", user: "John Smith", action: "Updated Employee", oldValue: "Salary ₹25,000", newValue: "Salary ₹28,000", date: "05-08-2026", status: "Success" },
    { id: "LOG002", user: "Priya", action: "Created Customer", oldValue: "-", newValue: "ABC Company", date: "06-08-2026", status: "Success" },
    { id: "LOG003", user: "Rahul", action: "Deleted Invoice", oldValue: "INV-1025", newValue: "-", date: "07-08-2026", status: "Warning" },
  ],
  backups: [
    { id: "BK001", name: "Daily Backup", type: "Automatic", date: "05-08-2026", time: "02:00 AM", size: "150 MB", storageLocation: "Local Storage", schedule: "Daily", status: "Completed" },
    { id: "BK002", name: "Manual Backup", type: "Manual", date: "06-08-2026", time: "10:30 AM", size: "155 MB", storageLocation: "Cloud Storage", schedule: "Weekly", status: "Completed" },
    { id: "BK003", name: "Scheduled Backup", type: "Automatic", date: "07-08-2026", time: "02:00 AM", size: "160 MB", storageLocation: "Local Storage", schedule: "Daily", status: "Scheduled" },
  ],
  backup_restore_history: [
    { id: "RS001", backupId: "BK001", restoreDate: "05-08-2026", restoredBy: "Admin", status: "Success" },
    { id: "RS002", backupId: "BK002", restoreDate: "06-08-2026", restoredBy: "Super Admin", status: "Success" },
  ],
  campaigns: [
    { id: "CMP001", name: "Summer Offer", channel: "Email", sent: 500, opened: 420, clicked: 180, status: "Completed" },
    { id: "CMP002", name: "Festival Sale", channel: "SMS", sent: 1000, opened: 960, clicked: 320, status: "Running" },
    { id: "CMP003", name: "New Product Launch", channel: "WhatsApp", sent: 300, opened: 280, clicked: 145, status: "Completed" },
    { id: "CMP004", name: "Membership Offer", channel: "Email", sent: 750, opened: 620, clicked: 250, status: "Scheduled" },
    { id: "CMP005", name: "Weekend Discount", channel: "SMS", sent: 900, opened: 870, clicked: 310, status: "Running" },
  ],
  collaborations: [
    { id: "CHAT001", employee: "John Smith", type: "One-to-One", lastMessage: "Project Completed", status: "Online" },
    { id: "CHAT002", employee: "Priya", type: "Group Chat", lastMessage: "Meeting at 3 PM", status: "Offline" },
    { id: "CHAT003", employee: "Rahul", type: "Group Chat", lastMessage: "Invoice Updated", status: "Online" },
    { id: "CHAT004", employee: "David", type: "One-to-One", lastMessage: "Please Review", status: "Busy" },
  ],
  calls: [
    { id: "CL001", customer: "John Smith", phone: "9876543210", duration: "08:30", employee: "Priya", status: "Completed" },
    { id: "CL002", customer: "Rahul", phone: "9876501234", duration: "05:15", employee: "David", status: "Missed" },
    { id: "CL003", customer: "Sneha", phone: "9876512345", duration: "12:45", employee: "John", status: "Completed" },
    { id: "CL004", customer: "Arun", phone: "9876523456", duration: "03:10", employee: "Priya", status: "Ongoing" },
  ],
  companies: [
    { id: "CMP001", name: "ABC Company", admin: "John Smith", email: "john@abc.com", employees: 120, plan: "Premium", status: "Active" },
    { id: "CMP002", name: "XYZ Pvt Ltd", admin: "Rahul", email: "rahul@xyz.com", employees: 80, plan: "Standard", status: "Active" },
    { id: "CMP003", name: "Tech Solutions", admin: "David", email: "david@tech.com", employees: 45, plan: "Basic", status: "Inactive" },
  ],
  contacts: [
    { id: "CNT001", company: "ABC Company", name: "John Smith", role: "Manager", phone: "+91 9876543210", email: "john@abc.com", primaryContact: "Yes", status: "Active", notes: "Main contact" },
    { id: "CNT002", company: "ABC Company", name: "Priya", role: "HR", phone: "+91 9876500000", email: "priya@abc.com", primaryContact: "No", status: "Active", notes: "HR contact" },
    { id: "CNT003", company: "XYZ Pvt Ltd", name: "Rahul", role: "CEO", phone: "+91 9988776655", email: "rahul@xyz.com", primaryContact: "Yes", status: "Inactive", notes: "CEO contact" },
  ],
  cx_feedbacks: [
    { id: "FB001", customer: "John Smith", service: "CRM Setup", rating: 5, feedback: "Excellent Service", status: "Reviewed" },
    { id: "FB002", customer: "Priya", service: "Support", rating: 4, feedback: "Very Good", status: "Pending" },
    { id: "FB003", customer: "Rahul", service: "Training", rating: 5, feedback: "Outstanding", status: "Reviewed" },
    { id: "FB004", customer: "David", service: "Consultation", rating: 3, feedback: "Average", status: "Pending" },
  ],
  cx_loyalty: [
    { id: "LOY001", customer: "John Smith", purchase: 15000, pointsEarned: 150, reward: "10% Discount Coupon", status: "Available" },
    { id: "LOY002", customer: "Priya", purchase: 8500, pointsEarned: 85, reward: "Gift Voucher", status: "Redeemed" },
    { id: "LOY003", customer: "Rahul", purchase: 22000, pointsEarned: 220, reward: "Premium Membership", status: "Earned" },
  ],
  cx_referrals: [
    { id: "REF001", referrer: "John Smith", newCustomer: "David", reward: "₹500 Voucher", status: "Verified" },
    { id: "REF002", referrer: "Priya", newCustomer: "Sneha", reward: "100 Points", status: "Pending" },
    { id: "REF003", referrer: "Rahul", newCustomer: "Arun", reward: "₹1000 Coupon", status: "Rewarded" },
  ],
  cx_surveys: [
    { id: "CS001", customer: "John Smith", ticket: "TK001", csatScore: 95, response: "Excellent" },
    { id: "CS002", customer: "Priya", ticket: "TK002", csatScore: 88, response: "Good" },
    { id: "CS003", customer: "Rahul", ticket: "TK003", csatScore: 72, response: "Average" },
  ],
  cx_knowledge_base: [
    { id: "KB001", title: "How to reset my password?", type: "FAQ" },
    { id: "KB002", title: "CRM User Guide", type: "Guide" },
    { id: "KB003", title: "Video Tutorial – Customer Management", type: "Video" },
    { id: "KB004", title: "Troubleshooting Login Issues", type: "Troubleshooting" },
    { id: "KB005", title: "Invoice Download Guide", type: "Guide" },
  ],
  customer_portal: [
    { id: "CUS001", name: "John Smith", invoice: "INV1001", payment: "Paid", ticket: "Open" },
    { id: "CUS002", name: "Priya", invoice: "INV1002", payment: "Pending", ticket: "Closed" },
    { id: "CUS003", name: "Rahul", invoice: "INV1003", payment: "Paid", ticket: "Open" },
    { id: "CUS004", name: "David", invoice: "INV1004", payment: "Pending", ticket: "Closed" },
    { id: "CUS005", name: "Sneha", invoice: "INV1005", payment: "Paid", ticket: "Open" },
  ],
  follow_ups: [
    { id: "FU001", customer: "ABC Company", contact: "John Smith", employee: "Priya", phone: "9876543210", date: "05-08-2026", time: "04:00 PM", priority: "High", status: "Scheduled", notes: "Discussed new requirements" },
    { id: "FU002", customer: "XYZ Pvt Ltd", contact: "Rahul", employee: "David", phone: "9876543211", date: "05-08-2026", time: "11:00 AM", priority: "Medium", status: "Completed", notes: "Follow-up call completed" },
  ],
  emails: [
    { id: "EM001", type: "Welcome", recipient: "John Smith", subject: "Welcome to CRM", date: "30-07-2026", status: "Sent" },
    { id: "EM002", type: "Proposal", recipient: "Priya", subject: "Business Proposal", date: "31-07-2026", status: "Pending" },
    { id: "EM003", type: "Meeting Reminder", recipient: "Rahul", subject: "Meeting Reminder", date: "01-08-2026", status: "Sent" },
    { id: "EM004", type: "Invoice", recipient: "David", subject: "Invoice Generated", date: "02-08-2026", status: "Sent" },
    { id: "EM005", type: "Payment Reminder", recipient: "Sneha", subject: "Payment Due", date: "03-08-2026", status: "Pending" },
  ],
  subscriptions: [
    { id: "SUB001", company: "ABC Company", plan: "Enterprise", expiry: "31-12-2026", amount: 50000, status: "Active" },
    { id: "SUB002", company: "XYZ Pvt Ltd", plan: "Pro", expiry: "15-09-2026", amount: 20000, status: "Renewal Due" },
    { id: "SUB003", company: "Tech Solutions", plan: "Basic", expiry: "10-08-2026", amount: 8000, status: "Expired" },
  ],
  super_admin_companies: [
    { id: "CMP001", company: "ABC Company", admin: "John Smith", users: 120, plan: "Premium", status: "Active" },
    { id: "CMP002", company: "XYZ Pvt Ltd", admin: "Rahul", users: 75, plan: "Standard", status: "Active" },
    { id: "CMP003", company: "Tech Solutions", admin: "David", users: 45, plan: "Basic", status: "Inactive" },
  ],
  vendors: [
    { id: "V001", name: "ABC Technologies", purchase: "₹50,000", payment: "Paid", orders: 10, status: "Active" },
    { id: "V002", name: "Global Supplies", purchase: "₹25,000", payment: "Pending", orders: 5, status: "Active" },
    { id: "V003", name: "Star Electronics", purchase: "₹75,000", payment: "Paid", orders: 15, status: "Active" },
    { id: "V004", name: "Smart Traders", purchase: "₹18,000", payment: "Pending", orders: 4, status: "Inactive" },
    { id: "V005", name: "Tech World", purchase: "₹42,000", payment: "Paid", orders: 8, status: "Active" },
  ],
  whatsapp_messages: [
    { id: "WA001", customer: "ABC Company", phone: "+91 9876543210", type: "Meeting Reminder", date: "05-08-2026", status: "Delivered", message: "Meeting Reminder" },
    { id: "WA002", customer: "XYZ Pvt Ltd", phone: "+91 9988776655", type: "Invoice", date: "05-08-2026", status: "Pending", message: "Invoice" },
    { id: "WA003", customer: "Tech Solutions", phone: "+91 9123456789", type: "Payment Reminder", date: "06-08-2026", status: "Delivered", message: "Payment Reminder" },
  ],
  employees: [
    { id: 101, name: "John Smith", department: "Sales", designation: "Sales Executive", salary: "₹35,000", email: "john@gmail.com", phone: "9876543210", status: "Active" },
    { id: 102, name: "Priya", department: "HR", designation: "HR Manager", salary: "₹45,000", email: "priya@gmail.com", phone: "9876500000", status: "Active" },
    { id: 103, name: "Rahul", department: "IT", designation: "React Developer", salary: "₹55,000", email: "rahul@gmail.com", phone: "9876511111", status: "Inactive" },
    { id: 104, name: "David", department: "Finance", designation: "Accountant", salary: "₹40,000", email: "david@gmail.com", phone: "9876522222", status: "Active" },
    { id: 105, name: "Sneha", department: "Support", designation: "Support Executive", salary: "₹30,000", email: "sneha@gmail.com", phone: "9876533333", status: "Active" },
  ],
  language_users: [
    { id: 1, name: "John", language: "English", status: "Active" },
    { id: 2, name: "Priya", language: "Tamil", status: "Active" },
    { id: 3, name: "Rahul", language: "Hindi", status: "Active" },
    { id: 4, name: "David", language: "English", status: "Active" },
    { id: 5, name: "Sneha", language: "Tamil", status: "Active" },
  ],
};

async function seedTable(table, rows) {
  for (const row of rows) {
    await pool.query(
      `INSERT INTO ${table} (id, payload) VALUES ($1, $2) ON CONFLICT (id) DO NOTHING`,
      [String(row.id), JSON.stringify(row)]
    );
  }
  console.log(`Seeded ${rows.length} rows -> ${table}`);
}

async function run() {
  for (const [table, rows] of Object.entries(seeds)) {
    await seedTable(table, rows);
  }

  // app_settings: current language for MultiLanguage page
  await pool.query(
    `INSERT INTO app_settings (key, value) VALUES ('currentLanguage', 'English') ON CONFLICT (key) DO NOTHING`
  );

  // Default admin login (same demo credentials the old code had)
  const existing = await pool.query("SELECT id FROM users WHERE email = $1", ["admin@gmail.com"]);
  if (existing.rows.length === 0) {
    const hash = await bcrypt.hash("123456", 10);
    await pool.query(
      "INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4)",
      ["Admin", "admin@gmail.com", hash, "Admin"]
    );
    console.log("Seeded default admin login -> admin@gmail.com / 123456");
  }

  console.log("Seeding complete.");
  await pool.end();
}

run().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
