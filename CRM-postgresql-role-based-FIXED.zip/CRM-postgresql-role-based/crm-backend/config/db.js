// PostgreSQL connection (previously MySQL via mysql2).
// Re-exports the shared pool so any existing `require("../config/db")`
// calls keep working unchanged.
module.exports = require("../db/pool");
