const express = require("express");
const cors = require("cors");
require("dotenv").config();

// =====================================================
// DIAGNOSTICS: log WHY the process ever exits.
// Without this, Node/nodemon can shut down silently (e.g. an uncaught
// exception in an async route handler, a native-module load failure like
// bcrypt's missing build, etc.) and all you see is nodemon printing
// "clean exit - waiting for changes before restart" with no explanation.
// =====================================================
process.on("uncaughtException", (err) => {
  console.error("💥 Uncaught Exception (this is what killed the server):");
  console.error(err);
});
process.on("unhandledRejection", (reason) => {
  console.error("💥 Unhandled Promise Rejection (this is what killed the server):");
  console.error(reason);
});
process.on("exit", (code) => {
  console.log(`🚪 Process exiting with code ${code}`);
});

const app = express();

app.use(cors());
app.use(express.json());

const authRoutes = require("./routes/authRoutes");
const employeeRoutes = require("./routes/employeeRoutes");
const customerRoutes = require("./routes/customerRoutes");
const leadRoutes = require("./routes/leadRoutes");
const attendanceRoutes = require("./routes/attendanceRoutes");
const leaveRoutes = require("./routes/leaveRoutes");
const taskRoutes = require("./routes/taskRoutes");
const payrollRoutes = require("./routes/payrollRoutes");
const paymentsRoutes = require("./routes/paymentsRoutes");
const reportsRoutes = require("./routes/reportsRoutes");
const inventoryRoutes = require("./routes/inventoryRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const salesRoutes = require("./routes/salesRoutes");
const invoiceRoutes = require("./routes/invoiceRoutes");
const financeRoutes = require("./routes/financeRoutes");
const meetingRoutes = require("./routes/meetingRoutes");
const ticketRoutes = require("./routes/ticketRoutes");
const followupRoutes = require("./routes/followupRoutes");
const contactRoutes = require("./routes/contactRoutes");
const vendorRoutes = require("./routes/vendorRoutes");
const campaignRoutes = require("./routes/campaignRoutes");
const emailRoutes = require("./routes/emailRoutes");
const whatsappRoutes = require("./routes/whatsappRoutes");
const activityLogRoutes = require("./routes/activityLogRoutes");
const auditLogRoutes = require("./routes/auditLogRoutes");
const subscriptionRoutes = require("./routes/subscriptionRoutes");
const superAdminRoutes = require("./routes/superAdminRoutes");
const communicationRoutes = require("./routes/communicationRoutes");
const customerPortalRoutes = require("./routes/customerPortalRoutes");
const customerExperienceRoutes = require("./routes/customerExperienceRoutes");
const collaborationRoutes = require("./routes/collaborationRoutes");
const backupRoutes = require("./routes/backupRoutes");
const uploadRoutes = require("./routes/uploadRoutes");
const companyRoutes = require("./routes/companyRoutes");
const multiLanguageRoutes = require("./routes/multiLanguageRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const aiChatbotRoutes = require("./routes/aiChatbotRoutes");
const aiAssistantRoutes = require("./routes/aiAssistantRoutes");



app.use("/api/auth", authRoutes);
app.use("/api/employees", employeeRoutes);
app.use("/api/customers", customerRoutes);
app.use("/api/leads", leadRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/leaves", leaveRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/reports", reportsRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/sales", salesRoutes);
app.use("/api/invoices", invoiceRoutes);
app.use("/api/finance", financeRoutes);
app.use("/api/meetings", meetingRoutes);
app.use("/api/tickets", ticketRoutes);
app.use("/api/followups", followupRoutes);
app.use("/api/contacts", contactRoutes);
app.use("/api/vendors", vendorRoutes);
app.use("/api/campaigns", campaignRoutes);
app.use("/api/emails", emailRoutes);
app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/activity-logs", activityLogRoutes);
app.use("/api/audit-logs", auditLogRoutes);
app.use("/api/subscriptions", subscriptionRoutes);
app.use("/api/super-admin", superAdminRoutes);
app.use("/api/communication", communicationRoutes);
app.use( "/api/customer-portal", customerPortalRoutes);
app.use("/api/customer-experience",customerExperienceRoutes);
app.use("/api/collaborations", collaborationRoutes);
app.use("/api/backups", backupRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/uploads", express.static("uploads"));
app.use("/api/companies", companyRoutes);
app.use("/api/multi-language", multiLanguageRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/ai-chatbot", aiChatbotRoutes);
app.use("/api/ai-assistant",aiAssistantRoutes);



app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "CRM Backend Running Successfully"
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server Running on Port ${PORT}`);
});