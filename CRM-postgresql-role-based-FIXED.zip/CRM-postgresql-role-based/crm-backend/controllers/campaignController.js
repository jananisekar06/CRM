const store = require("../db/store");
const TABLE = "campaigns";

const getCampaigns = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createCampaign = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "CMP");
  const newCampaign = {
    id,
    name: req.body.name,
    channel: req.body.channel,
    sent: req.body.sent || 0,
    opened: req.body.opened || 0,
    clicked: req.body.clicked || 0,
    status: req.body.status || "Scheduled",
  };

  await store.insertItem(TABLE, newCampaign);

  res.status(201).json({ success: true, message: "Campaign created successfully", campaign: newCampaign });
};

const updateCampaign = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Campaign not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Campaign updated successfully", campaign: updated });
};

const deleteCampaign = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Campaign not found" });
  }

  res.json({ success: true, message: "Campaign deleted successfully" });
};

module.exports = { getCampaigns, createCampaign, updateCampaign, deleteCampaign };
