const store = require("../db/store");
const TABLE = "audit_logs";

const getAuditLogs = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createAuditLog = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "LOG");
  const newLog = { id, ...req.body };

  await store.insertItem(TABLE, newLog);

  res.status(201).json({ success: true, message: "Audit log created successfully", log: newLog });
};

const updateAuditLog = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Audit log not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Audit log updated successfully", log: updated });
};

const deleteAuditLog = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Audit log not found" });
  }

  res.json({ success: true, message: "Audit log deleted successfully" });
};

module.exports = { getAuditLogs, createAuditLog, updateAuditLog, deleteAuditLog };
