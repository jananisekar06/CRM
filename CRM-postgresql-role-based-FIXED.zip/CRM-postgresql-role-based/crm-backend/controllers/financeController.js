const store = require("../db/store");

const TABLE = "finances";

// ==============================
// GET ALL FINANCES
// ==============================
const getFinances = async (req, res) => {
  try {
    const finances = await store.listAll(TABLE);

    res.status(200).json(finances);
  } catch (error) {
    console.error("GET FINANCES ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch finance records",
      error: error.message,
    });
  }
};

// ==============================
// ADD FINANCE
// ==============================
const addFinance = async (req, res) => {
  try {
    console.log("ADD FINANCE BODY:", req.body);

    // Get existing records
    const existingFinances = await store.listAll(TABLE);

    // Generate next numeric ID
    const numericIds = existingFinances
      .map((item) => Number(item.id))
      .filter((id) => !isNaN(id));

    const nextId =
      numericIds.length > 0
        ? Math.max(...numericIds) + 1
        : 1;

    const finance = {
      id: nextId,
      title: req.body.title || "Office Expense",
      amount: Number(req.body.amount) || 0,
      type: req.body.type || "Expense",
      description: req.body.description || "",
      date: req.body.date || new Date().toISOString().split("T")[0],
      employee: req.body.employee || "Admin",
      status: req.body.status || "Pending",
    };

    await store.insertItem(TABLE, finance);

    console.log("FINANCE CREATED:", finance);

    res.status(201).json({
      success: true,
      message: "Finance Added Successfully",
      finance: finance,
    });
  } catch (error) {
    console.error("ADD FINANCE ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create finance record",
      error: error.message,
    });
  }
};

// ==============================
// DELETE FINANCE
// ==============================
const deleteFinance = async (req, res) => {
  try {
    const removed = await store.removeItem(
      TABLE,
      req.params.id
    );

    if (!removed) {
      return res.status(404).json({
        success: false,
        message: "Finance not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Finance deleted successfully",
    });
  } catch (error) {
    console.error("DELETE FINANCE ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete finance record",
      error: error.message,
    });
  }
};

// ==============================
// UPDATE FINANCE
// ==============================
const updateFinance = async (req, res) => {
  try {
    const existing = await store.getById(
      TABLE,
      req.params.id
    );

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: "Finance not found",
      });
    }

    const updated = await store.updateItem(
      TABLE,
      req.params.id,
      {
        ...existing,
        ...req.body,
        id: existing.id,
      }
    );

    res.status(200).json({
      success: true,
      message: "Finance updated successfully",
      finance: updated,
    });
  } catch (error) {
    console.error("UPDATE FINANCE ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update finance record",
      error: error.message,
    });
  }
};

module.exports = {
  getFinances,
  addFinance,
  deleteFinance,
  updateFinance,
};