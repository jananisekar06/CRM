const askAI = async (req, res) => {
  try {
    const { question } = req.body;

    if (!question || !question.trim()) {
      return res.status(400).json({
        success: false,
        message: "Question is required",
      });
    }

    console.log("=================================");
    console.log("AI QUESTION:", question);
    console.log("=================================");

    // Temporary answer system
    const answer = generateAnswer(question);

    return res.status(200).json({
      success: true,
      question,
      answer,
    });

  } catch (error) {
    console.error("AI ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to generate AI response",
      error: error.message,
    });
  }
};


// ================================
// ANSWER FUNCTION
// ================================
function generateAnswer(question) {
  const q = question.toLowerCase();

  if (q.includes("customer")) {
    return "You can manage customers from the Customer Management section. Review customer details, follow-ups, communication history and status.";
  }

  if (q.includes("sales")) {
    return "To improve sales performance, prioritize high-value leads, follow up regularly, track conversions and analyze customer behavior.";
  }

  if (q.includes("lead")) {
    return "Prioritize leads based on interest level, expected value, recent activity and probability of conversion.";
  }

  if (q.includes("employee")) {
    return "Employee information can be managed through the Employee Management section, including employee details, department and status.";
  }

  if (q.includes("payroll") || q.includes("salary")) {
    return "Payroll information can be managed from the Payroll section. You can review salary, allowance, deduction, net salary and payment status.";
  }

  if (q.includes("email")) {
    return "You can send customer or business emails from the Email section. Make sure your Gmail SMTP credentials are correctly configured.";
  }

  if (q.includes("communication") || q.includes("call")) {
    return "The Communication section allows you to manage call records, call duration, employees, customers and call status.";
  }

  if (q.includes("report")) {
    return "Reports can help you analyze business performance, sales activity, customer activity and employee-related information.";
  }

  // General question
  return `I received your question:

"${question}"

I can help you with CRM customers, leads, sales, employees, payroll, email, communication, reports and general business questions.`;
}

module.exports = {
  askAI,
};