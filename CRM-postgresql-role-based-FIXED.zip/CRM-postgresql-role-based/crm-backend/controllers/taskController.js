const store = require("../db/store");
const TABLE = "tasks";

const getTasks = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addTask = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const task = { id, ...req.body, status: "Pending" };

  await store.insertItem(TABLE, task);

  res.status(201).json({ success: true, message: "Task Added Successfully", task });
};

module.exports = { getTasks, addTask };
