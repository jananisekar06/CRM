const store = require("../db/store");
const TABLE = "attendance";

const getAttendance = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const markAttendance = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const record = { id, ...req.body };

  await store.insertItem(TABLE, record);

  res.status(201).json({ success: true, message: "Attendance Marked Successfully", attendance: record });
};

module.exports = { getAttendance, markAttendance };
