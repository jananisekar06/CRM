const chatWithAI = (req, res) => {
  try {
    const { message } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({
        success: false,
        message: "Please enter a message",
      });
    }

    const text = message.toLowerCase();

    let reply;

    if (
      text.includes("business hours") ||
      text.includes("working hours") ||
      text.includes("timing")
    ) {
      reply =
        "🕒 Our business hours are Monday to Saturday, 9:00 AM to 6:00 PM.";
    } else if (
      text.includes("order") ||
      text.includes("delivery")
    ) {
      reply =
        "📦 Please provide your Order ID to check your order status.";
    } else if (
      text.includes("password") ||
      text.includes("forgot password") ||
      text.includes("reset password")
    ) {
      reply =
        "🔑 Click on 'Forgot Password' on the login page to reset your password.";
    } else if (
      text.includes("service") ||
      text.includes("services")
    ) {
      reply =
        "💼 We provide CRM Software, Sales Management, Customer Support, and Business Analytics.";
    } else if (
      text.includes("meeting") ||
      text.includes("schedule")
    ) {
      reply =
        "📅 You can schedule a meeting from the Meeting Scheduler module.";
    } else if (
      text.includes("support") ||
      text.includes("help") ||
      text.includes("contact")
    ) {
      reply =
        "👨‍💻 Connecting you to our Support Team...";
    } else if (
      text.includes("hello") ||
      text.includes("hi") ||
      text.includes("hey")
    ) {
      reply =
        "👋 Hello! I'm your CRM AI Assistant. How can I help you today?";
    } else if (
      text.includes("thank")
    ) {
      reply =
        "😊 You're welcome! I'm happy to help.";
    } else {
      reply =
        "🤖 Sorry, I couldn't understand your question. Please try another question.";
    }

    res.status(200).json({
      success: true,
      userMessage: message,
      reply,
    });
  } catch (error) {
    console.error("AI Chatbot Error:", error);

    res.status(500).json({
      success: false,
      message: "AI chatbot server error",
    });
  }
};

const connectSupport = (req, res) => {
  try {
    res.status(200).json({
      success: true,
      message:
        "👨‍💻 You have been connected to our Support Team.",
    });
  } catch (error) {
    console.error("Support connection error:", error);

    res.status(500).json({
      success: false,
      message: "Unable to connect to support",
    });
  }
};

module.exports = {
  chatWithAI,
  connectSupport,
};