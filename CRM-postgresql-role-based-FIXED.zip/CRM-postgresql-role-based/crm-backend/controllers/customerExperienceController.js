const store = require("../db/store");
const FEEDBACKS = "cx_feedbacks";
const LOYALTY = "cx_loyalty";
const REFERRALS = "cx_referrals";
const SURVEYS = "cx_surveys";
const KNOWLEDGE_BASE = "cx_knowledge_base";

const getFeedbacks = async (req, res) => {
  try {
    res.status(200).json({ success: true, feedbacks: await store.listAll(FEEDBACKS) });
  } catch (error) {
    console.error("Get Feedback Error:", error);
    res.status(500).json({ success: false, message: "Failed to load feedbacks" });
  }
};

const getFeedbackById = async (req, res) => {
  try {
    const feedback = await store.getById(FEEDBACKS, req.params.id, true);

    if (!feedback) {
      return res.status(404).json({ success: false, message: "Feedback not found" });
    }

    res.status(200).json({ success: true, feedback });
  } catch (error) {
    console.error("Get Feedback Error:", error);
    res.status(500).json({ success: false, message: "Failed to load feedback" });
  }
};

const createFeedback = async (req, res) => {
  try {
    const { customer, service, rating, feedback, status } = req.body;

    if (!customer || !service || !rating || !feedback) {
      return res.status(400).json({ success: false, message: "Customer, service, rating and feedback are required" });
    }

    const id = await store.nextPrefixedId(FEEDBACKS, "FB");
    const newFeedback = {
      id,
      customer,
      service,
      rating: Number(rating),
      feedback,
      status: status || "Pending",
    };

    await store.insertItem(FEEDBACKS, newFeedback);

    res.status(201).json({ success: true, message: "Feedback created successfully", feedback: newFeedback });
  } catch (error) {
    console.error("Create Feedback Error:", error);
    res.status(500).json({ success: false, message: "Failed to create feedback" });
  }
};

const updateFeedback = async (req, res) => {
  try {
    const existing = await store.getById(FEEDBACKS, req.params.id, true);

    if (!existing) {
      return res.status(404).json({ success: false, message: "Feedback not found" });
    }

    const updated = await store.updateItem(FEEDBACKS, req.params.id, {
      ...existing,
      ...req.body,
      id: existing.id,
    }, true);

    res.status(200).json({ success: true, message: "Feedback updated successfully", feedback: updated });
  } catch (error) {
    console.error("Update Feedback Error:", error);
    res.status(500).json({ success: false, message: "Failed to update feedback" });
  }
};

const deleteFeedback = async (req, res) => {
  try {
    const removed = await store.removeItem(FEEDBACKS, req.params.id, true);

    if (!removed) {
      return res.status(404).json({ success: false, message: "Feedback not found" });
    }

    res.status(200).json({ success: true, message: "Feedback deleted successfully", feedback: removed });
  } catch (error) {
    console.error("Delete Feedback Error:", error);
    res.status(500).json({ success: false, message: "Failed to delete feedback" });
  }
};

const getLoyaltyPoints = async (req, res) => {
  try {
    res.status(200).json({ success: true, loyaltyPoints: await store.listAll(LOYALTY) });
  } catch (error) {
    console.error("Get Loyalty Error:", error);
    res.status(500).json({ success: false, message: "Failed to load loyalty points" });
  }
};

const getReferrals = async (req, res) => {
  try {
    res.status(200).json({ success: true, referrals: await store.listAll(REFERRALS) });
  } catch (error) {
    console.error("Get Referral Error:", error);
    res.status(500).json({ success: false, message: "Failed to load referrals" });
  }
};

const getSurveys = async (req, res) => {
  try {
    res.status(200).json({ success: true, surveys: await store.listAll(SURVEYS) });
  } catch (error) {
    console.error("Get Survey Error:", error);
    res.status(500).json({ success: false, message: "Failed to load surveys" });
  }
};

const getKnowledgeBase = async (req, res) => {
  try {
    res.status(200).json({ success: true, knowledgeBase: await store.listAll(KNOWLEDGE_BASE) });
  } catch (error) {
    console.error("Get Knowledge Base Error:", error);
    res.status(500).json({ success: false, message: "Failed to load knowledge base" });
  }
};

const getSummary = async (req, res) => {
  try {
    const feedbacks = await store.listAll(FEEDBACKS);
    const surveys = await store.listAll(SURVEYS);
    const loyaltyPoints = await store.listAll(LOYALTY);
    const referrals = await store.listAll(REFERRALS);
    const knowledgeBase = await store.listAll(KNOWLEDGE_BASE);

    const averageRating = feedbacks.length > 0
      ? (feedbacks.reduce((sum, item) => sum + Number(item.rating), 0) / feedbacks.length).toFixed(1)
      : 0;

    const averageCSAT = surveys.length > 0
      ? Math.round(surveys.reduce((sum, item) => sum + Number(item.csatScore), 0) / surveys.length)
      : 0;

    res.status(200).json({
      success: true,
      summary: {
        averageRating: Number(averageRating),
        csat: averageCSAT,
        loyaltyMembers: loyaltyPoints.length,
        referrals: referrals.length,
        knowledgeArticles: knowledgeBase.length,
      },
    });
  } catch (error) {
    console.error("Get Summary Error:", error);
    res.status(500).json({ success: false, message: "Failed to load customer experience summary" });
  }
};

module.exports = {
  getFeedbacks,
  getFeedbackById,
  createFeedback,
  updateFeedback,
  deleteFeedback,
  getLoyaltyPoints,
  getReferrals,
  getSurveys,
  getKnowledgeBase,
  getSummary,
};
