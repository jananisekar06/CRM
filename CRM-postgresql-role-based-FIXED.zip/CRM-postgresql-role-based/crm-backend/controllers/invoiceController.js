const store = require("../db/store");
const TABLE = "invoices";

const getInvoices = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createInvoice = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "INV");
  const invoice = { id, ...req.body };

  await store.insertItem(TABLE, invoice);

  res.status(201).json({ success: true, message: "Invoice Created Successfully", invoice });
};

module.exports = { getInvoices, createInvoice };
