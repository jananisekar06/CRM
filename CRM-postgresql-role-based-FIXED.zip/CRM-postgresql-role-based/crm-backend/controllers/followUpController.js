const store = require("../db/store");
const TABLE = "follow_ups";

const getFollowUps = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createFollowUp = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "FU");
  const newFollowUp = { id, ...req.body };

  await store.insertItem(TABLE, newFollowUp);

  res.status(201).json({ success: true, message: "Follow-up created successfully", followUp: newFollowUp });
};

const updateFollowUp = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Follow-up not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Follow-up updated successfully", followUp: updated });
};

const deleteFollowUp = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Follow-up not found" });
  }

  res.json({ success: true, message: "Follow-up deleted successfully" });
};

module.exports = { getFollowUps, createFollowUp, updateFollowUp, deleteFollowUp };
