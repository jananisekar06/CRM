const store = require("../db/store");
const TABLE = "reports";

const getReports = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addReport = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const report = { id, ...req.body };

  await store.insertItem(TABLE, report);

  res.status(201).json({ success: true, message: "Report Added Successfully", report });
};

const deleteReport = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Report not found" });
  }

  res.json({ success: true, message: "Report deleted successfully" });
};

const updateReport = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Report not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body, id: existing.id });

  res.json({ success: true, message: "Report updated successfully", report: updated });
};

module.exports = { getReports, addReport, deleteReport, updateReport };
