const store = require("../db/store");
const TABLE = "calls";

const getCalls = async (req, res) => {
  try {
    res.status(200).json({ success: true, calls: await store.listAll(TABLE) });
  } catch (error) {
    console.error("Get Calls Error:", error);
    res.status(500).json({ success: false, message: "Failed to load call records" });
  }
};

const getCallById = async (req, res) => {
  try {
    const call = await store.getById(TABLE, req.params.id, true);

    if (!call) {
      return res.status(404).json({ success: false, message: "Call record not found" });
    }

    res.status(200).json({ success: true, call });
  } catch (error) {
    console.error("Get Call Error:", error);
    res.status(500).json({ success: false, message: "Failed to load call" });
  }
};

const createCall = async (req, res) => {
  try {
    const { customer, phone, duration, employee, status } = req.body;

    if (!customer || !phone || !employee) {
      return res.status(400).json({ success: false, message: "Customer, phone and employee are required" });
    }

    const id = await store.nextPrefixedId(TABLE, "CL");
    const newCall = {
      id,
      customer: customer.trim(),
      phone: phone.trim(),
      duration: duration || "00:00",
      employee: employee.trim(),
      status: status || "Completed",
    };

    await store.insertItem(TABLE, newCall);

    res.status(201).json({ success: true, message: "Call record created successfully", call: newCall });
  } catch (error) {
    console.error("Create Call Error:", error);
    res.status(500).json({ success: false, message: "Failed to create call record" });
  }
};

const updateCall = async (req, res) => {
  try {
    const existing = await store.getById(TABLE, req.params.id, true);

    if (!existing) {
      return res.status(404).json({ success: false, message: "Call record not found" });
    }

    const { customer, phone, duration, employee, status } = req.body;

    if (!customer || !phone || !employee) {
      return res.status(400).json({ success: false, message: "Customer, phone and employee are required" });
    }

    const updated = await store.updateItem(TABLE, req.params.id, {
      ...existing,
      customer: customer.trim(),
      phone: phone.trim(),
      duration: duration || "00:00",
      employee: employee.trim(),
      status: status || "Completed",
    }, true);

    res.status(200).json({ success: true, message: "Call record updated successfully", call: updated });
  } catch (error) {
    console.error("Update Call Error:", error);
    res.status(500).json({ success: false, message: "Failed to update call record" });
  }
};

const deleteCall = async (req, res) => {
  try {
    const removed = await store.removeItem(TABLE, req.params.id, true);

    if (!removed) {
      return res.status(404).json({ success: false, message: "Call record not found" });
    }

    res.status(200).json({ success: true, message: "Call record deleted successfully", call: removed });
  } catch (error) {
    console.error("Delete Call Error:", error);
    res.status(500).json({ success: false, message: "Failed to delete call record" });
  }
};

module.exports = { getCalls, getCallById, createCall, updateCall, deleteCall };
