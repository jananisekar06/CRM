const store = require("../db/store");
const TABLE = "whatsapp_messages";

const getMessages = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createMessage = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "WA");
  const newMessage = {
    id,
    customer: req.body.customer,
    phone: req.body.phone,
    type: req.body.type,
    date: req.body.date || new Date().toLocaleDateString("en-GB"),
    status: req.body.status || "Pending",
    message: req.body.message,
  };

  await store.insertItem(TABLE, newMessage);

  res.status(201).json({ success: true, message: "WhatsApp message created successfully", data: newMessage });
};

const updateMessage = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "WhatsApp message not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "WhatsApp message updated successfully", data: updated });
};

const deleteMessage = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "WhatsApp message not found" });
  }

  res.json({ success: true, message: "WhatsApp message deleted successfully" });
};

module.exports = { getMessages, createMessage, updateMessage, deleteMessage };
