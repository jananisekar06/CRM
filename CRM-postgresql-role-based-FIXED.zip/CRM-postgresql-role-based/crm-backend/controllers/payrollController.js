const store = require("../db/store");

const TABLE = "payroll";

// =====================================================
// GET ALL PAYROLL
// =====================================================

const getPayroll = async (req, res) => {
  try {
    const payroll = await store.listAll(TABLE);

    res.status(200).json({
      success: true,
      payroll,
    });
  } catch (error) {
    console.error("❌ GET PAYROLL ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to load payroll",
      error: error.message,
    });
  }
};

// =====================================================
// ADD PAYROLL
// =====================================================

const addPayroll = async (req, res) => {
  try {
    console.log("=================================");
    console.log("PAYROLL ADD REQUEST");
    console.log("BODY:", req.body);
    console.log("=================================");

    // Check request body
    if (!req.body || Object.keys(req.body).length === 0) {
      return res.status(400).json({
        success: false,
        message: "Payroll data is required",
      });
    }

    // Generate numeric ID
    const id = await store.nextNumericId(TABLE);

    // Create payroll object
    const salary = {
      id,
      ...req.body,
    };

    console.log("Generated Payroll ID:", id);
    console.log("Payroll Data:", salary);

    // Save to PostgreSQL
    await store.insertItem(TABLE, salary);

    console.log("✅ PAYROLL SAVED SUCCESSFULLY");

    return res.status(201).json({
      success: true,
      message: "Payroll Added Successfully",
      salary,
    });

  } catch (error) {
    console.error("=================================");
    console.error("❌ PAYROLL ADD ERROR");
    console.error("Code:", error.code);
    console.error("Message:", error.message);
    console.error("Detail:", error.detail);
    console.error("=================================");

    return res.status(500).json({
      success: false,
      message: "Failed to add payroll",
      error: error.message,
      code: error.code || null,
      detail: error.detail || null,
    });
  }
};

module.exports = {
  getPayroll,
  addPayroll,
};