const store = require("../db/store");
const nodemailer = require("nodemailer");

const TABLE = "emails";

// =====================================================
// GMAIL TRANSPORTER
// =====================================================

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,

  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// =====================================================
// TEST EMAIL CONNECTION
// =====================================================

// Skip the live SMTP check when EMAIL_USER/EMAIL_PASS are still the
// placeholder values from .env.example — trying to verify() with those
// always fails and just spams a scary-looking error on every server start.
// Email sending itself still works fine as soon as real credentials are set;
// this only skips the startup check.
const isEmailConfigured =
  process.env.EMAIL_USER &&
  process.env.EMAIL_PASS &&
  !process.env.EMAIL_USER.includes("YOUR_GMAIL") &&
  !process.env.EMAIL_PASS.includes("YOUR_16_DIGIT");

if (isEmailConfigured) {
  transporter.verify((error, success) => {
    if (error) {
      console.error("❌ Gmail Connection Failed:", error.message);
      console.error(
        "   -> Check EMAIL_USER/EMAIL_PASS in .env. EMAIL_PASS must be a 16-character Gmail App Password (not your normal Gmail password), and 2-Step Verification must be enabled on the Google account."
      );
    } else {
      console.log("✅ Gmail SMTP Connection Ready");
    }
  });
} else {
  console.log(
    "ℹ️  Email not configured (EMAIL_USER/EMAIL_PASS still placeholders in .env) — skipping SMTP check. Email-sending features (e.g. forgot password) won't work until you set real Gmail credentials."
  );
}

// =====================================================
// SEND EMAIL
// =====================================================

const createEmail = async (req, res) => {
  try {
    const { to, subject, message } = req.body;

    console.log("=================================");
    console.log("EMAIL REQUEST");
    console.log("To:", to);
    console.log("Subject:", subject);
    console.log("Message:", message);
    console.log("=================================");

    // Validation
    if (!to || !subject || !message) {
      return res.status(400).json({
        success: false,
        message: "To, Subject and Message are required",
      });
    }

    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.error("❌ EMAIL_USER or EMAIL_PASS is missing");

      return res.status(500).json({
        success: false,
        message: "Gmail configuration is missing in .env",
      });
    }

    // =================================================
    // SEND THROUGH GMAIL
    // =================================================

    const result = await transporter.sendMail({
      from: `"CRM System" <${process.env.EMAIL_USER}>`,
      to: to.trim(),
      subject: subject.trim(),
      text: message,

      html: `
        <div style="
          font-family: Arial, sans-serif;
          max-width: 600px;
          margin: auto;
          padding: 25px;
          border: 1px solid #ddd;
          border-radius: 10px;
        ">

          <h2 style="color:#4F46E5;">
            CRM System
          </h2>

          <h3>${subject}</h3>

          <p style="
            font-size:16px;
            line-height:1.6;
            color:#334155;
          ">
            ${message}
          </p>

          <hr />

          <p style="
            color:#64748B;
            font-size:13px;
          ">
            This email was sent from CRM System.
          </p>

        </div>
      `,
    });

    console.log("✅ EMAIL SENT");
    console.log("Message ID:", result.messageId);

    // =================================================
    // SAVE EMAIL TO DATABASE
    // =================================================

    const id = await store.nextPrefixedId(TABLE, "EM");

    const email = {
      id,
      to: to.trim(),
      subject: subject.trim(),
      message,
      status: "Sent",
      messageId: result.messageId,
      date: new Date().toISOString(),
    };

    await store.insertItem(TABLE, email);

    console.log("✅ Email saved to database");

    return res.status(201).json({
      success: true,
      message: "Email sent successfully",
      email,
    });

  } catch (error) {

    console.error("=================================");
    console.error("❌ EMAIL SEND ERROR");
    console.error("Code:", error.code);
    console.error("Message:", error.message);
    console.error("=================================");

    return res.status(500).json({
      success: false,
      message: "Failed to send email",
      error: error.message,
      code: error.code || null,
    });
  }
};

// =====================================================
// GET EMAILS
// =====================================================

const getEmails = async (req, res) => {
  try {
    const emails = await store.listAll(TABLE);

    res.json(emails);
  } catch (error) {
    console.error("Get Emails Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to load emails",
      error: error.message,
    });
  }
};

// =====================================================
// UPDATE EMAIL
// =====================================================

const updateEmail = async (req, res) => {
  try {
    const existing = await store.getById(
      TABLE,
      req.params.id
    );

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: "Email not found",
      });
    }

    const updated = await store.updateItem(
      TABLE,
      req.params.id,
      {
        ...existing,
        ...req.body,
        id: existing.id,
      }
    );

    res.json({
      success: true,
      message: "Email updated successfully",
      email: updated,
    });

  } catch (error) {
    console.error("Update Email Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update email",
      error: error.message,
    });
  }
};

// =====================================================
// DELETE EMAIL
// =====================================================

const deleteEmail = async (req, res) => {
  try {
    const removed = await store.removeItem(
      TABLE,
      req.params.id
    );

    if (!removed) {
      return res.status(404).json({
        success: false,
        message: "Email not found",
      });
    }

    res.json({
      success: true,
      message: "Email deleted successfully",
    });

  } catch (error) {
    console.error("Delete Email Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete email",
      error: error.message,
    });
  }
};

module.exports = {
  getEmails,
  createEmail,
  updateEmail,
  deleteEmail,
};