const store = require("../db/store");
const TABLE = "companies";

const getCompanies = async (req, res) => {
  res.json({ success: true, companies: await store.listAll(TABLE) });
};

const getCompanyById = async (req, res) => {
  const company = await store.getById(TABLE, req.params.id);

  if (!company) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  res.json({ success: true, company });
};

const createCompany = async (req, res) => {
  const { name, admin, email, employees, plan, status } = req.body;

  if (!name || !admin || !email) {
    return res.status(400).json({ success: false, message: "Company name, admin and email are required" });
  }

  const id = await store.nextPrefixedId(TABLE, "CMP");
  const newCompany = {
    id,
    name,
    admin,
    email,
    employees: Number(employees) || 0,
    plan: plan || "Basic",
    status: status || "Active",
  };

  await store.insertItem(TABLE, newCompany);

  res.status(201).json({ success: true, message: "Company created successfully", company: newCompany });
};

const updateCompany = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, {
    ...existing,
    ...req.body,
    id: existing.id,
    employees: req.body.employees !== undefined ? Number(req.body.employees) : existing.employees,
  });

  res.json({ success: true, message: "Company updated successfully", company: updated });
};

const deleteCompany = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  res.json({ success: true, message: "Company deleted successfully", company: removed });
};

module.exports = { getCompanies, getCompanyById, createCompany, updateCompany, deleteCompany };
