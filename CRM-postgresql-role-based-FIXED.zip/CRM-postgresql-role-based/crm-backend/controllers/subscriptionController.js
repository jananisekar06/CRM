const store = require("../db/store");
const TABLE = "subscriptions";

const getSubscriptions = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createSubscription = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "SUB");
  const newSubscription = { id, ...req.body };

  await store.insertItem(TABLE, newSubscription);

  res.status(201).json({ success: true, message: "Subscription created successfully", subscription: newSubscription });
};

const updateSubscription = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Subscription not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Subscription updated successfully", subscription: updated });
};

const deleteSubscription = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Subscription not found" });
  }

  res.json({ success: true, message: "Subscription deleted successfully" });
};

module.exports = { getSubscriptions, createSubscription, updateSubscription, deleteSubscription };
