const store = require("../db/store");
const TABLE = "payments";

const getPayments = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addPayment = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const payment = { id, ...req.body };

  await store.insertItem(TABLE, payment);

  res.status(201).json({ success: true, message: "Payment Added Successfully", payment });
};

module.exports = { getPayments, addPayment };
