const store = require("../db/store");
const TABLE = "leads";

const getLeads = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addLead = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const lead = { id, ...req.body };

  await store.insertItem(TABLE, lead);

  res.status(201).json({ success: true, message: "Lead Added Successfully", lead });
};

const updateLeadStatus = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Lead not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, status: req.body.status });

  res.json({ success: true, message: "Lead status updated", lead: updated });
};

module.exports = { getLeads, addLead, updateLeadStatus };
