const store = require("../db/store");
const TABLE = "customers";

const getCustomers = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addCustomer = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const customer = { id, ...req.body };

  await store.insertItem(TABLE, customer);

  res.status(201).json({ success: true, message: "Customer Added Successfully", customer });
};

module.exports = { getCustomers, addCustomer };
