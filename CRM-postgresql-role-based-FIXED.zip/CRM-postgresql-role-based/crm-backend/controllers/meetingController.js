const store = require("../db/store");

const TABLE = "meetings";

// =====================================================
// GET ALL MEETINGS
// GET /api/meetings
// =====================================================

const getMeetings = async (req, res) => {
  try {
    const meetings = await store.listAll(TABLE);

    res.status(200).json({
      success: true,
      meetings,
    });
  } catch (error) {
    console.error("Get Meetings Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch meetings",
      error: error.message,
    });
  }
};

// =====================================================
// ADD MEETING
// POST /api/meetings
// =====================================================

const addMeeting = async (req, res) => {
  try {
    // Generate ID automatically
    const id = await store.nextPrefixedId(
      TABLE,
      "MT",
      3
    );

    const meeting = {
      id,

      title: String(req.body.title || "").trim(),

      date: req.body.date || "",

      time: req.body.time || "",

      platform:
        req.body.platform || "Google Meet",

      organizer:
        String(req.body.organizer || "").trim(),

      status:
        req.body.status || "Scheduled",
    };

    // Basic validation
    if (
      !meeting.title ||
      !meeting.date ||
      !meeting.time ||
      !meeting.organizer
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Meeting title, date, time and organizer are required",
      });
    }

    await store.insertItem(TABLE, meeting);

    res.status(201).json({
      success: true,
      message: "Meeting Added Successfully",
      meeting,
    });
  } catch (error) {
    console.error("Add Meeting Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to add meeting",
      error: error.message,
    });
  }
};

// =====================================================
// UPDATE MEETING
// PUT /api/meetings/:id
// =====================================================

const updateMeeting = async (req, res) => {
  try {
    const existing = await store.getById(
      TABLE,
      req.params.id
    );

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: "Meeting not found",
      });
    }

    const updated = {
      ...existing,

      ...req.body,

      // Never allow ID to change
      id: existing.id,

      title:
        req.body.title !== undefined
          ? String(req.body.title).trim()
          : existing.title,

      date:
        req.body.date !== undefined
          ? req.body.date
          : existing.date,

      time:
        req.body.time !== undefined
          ? req.body.time
          : existing.time,

      platform:
        req.body.platform !== undefined
          ? req.body.platform
          : existing.platform,

      organizer:
        req.body.organizer !== undefined
          ? String(req.body.organizer).trim()
          : existing.organizer,

      status:
        req.body.status !== undefined
          ? req.body.status
          : existing.status,
    };

    const result = await store.updateItem(
      TABLE,
      req.params.id,
      updated
    );

    if (!result) {
      return res.status(404).json({
        success: false,
        message: "Meeting not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Meeting Updated Successfully",
      meeting: result,
    });
  } catch (error) {
    console.error("Update Meeting Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update meeting",
      error: error.message,
    });
  }
};

// =====================================================
// DELETE MEETING
// DELETE /api/meetings/:id
// =====================================================

const deleteMeeting = async (req, res) => {
  try {
    const removed = await store.removeItem(
      TABLE,
      req.params.id
    );

    if (!removed) {
      return res.status(404).json({
        success: false,
        message: "Meeting not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Meeting Deleted Successfully",
      meeting: removed,
    });
  } catch (error) {
    console.error("Delete Meeting Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete meeting",
      error: error.message,
    });
  }
};

module.exports = {
  getMeetings,
  addMeeting,
  updateMeeting,
  deleteMeeting,
};