const store = require("../db/store");
const TABLE = "notifications";

const getNotifications = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addNotification = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const notification = { id, ...req.body };

  await store.insertItem(TABLE, notification);

  res.status(201).json({ success: true, message: "Notification Added Successfully", notification });
};

const deleteNotification = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Notification not found" });
  }

  res.json({ success: true, message: "Notification deleted successfully" });
};

module.exports = { getNotifications, addNotification, deleteNotification };
