const store = require("../db/store");
const TABLE = "leaves";

const getLeaves = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const applyLeave = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const leave = { id, ...req.body, status: "Pending" };

  await store.insertItem(TABLE, leave);

  res.status(201).json({ success: true, message: "Leave Applied Successfully", leave });
};

module.exports = { getLeaves, applyLeave };
