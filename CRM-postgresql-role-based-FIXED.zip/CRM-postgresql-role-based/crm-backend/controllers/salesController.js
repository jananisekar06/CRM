const store = require("../db/store");
const TABLE = "sales";

const getSales = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addSale = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const sale = { id, ...req.body };

  await store.insertItem(TABLE, sale);

  res.status(201).json({ success: true, message: "Sale Added Successfully", sale });
};

module.exports = { getSales, addSale };
