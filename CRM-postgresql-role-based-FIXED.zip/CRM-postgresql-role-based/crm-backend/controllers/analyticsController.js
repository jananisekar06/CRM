const store = require("../db/store");
const TABLE = "analytics";

const getAnalytics = async (req, res) => {
  try {
    res.status(200).json({ success: true, analytics: await store.listAll(TABLE) });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch analytics", error: error.message });
  }
};

const getAnalyticsById = async (req, res) => {
  try {
    const item = await store.getById(TABLE, req.params.id);

    if (!item) {
      return res.status(404).json({ success: false, message: "Analytics record not found" });
    }

    res.status(200).json({ success: true, analytics: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch analytics record", error: error.message });
  }
};

module.exports = { getAnalytics, getAnalyticsById };
