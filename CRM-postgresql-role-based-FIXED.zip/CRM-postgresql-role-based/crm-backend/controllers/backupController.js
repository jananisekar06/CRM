const store = require("../db/store");
const TABLE = "backups";
const HISTORY_TABLE = "backup_restore_history";

const getBackups = async (req, res) => {
  res.json({ success: true, data: await store.listAll(TABLE) });
};

const createBackup = async (req, res) => {
  const { name, type, storageLocation, schedule } = req.body;
  const id = await store.nextPrefixedId(TABLE, "BK");

  const newBackup = {
    id,
    name: name || "Backup",
    type: type || "Manual",
    date: new Date().toLocaleDateString("en-GB"),
    time: new Date().toLocaleTimeString("en-US"),
    size: "0 MB",
    storageLocation: storageLocation || "Local Storage",
    schedule: schedule || "Daily",
    status: "Completed",
  };

  await store.insertItem(TABLE, newBackup);

  res.status(201).json({ success: true, message: "Backup created successfully", data: newBackup });
};

const updateBackup = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Backup not found" });
  }

  const { name, type, storageLocation, schedule, backupTime, status } = req.body;

  const updated = await store.updateItem(TABLE, req.params.id, {
    ...existing,
    name: name ?? existing.name,
    type: type ?? existing.type,
    storageLocation: storageLocation ?? existing.storageLocation,
    schedule: schedule ?? existing.schedule,
    time: backupTime || existing.time,
    status: status ?? existing.status,
  });

  res.json({ success: true, message: "Backup updated successfully", data: updated });
};

const deleteBackup = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Backup not found" });
  }

  res.json({ success: true, message: "Backup deleted successfully" });
};

const restoreBackup = async (req, res) => {
  const { backupId, restoredBy } = req.body;

  const backup = await store.getById(TABLE, backupId);

  if (!backup) {
    return res.status(404).json({ success: false, message: "Backup not found" });
  }

  const restoreId = await store.nextPrefixedId(HISTORY_TABLE, "RS");
  const restore = {
    id: restoreId,
    backupId,
    restoreDate: new Date().toLocaleDateString("en-GB"),
    restoredBy: restoredBy || "Admin",
    status: "Success",
  };

  await store.insertItem(HISTORY_TABLE, restore);

  res.json({ success: true, message: "Backup restored successfully", data: restore });
};

const getRestoreHistory = async (req, res) => {
  res.json({ success: true, data: await store.listAll(HISTORY_TABLE) });
};

module.exports = { getBackups, createBackup, updateBackup, deleteBackup, restoreBackup, getRestoreHistory };
