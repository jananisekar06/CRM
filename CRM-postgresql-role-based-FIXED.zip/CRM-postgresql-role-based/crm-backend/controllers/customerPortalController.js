const store = require("../db/store");
const TABLE = "customer_portal";

const getCustomers = async (req, res) => {
  try {
    res.status(200).json({ success: true, customers: await store.listAll(TABLE) });
  } catch (error) {
    console.error("Get Customer Portal Error:", error);
    res.status(500).json({ success: false, message: "Failed to load customer portal data" });
  }
};

const getCustomerById = async (req, res) => {
  try {
    const customer = await store.getById(TABLE, req.params.id, true);

    if (!customer) {
      return res.status(404).json({ success: false, message: "Customer not found" });
    }

    res.status(200).json({ success: true, customer });
  } catch (error) {
    console.error("Get Customer By ID Error:", error);
    res.status(500).json({ success: false, message: "Failed to load customer" });
  }
};

const updateCustomer = async (req, res) => {
  try {
    const existing = await store.getById(TABLE, req.params.id, true);

    if (!existing) {
      return res.status(404).json({ success: false, message: "Customer not found" });
    }

    const updated = await store.updateItem(TABLE, req.params.id, {
      ...existing,
      ...req.body,
      id: existing.id,
    }, true);

    res.status(200).json({ success: true, message: "Customer updated successfully", customer: updated });
  } catch (error) {
    console.error("Update Customer Error:", error);
    res.status(500).json({ success: false, message: "Failed to update customer" });
  }
};

const deleteCustomer = async (req, res) => {
  try {
    const removed = await store.removeItem(TABLE, req.params.id, true);

    if (!removed) {
      return res.status(404).json({ success: false, message: "Customer not found" });
    }

    res.status(200).json({ success: true, message: "Customer deleted successfully", customer: removed });
  } catch (error) {
    console.error("Delete Customer Error:", error);
    res.status(500).json({ success: false, message: "Failed to delete customer" });
  }
};

module.exports = { getCustomers, getCustomerById, updateCustomer, deleteCustomer };
