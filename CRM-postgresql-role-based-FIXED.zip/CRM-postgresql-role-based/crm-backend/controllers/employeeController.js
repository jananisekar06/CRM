const store = require("../db/store");
const TABLE = "employees";

const getEmployees = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addEmployee = async (req, res) => {
  const id = await store.nextNumericId(TABLE);
  const employee = { id, ...req.body };

  await store.insertItem(TABLE, employee);

  res.status(201).json({ success: true, message: "Employee Added Successfully", employee });
};

module.exports = { getEmployees, addEmployee };
