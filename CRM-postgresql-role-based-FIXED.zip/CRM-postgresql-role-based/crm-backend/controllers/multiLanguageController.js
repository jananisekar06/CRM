const store = require("../db/store");
const pool = require("../db/pool");
const TABLE = "language_users";

const getLanguages = async (req, res) => {
  const { rows } = await pool.query("SELECT value FROM app_settings WHERE key = 'currentLanguage'");
  const currentLanguage = rows[0] ? rows[0].value : "English";

  res.json({
    success: true,
    currentLanguage,
    users: await store.listAll(TABLE),
    languages: ["English", "Tamil", "Hindi"],
  });
};

const getLanguageUsers = async (req, res) => {
  res.json({ success: true, users: await store.listAll(TABLE) });
};

const updateLanguage = async (req, res) => {
  const { language } = req.body;
  const validLanguages = ["English", "Tamil", "Hindi"];

  if (!language) {
    return res.status(400).json({ success: false, message: "Language is required" });
  }

  if (!validLanguages.includes(language)) {
    return res.status(400).json({ success: false, message: "Invalid language" });
  }

  await pool.query(
    "INSERT INTO app_settings (key, value) VALUES ('currentLanguage', $1) ON CONFLICT (key) DO UPDATE SET value = $1",
    [language]
  );

  res.json({ success: true, message: "Language updated successfully", currentLanguage: language });
};

module.exports = { getLanguages, getLanguageUsers, updateLanguage };
