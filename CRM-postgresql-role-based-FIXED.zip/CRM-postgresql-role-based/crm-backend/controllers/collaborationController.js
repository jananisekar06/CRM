const store = require("../db/store");
const TABLE = "collaborations";

const getCollaborations = async (req, res) => {
  res.status(200).json(await store.listAll(TABLE));
};

const getCollaborationById = async (req, res) => {
  const collaboration = await store.getById(TABLE, req.params.id);

  if (!collaboration) {
    return res.status(404).json({ message: "Collaboration not found" });
  }

  res.status(200).json(collaboration);
};

const createCollaboration = async (req, res) => {
  const { employee, type, lastMessage, status } = req.body;

  if (!employee || !type || !lastMessage || !status) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const id = await store.nextPrefixedId(TABLE, "CHAT");
  const newCollaboration = { id, employee, type, lastMessage, status };

  await store.insertItem(TABLE, newCollaboration);

  res.status(201).json({ message: "Collaboration created successfully", collaboration: newCollaboration });
};

const updateCollaboration = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ message: "Collaboration not found" });
  }

  const { employee, type, lastMessage, status } = req.body;

  const updated = await store.updateItem(TABLE, req.params.id, {
    ...existing,
    employee: employee || existing.employee,
    type: type || existing.type,
    lastMessage: lastMessage || existing.lastMessage,
    status: status || existing.status,
  });

  res.status(200).json({ message: "Collaboration updated successfully", collaboration: updated });
};

const deleteCollaboration = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ message: "Collaboration not found" });
  }

  res.status(200).json({ message: "Collaboration deleted successfully", collaboration: removed });
};

module.exports = { getCollaborations, getCollaborationById, createCollaboration, updateCollaboration, deleteCollaboration };
