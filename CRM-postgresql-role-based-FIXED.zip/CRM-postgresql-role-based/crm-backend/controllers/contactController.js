const store = require("../db/store");
const TABLE = "contacts";

const getContacts = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createContact = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "CNT");
  const newContact = { id, ...req.body };

  await store.insertItem(TABLE, newContact);

  res.status(201).json({ success: true, message: "Contact created successfully", contact: newContact });
};

const updateContact = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Contact not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Contact updated successfully", contact: updated });
};

const deleteContact = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Contact not found" });
  }

  res.json({ success: true, message: "Contact deleted successfully" });
};

module.exports = { getContacts, createContact, updateContact, deleteContact };
