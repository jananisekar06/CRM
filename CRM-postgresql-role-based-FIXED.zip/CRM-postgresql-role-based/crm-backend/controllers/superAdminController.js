const store = require("../db/store");
const TABLE = "super_admin_companies";

const getCompanies = async (req, res) => {
  res.status(200).json({ success: true, companies: await store.listAll(TABLE) });
};

const getCompanyById = async (req, res) => {
  const company = await store.getById(TABLE, req.params.id, true);

  if (!company) {
    return res.status(404).json({ success: false, message: "Company not found" });
  }

  res.status(200).json({ success: true, company });
};

const createCompany = async (req, res) => {
  try {
    const { company, admin, users, plan, status } = req.body;

    if (!company || !admin || !plan) {
      return res.status(400).json({ success: false, message: "Company, admin and plan are required" });
    }

    const id = await store.nextPrefixedId(TABLE, "CMP");
    const newCompany = {
      id,
      company: company.trim(),
      admin: admin.trim(),
      users: Number(users) || 0,
      plan,
      status: status || "Active",
    };

    await store.insertItem(TABLE, newCompany);

    res.status(201).json({ success: true, message: "Company created successfully", company: newCompany });
  } catch (error) {
    console.error("CREATE COMPANY ERROR:", error);
    res.status(500).json({ success: false, message: "Failed to create company" });
  }
};

const updateCompany = async (req, res) => {
  try {
    const existing = await store.getById(TABLE, req.params.id, true);

    if (!existing) {
      return res.status(404).json({ success: false, message: "Company not found" });
    }

    const { company, admin, users, plan, status } = req.body;

    if (!company || !admin || !plan) {
      return res.status(400).json({ success: false, message: "Company, admin and plan are required" });
    }

    const updated = await store.updateItem(TABLE, req.params.id, {
      ...existing,
      company: company.trim(),
      admin: admin.trim(),
      users: Number(users) || 0,
      plan,
      status: status || "Active",
    }, true);

    res.status(200).json({ success: true, message: "Company updated successfully", company: updated });
  } catch (error) {
    console.error("UPDATE COMPANY ERROR:", error);
    res.status(500).json({ success: false, message: "Failed to update company" });
  }
};

const deleteCompany = async (req, res) => {
  try {
    const removed = await store.removeItem(TABLE, req.params.id, true);

    if (!removed) {
      return res.status(404).json({ success: false, message: "Company not found" });
    }

    res.status(200).json({ success: true, message: "Company deleted successfully", company: removed });
  } catch (error) {
    console.error("DELETE COMPANY ERROR:", error);
    res.status(500).json({ success: false, message: "Failed to delete company" });
  }
};

module.exports = { getCompanies, getCompanyById, createCompany, updateCompany, deleteCompany };
