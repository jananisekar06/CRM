const store = require("../db/store");
const TABLE = "uploaded_files";

const getUploadedFiles = async (req, res) => {
  res.json({ success: true, files: await store.listAll(TABLE) });
};

const uploadFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: "Please select a file" });
    }

    const file = {
      id: Date.now(),
      name: req.file.originalname,
      size: formatFileSize(req.file.size),
      type: req.file.mimetype,
      date: new Date().toLocaleDateString("en-IN"),
      filename: req.file.filename,
      path: req.file.path,
    };

    await store.insertItem(TABLE, file);

    res.status(201).json({ success: true, message: "File uploaded successfully", file });
  } catch (error) {
    console.error("Upload Error:", error);
    res.status(500).json({ success: false, message: "File upload failed" });
  }
};

const deleteUploadedFile = async (req, res) => {
  try {
    const removed = await store.removeItem(TABLE, req.params.id);

    if (!removed) {
      return res.status(404).json({ success: false, message: "File not found" });
    }

    res.json({ success: true, message: "File deleted successfully", file: removed });
  } catch (error) {
    console.error("Delete Error:", error);
    res.status(500).json({ success: false, message: "File deletion failed" });
  }
};

const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return Math.round((bytes / Math.pow(1024, i)) * 100) / 100 + " " + sizes[i];
};

module.exports = { getUploadedFiles, uploadFile, deleteUploadedFile };
