const store = require("../db/store");
const TABLE = "vendors";

const getVendors = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createVendor = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "V");
  const newVendor = { id, ...req.body };

  await store.insertItem(TABLE, newVendor);

  res.status(201).json({ success: true, message: "Vendor created successfully", vendor: newVendor });
};

const updateVendor = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Vendor not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body });

  res.json({ success: true, message: "Vendor updated successfully", vendor: updated });
};

const deleteVendor = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Vendor not found" });
  }

  res.json({ success: true, message: "Vendor deleted successfully" });
};

module.exports = { getVendors, createVendor, updateVendor, deleteVendor };
