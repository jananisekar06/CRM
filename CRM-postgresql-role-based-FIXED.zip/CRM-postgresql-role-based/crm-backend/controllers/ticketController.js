const store = require("../db/store");

const TABLE = "tickets";

// =====================================================
// GET ALL TICKETS
// =====================================================

const getTickets = async (req, res) => {
  try {
    const tickets = await store.listAll(TABLE);

    res.status(200).json(tickets);
  } catch (error) {
    console.error("GET TICKETS ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch tickets",
      error: error.message,
    });
  }
};

// =====================================================
// CREATE TICKET
// =====================================================

const createTicket = async (req, res) => {
  try {
    console.log("CREATE TICKET BODY:", req.body);

    const {
      customer,
      employee,
      issue,
      priority,
      assignedTo,
      status,
      date,
    } = req.body;

    // ---------------------------------------------
    // VALIDATION
    // ---------------------------------------------

    if (!customer || !customer.trim()) {
      return res.status(400).json({
        success: false,
        message: "Customer name is required",
      });
    }

    if (!employee || !employee.trim()) {
      return res.status(400).json({
        success: false,
        message: "Employee name is required",
      });
    }

    if (!issue || !issue.trim()) {
      return res.status(400).json({
        success: false,
        message: "Issue / Problem is required",
      });
    }

    // ---------------------------------------------
    // GENERATE ID
    // ---------------------------------------------

    const ticketId = await store.nextPrefixedId(
      TABLE,
      "TKT",
      3
    );

    // ---------------------------------------------
    // CREATE TICKET
    // ---------------------------------------------

    const ticket = {
      id: ticketId,
      customer: customer.trim(),
      employee: employee.trim(),
      issue: issue.trim(),
      priority: priority || "Medium",
      assignedTo:
        assignedTo?.trim() || employee.trim(),
      status: status || "Open",
      date:
        date ||
        new Date().toISOString().split("T")[0],
    };

    console.log("TICKET TO SAVE:", ticket);

    // ---------------------------------------------
    // SAVE
    // ---------------------------------------------

    const savedTicket = await store.insertItem(
      TABLE,
      ticket
    );

    console.log("TICKET SAVED:", savedTicket);

    res.status(201).json({
      success: true,
      message: "Ticket Created Successfully",
      ticket: savedTicket,
    });
  } catch (error) {
    console.error(
      "CREATE TICKET ERROR:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to create ticket",
      error: error.message,
    });
  }
};

// =====================================================
// UPDATE TICKET
// =====================================================

const updateTicket = async (req, res) => {
  try {
    const ticketId = req.params.id;

    const existing = await store.getById(
      TABLE,
      ticketId
    );

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found",
      });
    }

    const updatedTicket = {
      ...existing,
      ...req.body,
      id: existing.id,
    };

    const updated = await store.updateItem(
      TABLE,
      ticketId,
      updatedTicket
    );

    res.json({
      success: true,
      message: "Ticket Updated Successfully",
      ticket: updated,
    });
  } catch (error) {
    console.error(
      "UPDATE TICKET ERROR:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to update ticket",
      error: error.message,
    });
  }
};

// =====================================================
// DELETE TICKET
// =====================================================

const deleteTicket = async (req, res) => {
  try {
    const removed = await store.removeItem(
      TABLE,
      req.params.id
    );

    if (!removed) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found",
      });
    }

    res.json({
      success: true,
      message: "Ticket Deleted Successfully",
    });
  } catch (error) {
    console.error(
      "DELETE TICKET ERROR:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to delete ticket",
      error: error.message,
    });
  }
};

// =====================================================
// EXPORT
// =====================================================

module.exports = {
  getTickets,
  createTicket,
  updateTicket,
  deleteTicket,
};