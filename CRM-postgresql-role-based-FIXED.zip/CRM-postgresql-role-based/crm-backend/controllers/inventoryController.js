const store = require("../db/store");
const TABLE = "products";

const getProducts = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const addProduct = async (req, res) => {
  const product = {
    id: req.body.id,
    name: req.body.name,
    stock: req.body.stock,
    purchase: req.body.purchase,
    sales: req.body.sales,
    status: req.body.status,
  };

  await store.insertItem(TABLE, product);

  res.status(201).json({ success: true, message: "Product Added Successfully", product });
};

const deleteProduct = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  res.json({ success: true, message: "Product deleted successfully" });
};

const updateProduct = async (req, res) => {
  const existing = await store.getById(TABLE, req.params.id);

  if (!existing) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }

  const updated = await store.updateItem(TABLE, req.params.id, { ...existing, ...req.body, id: existing.id });

  res.json({ success: true, message: "Product updated successfully", product: updated });
};

module.exports = { getProducts, addProduct, deleteProduct, updateProduct };
