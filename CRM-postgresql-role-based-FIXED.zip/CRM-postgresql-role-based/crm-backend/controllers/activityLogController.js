const store = require("../db/store");
const TABLE = "activity_logs";

const getActivityLogs = async (req, res) => {
  res.json(await store.listAll(TABLE));
};

const createActivityLog = async (req, res) => {
  const id = await store.nextPrefixedId(TABLE, "LOG");
  const newLog = {
    id,
    user: req.body.user,
    activity: req.body.activity,
    date: req.body.date,
    time: req.body.time,
    status: req.body.status,
  };

  await store.insertItem(TABLE, newLog);

  res.status(201).json({
    success: true,
    message: "Activity log created successfully",
    log: newLog,
  });
};

const getActivityLogById = async (req, res) => {
  const log = await store.getById(TABLE, req.params.id);

  if (!log) {
    return res.status(404).json({ success: false, message: "Activity log not found" });
  }

  res.json(log);
};

const deleteActivityLog = async (req, res) => {
  const removed = await store.removeItem(TABLE, req.params.id);

  if (!removed) {
    return res.status(404).json({ success: false, message: "Activity log not found" });
  }

  res.json({ success: true, message: "Activity log deleted successfully" });
};

module.exports = { getActivityLogs, createActivityLog, getActivityLogById, deleteActivityLog };
