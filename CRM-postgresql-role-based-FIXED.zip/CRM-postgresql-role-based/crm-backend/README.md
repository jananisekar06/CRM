# CRM Backend — PostgreSQL Edition

This backend used to store everything in plain in-memory JavaScript arrays
(nothing was actually saved anywhere — a server restart wiped all data, and
the MySQL connection in `config/db.js` was configured but never actually
used by any controller). It has been converted to a real PostgreSQL-backed
Express API: every one of the 38 modules now reads/writes real tables, and
login/register now use hashed passwords + JWT instead of plaintext checks
against a hardcoded array.

Two unrelated but important bugs were also fixed:
- 15+ controller/route files had filenames that didn't match the casing
  used in `require(...)` (e.g. `authcontroller.js` vs `require("authController")`).
  This works by accident on Windows/Mac (case-insensitive filesystems) but
  **crashes the server on Linux** (most hosting environments). All files are
  now renamed to match.
- `authMiddleware` was a no-op that did nothing. It now verifies JWTs
  properly (still not attached to any route, so behavior is unchanged
  unless you choose to add `authMiddleware` to a route).

## 1. Install PostgreSQL

Install PostgreSQL locally (postgresql.org, or `brew install postgresql`,
`apt install postgresql`, etc.), then create the database:

```bash
psql -U postgres -c "CREATE DATABASE crm_db;"
```

## 2. Configure `.env`

Already set up with sensible local defaults in `crm-backend/.env`:

```
PORT=5000
JWT_SECRET=crm_secret_key

DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=postgres
DB_NAME=crm_db
```

Change `DB_USER` / `DB_PASSWORD` to match your local PostgreSQL setup.

## 3. Install dependencies & create tables

```bash
cd crm-backend
npm install
npm run db:setup   # creates all 38 tables from db/schema.sql
npm run db:seed     # loads demo data + a default admin login
```

Default login after seeding: **admin@gmail.com / 123456**

## 4. Run the backend

```bash
npm run dev     # or: npm start
```

Server runs on `http://localhost:5000`. Visiting `/` should show
`{"success":true,"message":"CRM Backend Running Successfully"}`.

## 5. Run the frontend

```bash
cd crm-frontend
npm install
npm run dev
```

Opens on `http://localhost:5173` (Vite default) and talks to the backend
at `http://localhost:5000` (already hardcoded into the frontend pages).

## How data is stored

Every module (customers, leads, invoices, tickets, etc.) has its own table
shaped as `(id TEXT PRIMARY KEY, payload JSONB, created_at, updated_at)`.
The `payload` column holds the exact object the frontend sends — this keeps
every page's request/response shape identical to before, so no frontend
code needed to change, while giving you real persistence, filtering, and
the ability to run SQL against the data directly if you want.

The `users` table (login) is a normal relational table with a bcrypt
`password_hash` column — not JSONB — since auth needs real constraints
(unique email) and shouldn't store plaintext passwords.

## Verifying it end-to-end

1. Start backend + frontend as above.
2. Log in with `admin@gmail.com` / `123456`.
3. Add a customer/lead/task/etc. on any page, refresh the page — the data
   should still be there (proof it's in Postgres, not memory).
4. Check directly in the database:
   ```bash
   psql -U postgres -d crm_db -c "SELECT * FROM customers;"
   ```
